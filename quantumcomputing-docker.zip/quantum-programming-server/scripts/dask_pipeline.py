﻿from dask.distributed import Client
from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator
import time

# Start local Dask cluster (dashboard default: http://127.0.0.1:8787/status)
client = Client()
print("Dashboard:", client.dashboard_link)


def create_circuit():
    print("Creating circuit...")
    qc = QuantumCircuit(5)
    for i in range(5):
        qc.h(i)
    for i in range(4):
        qc.cx(i, i + 1)
    time.sleep(2)
    return qc


def transpile_circuit(qc):
    print("Transpiling circuit...")
    sim = AerSimulator()
    tqc = transpile(qc, sim, optimization_level=3)
    time.sleep(2)
    return tqc


def run_simulator(tqc):
    print("Running simulator...")
    tqc.measure_all()
    sim = AerSimulator()
    result = sim.run(tqc, shots=100000).result()
    time.sleep(2)
    return result.get_counts()


future1 = client.submit(create_circuit)
future2 = client.submit(transpile_circuit, future1)
future3 = client.submit(run_simulator, future2)

counts = future3.result()
print("\nResult:")
print(counts)

client.close()
