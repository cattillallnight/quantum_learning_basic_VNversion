﻿"""
IBM Quantum connection helper (optional).

1. Create an IBM Quantum account and API token:
   https://quantum.cloud.ibm.com/
2. Save token once:
   python scripts/ibm_setup.py --token YOUR_TOKEN
3. Or set env var QISKIT_IBM_TOKEN before running.
"""
from __future__ import annotations

import argparse
import os


def save_account(token: str) -> None:
    from qiskit_ibm_runtime import QiskitRuntimeService

    QiskitRuntimeService.save_account(
        channel="ibm_quantum_platform",
        token=token,
        overwrite=True,
    )
    print("IBM Quantum account saved locally.")


def test_connection() -> None:
    from qiskit_ibm_runtime import QiskitRuntimeService

    token = os.environ.get("QISKIT_IBM_TOKEN")
    if token:
        service = QiskitRuntimeService(channel="ibm_quantum_platform", token=token)
    else:
        service = QiskitRuntimeService()

    backends = service.backends()
    print(f"Connected. Available backends: {len(backends)}")
    for b in backends[:10]:
        print(" -", b.name)
    if len(backends) > 10:
        print(f" ... and {len(backends) - 10} more")


def main() -> None:
    parser = argparse.ArgumentParser(description="IBM Quantum auth helper")
    parser.add_argument("--token", help="IBM Quantum API token")
    parser.add_argument("--test", action="store_true", help="Test connection")
    args = parser.parse_args()

    if args.token:
        save_account(args.token)
    if args.test or not args.token:
        try:
            test_connection()
        except Exception as exc:
            print("Connection not configured yet or failed:")
            print(exc)
            print("\nRun: python scripts/ibm_setup.py --token YOUR_TOKEN")
            print("Or set environment variable QISKIT_IBM_TOKEN")


if __name__ == "__main__":
    main()
