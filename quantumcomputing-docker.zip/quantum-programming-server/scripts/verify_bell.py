﻿from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator

# Bell State verification (from documentation)
qc = QuantumCircuit(2, 2)
qc.h(0)
qc.cx(0, 1)
qc.measure([0, 1], [0, 1])

sim = AerSimulator()
compiled = transpile(qc, sim)
result = sim.run(compiled, shots=1000).result()
counts = result.get_counts()
print("Bell State counts:", counts)

# Expect roughly 50/50 on |00> and |11>
assert set(counts.keys()).issubset({"00", "11"}), f"Unexpected states: {counts}"
print("OK: Bell State simulation looks correct.")
