﻿import time
import math
from pathlib import Path

import pandas as pd
from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator

numbers = [143, 323, 1147, 4757, 10403, 47053]
simulator = AerSimulator()
results = []

print("QUANTUM SIMULATION")
print("-" * 50)

for n in numbers:
    qubits = max(4, math.ceil(math.log2(n)))
    qc = QuantumCircuit(qubits, qubits)
    for q in range(qubits):
        qc.h(q)
    qc.measure_all()

    start = time.perf_counter()
    compiled = transpile(qc, simulator)
    job = simulator.run(compiled, shots=2048)
    result = job.result()
    elapsed = time.perf_counter() - start

    results.append([n, qubits, elapsed])
    print(f"N={n:<8} Qubits={qubits:<2} Time={elapsed:.8f}s")

out = Path(__file__).resolve().parents[1] / "data" / "quantum_results.csv"
df = pd.DataFrame(results, columns=["N", "Qubits", "Time"])
df.to_csv(out, index=False)
print(f"\nSaved {out}")
