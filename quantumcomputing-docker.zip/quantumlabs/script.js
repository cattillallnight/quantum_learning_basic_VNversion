/* =========================================================
   QuantumLab Beginner — logic ứng dụng bằng JS thuần
   ========================================================= */
(() => {

const MODULES = ['qubits','measurement','superposition','entanglement','circuits','algorithms','noise','qec','qiskit'];
const STORAGE_KEY = 'quantumlab.progress.v1';

// ---------- Trạng thái được lưu bền ----------
const defaultProgress = () => {
  const s = {};
  MODULES.forEach(m => s[m] = {done:false, score:0});
  s.challenge = {done:false, score:0};
  return s;
};
let progress = load();

function load(){
  try{
    const raw = localStorage.getItem(STORAGE_KEY);
    if(!raw) return defaultProgress();
    return Object.assign(defaultProgress(), JSON.parse(raw));
  }catch{ return defaultProgress(); }
}
function save(){ localStorage.setItem(STORAGE_KEY, JSON.stringify(progress)); }

// ---------- Thông báo nổi (toast) ----------
const toast = msg => {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(toast._t);
  toast._t = setTimeout(() => t.classList.remove('show'), 2400);
};

// ---------- Dữ liệu bảng thuật ngữ ----------
const GLOSSARY = {
  bit:'Một đơn vị thông tin cổ điển. Hoặc là 0, hoặc là 1.',
  qubit:'Một bit lượng tử. Có thể là |0⟩, |1⟩, hoặc chồng chập của cả hai.',
  superposition:'Một tổ hợp của nhiều trạng thái lượng tử cùng một lúc.',
  entanglement:'Một mối liên kết giữa các qubit, khi đo một qubit bạn biết được thông tin về qubit kia.',
  measurement:'Hành động đọc một qubit, buộc nó phải chọn 0 hoặc 1.',
  gate:'Một phép toán làm thay đổi trạng thái của một hoặc nhiều qubit.',
  bloch:'Một mặt cầu dùng để hình dung trạng thái của một qubit đơn lẻ.',
  hadamard:'Cổng H. Biến |0⟩ thành chồng chập 50/50.',
  cnot:'Cổng 2 qubit, lật qubit đích nếu qubit điều khiển là 1. Tạo ra rối lượng tử.',
  noise:'Những nhiễu loạn không mong muốn có thể lật hoặc làm nhòe trạng thái qubit.',
  pulse:'Một xung năng lượng được tạo hình chính xác, dùng để áp dụng một cổng.',
  qiskit:'Bộ công cụ lập trình lượng tử mã nguồn mở của IBM, viết bằng Python.',
  shot:'Một lần chạy (đo) mạch lượng tử; chạy nhiều shot để thấy phân bố xác suất.',
};

const FAQ = [
  {q:'Tôi có cần giỏi toán mới bắt đầu được không?', a:'Không hề! Toàn bộ chuyến tham quan này tránh dùng phương trình. Chúng ta dùng thanh trượt, biểu đồ cột và hình ảnh.'},
  {q:'Qubit có chỉ là một bit hào nhoáng hơn không?', a:'Không — qubit có thể là 0, 1, hoặc cả hai cùng lúc. Chính sự tự do thêm đó là nguồn gốc sức mạnh lượng tử.'},
  {q:'Tôi có thể tự lắp một máy tính lượng tử thật ở nhà không?', a:'Thực tế là không — nhưng bạn có thể chạy những mạch thật trên phần cứng lượng tử đám mây (ví dụ IBM Quantum, IonQ).'},
  {q:'Vì sao nhiễu lại quan trọng đến vậy?', a:'Thông tin lượng tử rất mong manh. Những nhiễu loạn nhỏ nhất cũng làm xáo trộn nó, nên các kỹ sư dành rất nhiều công sức để cách ly qubit.'},
  {q:'"Cổng" (gate) là gì?', a:'Cổng là một phép toán tí hon, giống như một phép quay, làm thay đổi một qubit. Ghép nhiều cổng lại thành một mạch.'},
  {q:'Sau khóa học này tôi nên đi tiếp ở đâu?', a:'Hãy thử IBM Quantum Composer, Microsoft Quantum Katas, hoặc Q-CTRL Black Opal để thực hành sâu hơn.'},
];

// ---------- Dữ liệu bài kiểm tra ----------
const QUIZ_DATA = {
  qubits:[
    {q:'Một qubit có thể chứa bao nhiêu trạng thái *trước khi* nó được đo?',
     choices:['Chỉ 0','Chỉ 1','Một sự pha trộn của 0 và 1','Luôn luôn đúng 2 trạng thái cùng lúc'],
     answer:2,
     explain:'Một qubit có thể ở trạng thái chồng chập — một sự pha trộn của |0⟩ và |1⟩ — cho đến khi bị đo.'},
    {q:'Một bit cổ điển giống nhất với trạng thái nào của qubit?',
     choices:['Chồng chập','|0⟩ hoặc |1⟩ (một trạng thái xác định)','Một qubit bị rối','Chỉ là một qubit đã được đo'],
     answer:1,
     explain:'Một bit luôn ở trạng thái 0 hoặc 1 xác định, tương tự một qubit ở |0⟩ hoặc |1⟩ thuần khiết.'},
    {q:'Mũi tên Bloch chỉ thẳng lên trên biểu diễn điều gì?',
     choices:['|1⟩','|0⟩','Chồng chập cân bằng','Một lỗi'],
     answer:1,
     explain:'Theo quy ước, cực +z (hướng lên) là |0⟩ và cực −z (hướng xuống) là |1⟩.'},
  ],
  superposition:[
    {q:'Nếu P(0) = 70%, thì P(1) bằng bao nhiêu?',
     choices:['70%','30%','0%','100%'],
     answer:1,
     explain:'Xác suất của một qubit đơn phải cộng lại thành 100%, nên P(1) = 100 − 70 = 30.'},
    {q:'Chồng chập 50/50 nghĩa là...',
     choices:['Bạn luôn nhận được 0','Bạn luôn nhận được 1','Mỗi lần đo đều ngẫu nhiên như tung đồng xu cân đối','Cả 0 và 1 cùng lúc sau khi đo'],
     answer:2,
     explain:'Mỗi lần đo, bạn thấy 0 hoặc 1 một cách ngẫu nhiên với xác suất bằng nhau.'},
    {q:'Cổng nào tạo ra chồng chập cân bằng từ |0⟩?',
     choices:['X','H','CNOT','Đo'],
     answer:1,
     explain:'Cổng Hadamard (H) biến |0⟩ thành chồng chập cân bằng của |0⟩ và |1⟩.'},
  ],
  entanglement:[
    {q:'Hai qubit bị rối ở trạng thái Bell luôn cho kết quả đo...',
     choices:['Độc lập và ngẫu nhiên','Có tương quan với nhau','Đều là 0','Đều là 1'],
     answer:1,
     explain:'Ở trạng thái Bell |Φ+⟩, cả hai lần đo cho cùng một kết quả — chúng có tương quan.'},
    {q:'Để rối lượng tử, các qubit cần phải...',
     choices:['Chạm vào nhau','Được liên kết qua một tương tác trước đó','Luôn ở nhiệt độ phòng','Được làm từ cùng một nguyên tử'],
     answer:1,
     explain:'Chúng phải đã tương tác theo cách gắn số phận của chúng lại với nhau; sau đó khoảng cách không còn quan trọng.'},
    {q:'Cổng CNOT hữu ích cho việc gì?',
     choices:['Đặt lại một qubit','Thêm nhiễu','Tạo ra rối lượng tử','Đo một qubit'],
     answer:2,
     explain:'CNOT (controlled-NOT) là cổng chuẩn để làm rối hai qubit.'},
  ],
  measurement:[
    {q:'Sau khi đo, một qubit đang chồng chập trở thành...',
     choices:['Vẫn chồng chập','Chắc chắn là 0 hoặc chắc chắn là 1','Một trạng thái rối','Bị xóa mất'],
     answer:1,
     explain:'Phép đo làm sụp đổ qubit về một kết quả cổ điển duy nhất.'},
    {q:'Đo lặp lại với P(1)=70% sẽ cho...',
     choices:['Luôn là 1','Luôn là 0','Khoảng 70% là 1 qua nhiều lần thử','Đúng 7 lần ra 1, không bao giờ hơn'],
     answer:2,
     explain:'Xác suất thể hiện qua tần suất trong dài hạn — khoảng 70% trong nhiều lần đo sẽ ra 1.'},
    {q:'Vì sao không cứ đo liên tục?',
     choices:['Vì quá chậm','Vì nó phá hủy chồng chập mà ta muốn dùng','Vì tốn năng lượng','Vì bị pháp luật cấm'],
     answer:1,
     explain:'Phép đo làm sụp đổ trạng thái lượng tử phong phú, đánh mất tính song song tạo nên sức mạnh của thuật toán.'},
  ],
  circuits:[
    {q:'Trong một mạch, các cổng được áp dụng...',
     choices:['Tất cả cùng lúc một cách ngẫu nhiên','Theo một trình tự xác định qua thời gian','Chỉ một lần cho mỗi qubit','Một cách bí mật'],
     answer:1,
     explain:'Mạch được đọc từ trái sang phải; mỗi cổng hoạt động theo thứ tự.'},
    {q:'Cổng nào lật |0⟩ thành |1⟩?',
     choices:['H','X','CNOT','Đo'],
     answer:1,
     explain:'X là cổng lật bit (NOT).'},
    {q:'Phép đo thường được đặt ở đâu?',
     choices:['Ngay từ đầu','Ở cuối cùng','Ở cả hai đầu','Không quan trọng'],
     answer:1,
     explain:'Bạn thường chạy hết các cổng trước, rồi mới đo để đọc đáp án.'},
  ],
  noise:[
    {q:'Nhiễu cao hơn thường có nghĩa là...',
     choices:['Kết quả chính xác hơn','Kết quả kém chính xác hơn','Tính toán nhanh hơn','Không ảnh hưởng gì'],
     answer:1,
     explain:'Nhiễu làm hỏng trạng thái qubit, khiến thống kê đo lệch xa khỏi kết quả lý tưởng.'},
    {q:'Một lỗi lật bit có nhiễu gây ra tác động đại khái là gì?',
     choices:['Thêm một màu ngẫu nhiên','Lật 0↔1 với một xác suất nào đó','Nhân đôi qubit','Tạo ra một qubit mới'],
     answer:1,
     explain:'Kênh lật bit biến 0 thành 1 (hoặc ngược lại) một cách ngẫu nhiên với một xác suất nào đó.'},
    {q:'Làm sao chống lại nhiễu trên máy thật?',
     choices:['Phớt lờ nó','Cách ly tốt hơn, hiệu chỉnh tốt hơn và sửa lỗi','Dùng nhiều điện hơn','Chạy mạch to hơn'],
     answer:1,
     explain:'Các kỹ sư làm lạnh, che chắn, hiệu chỉnh và thêm sửa lỗi để bảo vệ qubit.'},
  ],
  qec:[
    {q:'Mã lật bit 3 qubit có thể sửa được bao nhiêu lần lật trong mỗi khối mã?',
     choices:['0','1','2','3'],
     answer:1,
     explain:'Bỏ phiếu theo đa số xử lý được tối đa 1 lần lật trong 3. Hai hoặc ba lần lật sẽ làm nó bó tay.'},
    {q:'Vượt quá tỉ lệ lỗi vật lý nào thì mã 3 qubit không còn giúp ích?',
     choices:['10%','25%','50%','99%'],
     answer:2,
     explain:'Tại p = 50%, tỉ lệ lỗi có mã hóa và không mã hóa bằng nhau. Trên 50%, dự phòng lại làm mọi thứ tệ hơn — đó là điểm hòa vốn của mã.'},
    {q:'Ý tưởng chính của sửa lỗi lượng tử là...',
     choices:['Tạo ra các qubit hoàn hảo','Mã hóa 1 qubit logic thành nhiều qubit vật lý và phát hiện/sửa lỗi','Chạy mọi mạch hai lần','Thay qubit bằng bit cổ điển'],
     answer:1,
     explain:'QEC trải thông tin logic ra trên nhiều qubit vật lý dư thừa và dùng các phép đo syndrome để phát hiện và sửa lỗi mà không làm xáo trộn trạng thái đã mã hóa.'},
  ],
  algorithms:[
    {q:'Một lần tung đồng xu lượng tử dùng cổng nào trước khi đo?',
     choices:['X','H','CNOT','Không cổng nào'],
     answer:1,
     explain:'H tạo chồng chập 50/50; đo nó sẽ cho một bit ngẫu nhiên công bằng.'},
    {q:'Thuật toán Grover mang lại kiểu tăng tốc nào?',
     choices:['Không tăng tốc','Tuyến tính (×2)','Bậc hai (√N)','Hàm mũ'],
     answer:2,
     explain:'Grover tìm ra phần tử được đánh dấu trong khoảng √N bước, so với N bước theo cách cổ điển.'},
    {q:'Deutsch–Jozsa phân biệt hằng số và cân bằng trong bao nhiêu truy vấn lượng tử?',
     choices:['1','log N','N/2','N'],
     answer:0,
     explain:'Nó chỉ cần 1 truy vấn lượng tử cho một câu trả lời mà cách cổ điển có thể cần tới N/2 + 1.'},
  ],
  qiskit:[
    {q:'Trong Qiskit, làm sao lấy được phân bố kết quả đo sau khi chạy mạch?',
     choices:['result.get_counts()','result.results()','qc.counts()','print(qc)'],
     answer:0,
     explain:'result.get_counts() trả về dict ánh xạ chuỗi bit sang số lần xuất hiện, ví dụ {"00": 512, "11": 512}.'},
    {q:'Qiskit đọc chuỗi bit theo thứ tự nào?',
     choices:['Big-endian (qubit 0 ngoài cùng bên trái)','Little-endian (qubit 0 ngoài cùng bên phải)','Ngẫu nhiên','Theo thứ tự đăng ký cổ điển'],
     answer:1,
     explain:'Qiskit dùng little-endian: qubit 0 nằm ở ngoài cùng bên phải. Chuỗi "10" nghĩa là q1=1, q0=0.'},
    {q:'Vì sao mạch Qiskit cần measure hoặc measure_all trước khi chạy để lấy counts?',
     choices:['Để tăng tốc độ','Vì kết quả đo là bit cổ điển — không đo thì không có counts','Vì cổng H cần nó','Để xóa nhiễu'],
     answer:1,
     explain:'Counts là kết quả đo cổ điển. Không có phép đo thì không có bit cổ điển nào để đếm.'},
    {q:'Qiskit 1.0 đã bỏ hàm nào mà các hướng dẫn cũ hay dùng?',
     choices:['execute()','transpile()','get_counts()','QuantumCircuit()'],
     answer:0,
     explain:'execute() đã bị bỏ. Cách mới: tạo backend rồi dùng backend.run(qc, shots=N).'},
    {q:'Cổng CNOT trong Qiskit được viết thế nào?',
     choices:['qc.cx(control, target)','qc.cnot(target, control)','qc.cnot(control, target)','qc.x(control, target)'],
     answer:0,
     explain:'qc.cx(control, target) — tham số đầu là qubit điều khiển, tham số sau là qubit đích.'},
    {q:'Muốn xem biên độ phức của trạng thái trước khi đo, bạn dùng gì?',
     choices:['result.get_counts()','Statevector từ qiskit.quantum_info','plot_histogram()','qc.draw()'],
     answer:1,
     explain:'Statevector(qc) cho bạn vector trạng thái đầy đủ (biên độ phức), trước khi bị đo sụp.'},
  ],
};


const FINAL_QUIZ = [
  {q:'Điều nào sau đây là duy nhất của máy tính lượng tử, không có ở máy tính cổ điển?',
   choices:['Bit','Dây dẫn','Chồng chập + rối lượng tử','Vòng lặp'],
   answer:2,
   explain:'Chồng chập và rối lượng tử, khi kết hợp, tạo nên lợi thế lượng tử.'},
  {q:'Bạn áp H lên |0⟩ rồi đo. Qua nhiều lần đo bạn sẽ thấy gì?',
   choices:['Luôn là 0','Luôn là 1','≈50% ra 0, 50% ra 1','Một qubit mới'],
   answer:2,
   explain:'H tạo ra một chồng chập cân bằng.'},
  {q:'Hai qubit ở trạng thái Bell cho thấy kiểu kết quả đo nào?',
   choices:['Độc lập','Luôn bằng nhau (hoặc luôn ngược nhau)','Luôn là 00','Luôn là 11'],
   answer:1,
   explain:'Chúng tương quan hoàn hảo với nhau.'},
  {q:'Tăng nhiễu từ 0% lên 50% thường sẽ...',
   choices:['Làm kết quả sắc nét hơn','Làm kết quả phẳng dần về phía ngẫu nhiên','Tăng tốc độ','Loại bỏ các cổng'],
   answer:1,
   explain:'Nhiễu cao đẩy kết quả về phía ngẫu nhiên 50/50.'},
  {q:'Vì sao các kỹ sư lượng tử lại quan tâm nhiều đến hiệu chỉnh xung (pulse)?',
   choices:['Vì trông ngầu','Để có các cổng chính xác','Để tiết kiệm pin','Để rút ngắn dây dẫn'],
   answer:1,
   explain:'Xung chỉnh sai → góc quay sai → cổng sai → đáp án sai.'},
];

// ---------- Bộ định tuyến hash ----------
const sections = document.querySelectorAll('.module');
const navLinks = document.querySelectorAll('.nav-list a');

function showSection(id){
  sections.forEach(s => s.classList.toggle('active', s.id === id));
  navLinks.forEach(a => a.classList.toggle('active', a.getAttribute('href') === '#' + id));
  document.getElementById('sidebar').classList.remove('open');
  window.scrollTo({top:0, behavior:'smooth'});
}
window.addEventListener('hashchange', () => showSection((location.hash||'#qubits').slice(1)));

// ---------- Nút mở/đóng thanh bên trên di động ----------
document.getElementById('menu-toggle').onclick = () =>
  document.getElementById('sidebar').classList.toggle('open');

// ---------- Đặt lại ----------
document.getElementById('reset-btn').onclick = () => {
  if(!confirm('Đặt lại toàn bộ tiến độ?')) return;
  localStorage.removeItem(STORAGE_KEY);
  progress = defaultProgress();
  save();
  toast('Đã đặt lại tiến độ.');
  setTimeout(()=>location.reload(), 600);
};

// ---------- Hiển thị: tiến độ, huy hiệu, điểm ----------
function render(){
  const done = MODULES.filter(m => progress[m].done).length;
  document.getElementById('progress-text').textContent = `${done} / ${MODULES.length}`;
  document.getElementById('progress-fill').style.width = (done/MODULES.length*100) + '%';

  navLinks.forEach(a => {
    const m = a.dataset.mod;
    if(m && progress[m].done) a.classList.add('done');
    else a.classList.remove('done');
  });

  // huy hiệu
  const icons = {qubits:'⚛',superposition:'🌊',entanglement:'🔗',measurement:'📏',
    circuits:'🔲',noise:'📡',qec:'🛡',algorithms:'🧮',qiskit:'🐍'};
  const badgesEl = document.getElementById('badges');
  badgesEl.innerHTML = '';
  MODULES.forEach(m => {
    const b = document.createElement('div');
    b.className = 'badge' + (progress[m].done ? ' earned' : '');
    b.title = m + (progress[m].done ? ' — đã hoàn thành' : ' — đang khóa');
    b.textContent = icons[m];
    badgesEl.appendChild(b);
  });

  const totalScore = MODULES.reduce((s,m) => s + (progress[m].score||0), 0) + (progress.challenge.score||0);
  document.getElementById('total-score').textContent = totalScore;

  // khóa thử thách trên thanh điều hướng
  document.getElementById('nav-challenge').classList.toggle('locked', done < 6);
}

// ---------- Bảng thuật ngữ ----------
function renderGlossary(){
  const list = document.getElementById('glossary-list');
  const quick = document.getElementById('quick-glossary');
  list.innerHTML = '';
  quick.innerHTML = '';
  Object.entries(GLOSSARY).forEach(([k,v]) => {
    const cap = k[0].toUpperCase() + k.slice(1);
    const item = document.createElement('div');
    item.className = 'g-item';
    item.innerHTML = `<b>${cap}</b><br><span class="muted">${v}</span>`;
    list.appendChild(item);

    const small = document.createElement('div');
    small.innerHTML = `<b>${cap}</b> — ${v}`;
    quick.appendChild(small);
  });

  // gắn chú thích cho các span .term
  document.querySelectorAll('.term').forEach(t => {
    const k = t.dataset.term;
    if(GLOSSARY[k]) t.dataset.tip = GLOSSARY[k];
  });
}

function renderFaq(){
  const wrap = document.getElementById('faq-list');
  wrap.innerHTML = '';
  FAQ.forEach(({q,a}) => {
    const d = document.createElement('details');
    d.innerHTML = `<summary>${q}</summary><p>${a}</p>`;
    wrap.appendChild(d);
  });
}

// ---------- Bộ máy bài kiểm tra ----------
function renderQuiz(moduleId, questions, mountEl, onComplete){
  let idx = 0, score = 0;
  function step(){
    if(idx >= questions.length){
      const passed = score >= Math.ceil(questions.length * 0.66);
      mountEl.innerHTML = `<div class="quiz-result ${passed?'pass':'fail'}">
        ${passed?'✅ Đã đạt':'❌ Thử lại nhé'} — ${score} / ${questions.length}
      </div>
      <button class="primary-btn" id="retry-${moduleId}">Làm lại bài kiểm tra</button>`;
      mountEl.querySelector('#retry-'+moduleId).onclick = () => renderQuiz(moduleId, questions, mountEl, onComplete);
      if(passed) onComplete(score);
      return;
    }
    const Q = questions[idx];
    mountEl.innerHTML = `
      <div class="q-num muted">Câu hỏi ${idx+1} / ${questions.length}</div>
      <div class="q-text">${Q.q}</div>
      <div class="choices"></div>
      <div class="feedback" style="display:none"></div>
      <button class="primary-btn next-btn" style="display:none;margin-top:10px">Tiếp →</button>
    `;
    const choicesEl = mountEl.querySelector('.choices');
    const fb = mountEl.querySelector('.feedback');
    const next = mountEl.querySelector('.next-btn');

    Q.choices.forEach((c,i) => {
      const btn = document.createElement('button');
      btn.className = 'choice';
      btn.textContent = c;
      btn.onclick = () => {
        Array.from(choicesEl.children).forEach(b => b.disabled = true);
        if(i === Q.answer){
          btn.classList.add('correct');
          score++;
          fb.innerHTML = `<b style="color:var(--success)">Chính xác.</b> ${Q.explain}`;
        }else{
          btn.classList.add('wrong');
          choicesEl.children[Q.answer].classList.add('correct');
          fb.innerHTML = `<b style="color:var(--danger)">Chưa đúng rồi.</b> ${Q.explain}`;
        }
        fb.style.display = 'block';
        next.style.display = 'inline-block';
      };
      choicesEl.appendChild(btn);
    });
    next.onclick = () => { idx++; step(); };
  }
  step();
}

function attachQuizzes(){
  document.querySelectorAll('.quiz').forEach(card => {
    const id = card.dataset.quiz;
    const body = card.querySelector('.quiz-body');
    renderQuiz(id, QUIZ_DATA[id], body, score => {
      const prev = progress[id].score || 0;
      if(score > prev) progress[id].score = score;
      if(!progress[id].done){
        progress[id].done = true;
        save(); render();
        toast(`🎉 Đã hoàn thành mô-đun ${id}!`);
      }else{ save(); render(); }
    });
  });
}

// ============================================================
// Tiện ích của từng mô-đun
// ============================================================

// ----- Qubits: bật/tắt Bloch -----
function initQubits(){
  const arrow = document.getElementById('bloch-arrow');
  const explain = document.getElementById('bloch-explain');
  const setActive = el => document.querySelectorAll('.state-btn').forEach(b => b.classList.toggle('active', b===el));
  document.querySelectorAll('.state-btn').forEach(btn => {
    btn.onclick = () => {
      setActive(btn);
      arrow.classList.remove('spin');
      const s = btn.dataset.state;
      if(s==='0'){
        arrow.style.transform='translate(-50%,-100%) rotate(0deg)';
        explain.textContent='Trạng thái thuần |0⟩ — mũi tên chỉ lên trên. Khi đo luôn nhận được 0.';
      } else if(s==='1'){
        arrow.style.transform='translate(-50%,-100%) rotate(180deg)';
        explain.textContent='Trạng thái thuần |1⟩ — mũi tên chỉ xuống dưới. Khi đo luôn nhận được 1.';
      } else {
        arrow.style.transform='translate(-50%,-100%) rotate(90deg)';
        explain.textContent='Chồng chập đều — mũi tên quét quanh đường xích đạo. Khi đo: 50/50.';
        arrow.classList.add('spin');
      }
    };
  });
}

// ----- Bloch Sphere (3D, interactive) -----
function initBloch(){
  let theta = 0;     // polar from |0⟩, 0..π
  let phi   = 0;     // azimuth, 0..2π
  let viewX = -22;   // current view rotation in degrees
  let viewY = -30;
  const R = 120;     // px, sphere radius for vector

  const cube  = document.getElementById('bloch-cube');
  const tEl   = document.getElementById('bloch-theta');
  const pEl   = document.getElementById('bloch-phi');
  const tV    = document.getElementById('bloch-theta-v');
  const pV    = document.getElementById('bloch-phi-v');
  const vec   = document.getElementById('bloch-vec');
  const tip   = document.getElementById('bloch-tip');
  const stEl  = document.getElementById('bloch-state');
  if(!cube) return;

  // Complex helpers
  const c     = (re, im=0) => [re, im];
  const cAdd  = (a, b) => [a[0]+b[0], a[1]+b[1]];
  const cMul  = (a, b) => [a[0]*b[0]-a[1]*b[1], a[0]*b[1]+a[1]*b[0]];
  const cAbs  = (z) => Math.hypot(z[0], z[1]);
  const cArg  = (z) => Math.atan2(z[1], z[0]);

  const I = c(1), Z0 = c(0);
  const GATES = {
    X: [[Z0, c(1)], [c(1), Z0]],
    Y: [[Z0, c(0,-1)], [c(0,1), Z0]],
    Z: [[I, Z0], [Z0, c(-1)]],
    H: (() => { const s = 1/Math.SQRT2; return [[c(s),c(s)],[c(s),c(-s)]]; })(),
    S: [[I, Z0], [Z0, c(0,1)]],
    T: [[I, Z0], [Z0, c(Math.cos(Math.PI/4), Math.sin(Math.PI/4))]],
  };

  function update(){
    // Display angle text
    const tDeg = theta * 180 / Math.PI;
    const pDeg = phi   * 180 / Math.PI;
    tV.textContent = tDeg.toFixed(0);
    pV.textContent = pDeg.toFixed(0);
    tEl.value = tDeg.toFixed(0);
    pEl.value = pDeg.toFixed(0);

    // Tip position in CSS coords (physics x → css x; physics y → css z; physics z → −css y).
    const sx =  R * Math.sin(theta) * Math.cos(phi);
    const sy = -R * Math.cos(theta);
    const sz =  R * Math.sin(theta) * Math.sin(phi);
    tip.style.transform = `translate3d(${sx}px, ${sy}px, ${sz}px)`;

    // Vector orientation: rotateY(−φ) then rotateZ(θ−π/2). Length R.
    vec.style.transform = `rotateY(${-phi}rad) rotateZ(${theta - Math.PI/2}rad)`;

    // Dirac notation — coefficients can be negative when θ ∈ (360°, 720°), so show signs.
    const cT = Math.cos(theta/2), sT = Math.sin(theta/2);
    const aSign = cT < 0 ? '−' : '';
    const bSign = sT < 0 ? '− ' : '+ ';
    const aAbs  = Math.abs(cT).toFixed(3);
    const bAbs  = Math.abs(sT).toFixed(3);
    const phaseStr = (Math.abs(phi) < 1e-3 || Math.abs(sT) < 1e-6)
      ? ''
      : ` · e<sup>i·${pDeg.toFixed(0)}°</sup>`;

    // Spinor cycle: the state acquires a global −1 between θ = 360° and 720°.
    const inSpinor = (theta > 2*Math.PI - 1e-3) && (theta < 4*Math.PI - 1e-3);
    const spinorLine = inSpinor
      ? `<div style="margin-top:8px;font-size:.82rem;color:var(--accent-3);background:rgba(236,72,153,.08);border:1px solid rgba(236,72,153,.3);padding:6px 10px;border-radius:6px">⚡ <b>Vùng spinor.</b> Vector Bloch chỉ cùng hướng như khi θ = ${(tDeg-360).toFixed(0)}°, nhưng trạng thái đã nhận thêm một pha toàn cục −1. Kéo hết đến 720° để lấy lại |ψ⟩.</div>`
      : '';

    stEl.innerHTML = `
      <span class="label">Trạng thái |ψ⟩</span>
      <div class="eq">|ψ⟩ = ${aSign}<span class="alpha">${aAbs}</span>·|0⟩ ${bSign}<span class="beta">${bAbs}${phaseStr}</span>·|1⟩</div>
      <span class="approx">θ = ${tDeg.toFixed(0)}°, &nbsp; φ = ${pDeg.toFixed(0)}°
        &nbsp;·&nbsp; |α|² = ${(cT*cT*100).toFixed(1)}%, &nbsp; |β|² = ${(sT*sT*100).toFixed(1)}%</span>
      ${spinorLine}`;
  }

  function applyView(){
    cube.style.transform = `rotateX(${viewX}deg) rotateY(${viewY}deg)`;
  }

  function applyGate(M){
    // Current state ψ = [cos(θ/2), e^(iφ) sin(θ/2)]
    const cT = Math.cos(theta/2), sT = Math.sin(theta/2);
    const psi = [
      [cT, 0],
      [Math.cos(phi)*sT, Math.sin(phi)*sT],
    ];
    const out = [
      cAdd(cMul(M[0][0], psi[0]), cMul(M[0][1], psi[1])),
      cAdd(cMul(M[1][0], psi[0]), cMul(M[1][1], psi[1])),
    ];
    // Recover (θ, φ) modulo a global phase.
    const m0 = cAbs(out[0]);
    const m1 = cAbs(out[1]);
    theta = 2 * Math.atan2(m1, m0);
    if(m0 < 1e-9){
      phi = ((cArg(out[1]) % (2*Math.PI)) + 2*Math.PI) % (2*Math.PI);
    } else {
      const dphi = cArg(out[1]) - cArg(out[0]);
      phi = ((dphi % (2*Math.PI)) + 2*Math.PI) % (2*Math.PI);
    }
    update();
  }

  function setPreset(name){
    switch(name){
      case '0':  theta = 0;          phi = 0; break;
      case '1':  theta = Math.PI;    phi = 0; break;
      case '+':  theta = Math.PI/2;  phi = 0; break;
      case '-':  theta = Math.PI/2;  phi = Math.PI; break;
      case 'i':  theta = Math.PI/2;  phi = Math.PI/2; break;
      case '-i': theta = Math.PI/2;  phi = 3*Math.PI/2; break;
    }
    update();
  }

  tEl.oninput = () => { theta = +tEl.value * Math.PI/180; update(); };
  pEl.oninput = () => { phi   = +pEl.value * Math.PI/180; update(); };

  document.querySelectorAll('#bloch .bloch-gate').forEach(b => {
    b.onclick = () => {
      if(b.dataset.gate)   applyGate(GATES[b.dataset.gate]);
      if(b.dataset.preset) setPreset(b.dataset.preset);
    };
  });

  // Drag to rotate view
  let dragging = false, lastX = 0, lastY = 0;
  cube.addEventListener('pointerdown', (e) => {
    dragging = true; lastX = e.clientX; lastY = e.clientY;
    cube.setPointerCapture(e.pointerId);
  });
  cube.addEventListener('pointermove', (e) => {
    if(!dragging) return;
    const dx = e.clientX - lastX, dy = e.clientY - lastY;
    viewY += dx * 0.5;
    viewX -= dy * 0.5;
    viewX = Math.max(-85, Math.min(85, viewX));
    lastX = e.clientX; lastY = e.clientY;
    applyView();
  });
  cube.addEventListener('pointerup',   () => { dragging = false; });
  cube.addEventListener('pointercancel',() => { dragging = false; });

  applyView();
  update();
}

// ----- Superposition: slider + bars + wave -----
function initSuperposition(){
  const slider = document.getElementById('sp-slider');
  const p0=document.getElementById('sp-p0'), p1=document.getElementById('sp-p1');
  const b0=document.getElementById('sp-bar0'), b1=document.getElementById('sp-bar1');
  const dirac = document.getElementById('sp-dirac');
  const cv = document.getElementById('sp-wave'); const ctx = cv.getContext('2d');

  // Render Dirac notation:  |ψ⟩ = α|0⟩ + β|1⟩, where α=√P(0), β=√P(1).
  // Pretty-prints familiar fractions (1/√2, 1, 0) and shows decimal approximations.
  const FRAC_1_SQRT2 = '<span class="frac"><span class="num">1</span><span class="den">√2</span></span>';
  function prettyAmp(p){
    if(p === 0) return '0';
    if(p === 100) return '1';
    if(p === 50) return FRAC_1_SQRT2;
    return `√<span style="font-style:normal">${(p/100).toFixed(2)}</span>`;
  }
  function renderDirac(p1pct){
    const p0pct = 100 - p1pct;
    const a = Math.sqrt(p0pct/100);
    const b = Math.sqrt(p1pct/100);
    const aStr = prettyAmp(p0pct);
    const bStr = prettyAmp(p1pct);

    // build expression, hiding zero terms cleanly
    let main;
    if(p0pct === 0)      main = `<span class="beta">${bStr}</span><span class="ket">|1⟩</span>`;
    else if(p1pct === 0) main = `<span class="alpha">${aStr}</span><span class="ket">|0⟩</span>`;
    else
      main = `<span class="alpha">${aStr}</span><span class="ket">|0⟩</span> + ` +
             `<span class="beta">${bStr}</span><span class="ket">|1⟩</span>`;

    dirac.innerHTML = `
      <span class="label">Ký hiệu Dirac</span>
      <div class="eq">|ψ⟩ = ${main}</div>
      <span class="approx">≈ ${a.toFixed(3)} |0⟩ + ${b.toFixed(3)} |1⟩
        &nbsp;·&nbsp; |α|² = ${(p0pct).toFixed(0)}%, &nbsp; |β|² = ${(p1pct).toFixed(0)}%</span>`;
  }

  function update(){
    const v = +slider.value;          // probability of 1 in %
    p1.textContent = v; p0.textContent = 100-v;
    b0.style.width = (100-v)+'%';
    b1.style.width = v + '%';
    renderDirac(v);
  }
  slider.oninput = update; update();

  // animated wave
  let t = 0;
  function frame(){
    const w = cv.width = cv.clientWidth, h = cv.height;
    ctx.clearRect(0,0,w,h);
    const v = +slider.value/100;
    const ampMix = Math.sin(Math.PI * v);  // peak at 50%
    ctx.lineWidth = 2;
    // |0> wave (cyan)
    ctx.strokeStyle = 'rgba(6,182,212,.85)';
    ctx.beginPath();
    for(let x=0;x<w;x++){
      const y = h/2 + Math.sin((x*0.04)+t) * (h/3) * (1-v);
      x===0 ? ctx.moveTo(x,y) : ctx.lineTo(x,y);
    }
    ctx.stroke();
    // |1> wave (pink)
    ctx.strokeStyle = 'rgba(236,72,153,.85)';
    ctx.beginPath();
    for(let x=0;x<w;x++){
      const y = h/2 + Math.cos((x*0.04)+t*1.3) * (h/3) * v;
      x===0 ? ctx.moveTo(x,y) : ctx.lineTo(x,y);
    }
    ctx.stroke();
    // mix glow
    ctx.fillStyle = `rgba(124,58,237,${0.04 + 0.18*ampMix})`;
    ctx.fillRect(0,0,w,h);
    t += 0.06;
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
}

// ----- Entanglement -----
function initEntanglement(){
  const a = document.getElementById('qa'), b = document.getElementById('qb');
  const av = a.querySelector('.qval'), bv = b.querySelector('.qval');
  const msg = document.getElementById('ent-msg');
  const formula = document.getElementById('ent-formula');
  const ampsEl = document.getElementById('ent-amps');
  const note = document.getElementById('ent-note');

  // amplitudes for the four 2-qubit basis states  |00>, |01>, |10>, |11>
  const labels = ['|00⟩','|01⟩','|10⟩','|11⟩'];

  function renderState(amps){
    ampsEl.innerHTML = '';
    amps.forEach((amp, i) => {
      const p = amp*amp;
      const row = document.createElement('div');
      row.className = 'sv-row' + (Math.abs(amp) < 1e-6 ? ' zero' : '');
      row.innerHTML = `
        <span class="sv-label">${labels[i]}</span>
        <div class="sv-bar"><div style="width:${(p*100).toFixed(0)}%"></div></div>
        <span class="sv-amp">${formatAmp(amp)}</span>`;
      ampsEl.appendChild(row);
    });
  }

  function formatAmp(a){
    if(Math.abs(a) < 1e-6) return '0';
    if(Math.abs(a - 1) < 1e-6) return '1';
    if(Math.abs(a - 1/Math.SQRT2) < 1e-6) return F12;
    if(Math.abs(a + 1/Math.SQRT2) < 1e-6) return '−' + F12;
    return a.toFixed(3);
  }

  const F12 = '<span class="frac"><span class="num">1</span><span class="den">√2</span></span>';

  function setBell(){
    av.textContent = '?'; bv.textContent = '?';
    a.classList.remove('measured'); b.classList.remove('measured');
    formula.innerHTML = `|Φ⁺⟩ = ${F12}·|00⟩ + ${F12}·|11⟩`;
    note.textContent = 'Một chồng chập đều của |00⟩ và |11⟩. Hãy để ý |01⟩ và |10⟩ có biên độ bằng 0 — hai qubit tương quan hoàn hảo với nhau, không bao giờ ngược nhau.';
    renderState([1/Math.SQRT2, 0, 0, 1/Math.SQRT2]);
    msg.textContent = 'Cặp qubit đã rối lượng tử. Nhấn “Measure A” để sụp đổ trạng thái.';
  }

  function collapse(r){
    av.textContent = r; bv.textContent = r;
    a.classList.add('measured'); b.classList.add('measured');
    if(r === '0'){
      formula.innerHTML = '|00⟩  (đã sụp đổ)';
      note.textContent = 'Phép đo đã chiếu trạng thái về |00⟩. Cả hai qubit đều đọc ra 0 — từ giờ mỗi lần đo lại, bạn luôn nhận được 0.';
      renderState([1, 0, 0, 0]);
    } else {
      formula.innerHTML = '|11⟩  (đã sụp đổ)';
      note.textContent = 'Phép đo đã chiếu trạng thái về |11⟩. Cả hai qubit đều đọc ra 1 — sự rối lượng tử đã bị phép đo “dùng hết”.';
      renderState([0, 0, 0, 1]);
    }
    msg.textContent = `Cả hai đều sụp đổ về ${r}. Trạng thái Bell |Φ⁺⟩ luôn có tương quan khớp nhau.`;
  }

  document.getElementById('ent-measure').onclick = () =>
    collapse(Math.random() < 0.5 ? '0' : '1');
  document.getElementById('ent-reset').onclick = setBell;

  setBell();
}

// ----- Phase Kickback -----
function initKickback(){
  // Index convention for the 4-amp vector:  index = 2·c + t   (c = control, t = target)
  // Cases: target ∈ {|0⟩, |1⟩, |+⟩, |−⟩}.  Control starts |+⟩ = (|0⟩+|1⟩)/√2.
  const S = 1/Math.SQRT2;
  const KB = {
    '0': {
      initLabel:  '|+⟩ ⊗ |0⟩',
      init:       [S, 0, S, 0],
      finalLabel: '<span class="frac"><span class="num">|00⟩ + |11⟩</span><span class="den">√2</span></span>  =  |Φ⁺⟩',
      final:      [S, 0, 0, S],
      cls:        'entangle',
      verdict:    'Không có bắn ngược rõ ràng. Target |0⟩ không phải trạng thái riêng của X (phép toán mà CNOT áp dụng), nên hai qubit bị rối lượng tử thành trạng thái Bell |Φ⁺⟩.'
    },
    '1': {
      initLabel:  '|+⟩ ⊗ |1⟩',
      init:       [0, S, 0, S],
      finalLabel: '<span class="frac"><span class="num">|01⟩ + |10⟩</span><span class="den">√2</span></span>  =  |Ψ⁺⟩',
      final:      [0, S, S, 0],
      cls:        'entangle',
      verdict:    'Không có bắn ngược. Target |1⟩ không phải trạng thái riêng của X — hai qubit rối lượng tử thành trạng thái Bell |Ψ⁺⟩.'
    },
    '+': {
      initLabel:  '|+⟩ ⊗ |+⟩',
      init:       [0.5, 0.5, 0.5, 0.5],
      finalLabel: '|+⟩ ⊗ |+⟩',
      final:      [0.5, 0.5, 0.5, 0.5],
      cls:        'identity',
      verdict:    'Bắn ngược với pha +1 (tầm thường). X|+⟩ = +|+⟩, nên pha bắn ngược là +1 — không có gì thay đổi nhìn thấy được.'
    },
    '-': {
      initLabel:  '|+⟩ ⊗ |−⟩',
      init:       [0.5, -0.5, 0.5, -0.5],
      finalLabel: '|−⟩ ⊗ |−⟩',
      final:      [0.5, -0.5, -0.5, 0.5],
      cls:        'kick',
      verdict:    '✨ Bắn ngược pha! X|−⟩ = −|−⟩, nên một pha −1 bị bắn sang nhánh |1⟩ của qubit điều khiển. Qubit điều khiển lật |+⟩ → |−⟩ — target không đổi, thế nhưng chính "qubit điều khiển" lại là thứ đã thay đổi.'
    },
  };
  const labels = ['|00⟩','|01⟩','|10⟩','|11⟩'];

  const initEl  = document.getElementById('kb-init');
  const finalEl = document.getElementById('kb-final');
  const initAmps  = document.getElementById('kb-init-amps');
  const finalAmps = document.getElementById('kb-final-amps');
  const verdict   = document.getElementById('kb-verdict');

  const F12 = '<span class="frac"><span class="num">1</span><span class="den">√2</span></span>';
  const F1_2 = '<span class="frac"><span class="num">1</span><span class="den">2</span></span>';
  function fmt(a){
    if(Math.abs(a) < 1e-6) return '0';
    if(Math.abs(a - 1) < 1e-6) return '1';
    if(Math.abs(a + 1) < 1e-6) return '−1';
    if(Math.abs(a - S) < 1e-6) return F12;
    if(Math.abs(a + S) < 1e-6) return '−' + F12;
    if(Math.abs(a - 0.5) < 1e-6) return F1_2;
    if(Math.abs(a + 0.5) < 1e-6) return '−' + F1_2;
    return a.toFixed(3);
  }

  function renderAmps(host, vec){
    host.innerHTML = '';
    vec.forEach((a, i) => {
      const p = a*a;
      const row = document.createElement('div');
      row.className = 'sv-row' + (Math.abs(a) < 1e-6 ? ' zero' : '');
      row.innerHTML = `
        <span class="sv-label">${labels[i]}</span>
        <div class="sv-bar"><div style="width:${(p*100).toFixed(0)}%"></div></div>
        <span class="sv-amp">${fmt(a)}</span>`;
      host.appendChild(row);
    });
  }

  function show(stateKey){
    const c = KB[stateKey];
    initEl.innerHTML = c.initLabel;
    finalEl.innerHTML = c.finalLabel;
    renderAmps(initAmps, c.init);
    renderAmps(finalAmps, c.final);
    verdict.className = 'kb-verdict ' + c.cls;
    verdict.textContent = c.verdict;
    document.querySelectorAll('.kb-target').forEach(b =>
      b.classList.toggle('active', b.dataset.state === stateKey));
  }

  document.querySelectorAll('.kb-target').forEach(b =>
    b.onclick = () => show(b.dataset.state));

  show('-');
}

// ----- Quantum Paradoxes -----
function initParadox(){
  // Tab switching
  document.querySelectorAll('.pdx-tab').forEach(b => {
    b.onclick = () => {
      document.querySelectorAll('.pdx-tab').forEach(x => x.classList.toggle('active', x===b));
      document.querySelectorAll('.pdx-panel').forEach(p => p.classList.add('hidden'));
      const panel = document.getElementById('pdx-' + b.dataset.pdx);
      if(panel) panel.classList.remove('hidden');
    };
  });

  // -------- Schrödinger's Cat --------
  (() => {
    const box = document.getElementById('cat-box');
    const lbl = document.getElementById('cat-label');
    const msg = document.getElementById('cat-msg');
    const time = document.getElementById('cat-time');
    const timeV = document.getElementById('cat-time-v');

    function update(){
      const p = +time.value;
      timeV.textContent = p;
      if(box.classList.contains('opened')) return;
      const a = Math.sqrt((100-p)/100), b = Math.sqrt(p/100);
      lbl.innerHTML = `${a.toFixed(2)}·|còn sống⟩ + ${b.toFixed(2)}·|đã chết⟩`;
      msg.textContent = p === 0  ? 'Chưa có thời gian trôi qua — con mèo chắc chắn còn sống (không thể phân rã).'
                       : p === 100 ? 'Chắc chắn đã phân rã — con mèo đã chết (không cần chồng chập).'
                       : `Hộp đang đóng. Con mèo ở trạng thái chồng chập: ${(100-p)}% biên độ² còn sống, ${p}% đã chết.`;
    }
    time.oninput = update;

    document.getElementById('cat-open').onclick = () => {
      const p = +time.value / 100;
      const dead = Math.random() < p;
      box.classList.remove('closed');
      box.classList.add('opened', dead ? 'dead' : 'alive');
      lbl.innerHTML = dead ? '|đã chết⟩  (đã sụp đổ)' : '|còn sống⟩  (đã sụp đổ)';
      msg.textContent = dead
        ? '☠ Con mèo sụp đổ về |đã chết⟩. Nguyên tử đã phân rã.'
        : '😺 Con mèo sụp đổ về |còn sống⟩. Nguyên tử chưa phân rã.';
    };
    document.getElementById('cat-reset').onclick = () => {
      box.classList.remove('opened','alive','dead');
      box.classList.add('closed');
      update();
    };
    update();
  })();

  // -------- Wigner's Friend --------
  (() => {
    const friendEl = document.getElementById('wig-friend');
    const wignerEl = document.getElementById('wig-wigner');
    const msg      = document.getElementById('wig-msg');
    let stage = 0, friendOutcome = null;

    function setState(s){
      stage = s;
      if(s === 0){
        friendEl.textContent = '|+⟩ — chồng chập';
        wignerEl.textContent = '(qubit ⊗ Friend) ở trạng thái |+⟩ ⊗ |trung tính⟩';
        msg.innerHTML = 'Ban đầu: qubit ở trạng thái <b>|+⟩ = (|0⟩+|1⟩)/√2</b>. Cả hai người quan sát đều mô tả nó giống hệt nhau.';
        document.querySelectorAll('.wig-actor').forEach(a => a.classList.remove('measured'));
      } else if(s === 1){
        friendOutcome = Math.random() < 0.5 ? 0 : 1;
        friendEl.innerHTML = `|${friendOutcome}⟩ &nbsp;<span style="color:var(--muted)">(Tôi đã thấy một kết quả xác định!)</span>`;
        wignerEl.innerHTML = `<span style="color:var(--accent-3)">(|0⟩|thấy-0⟩ + |1⟩|thấy-1⟩)/√2</span><br><small style="color:var(--muted)">Friend &amp; qubit rối lượng tử với nhau</small>`;
        document.querySelectorAll('.wig-actor')[0].classList.add('measured');
        msg.innerHTML = `<b>Nghịch lý.</b> Friend nói: "Tôi đã đo được ${friendOutcome}, qubit đã sụp đổ." Nhưng Wigner — ở bên ngoài phòng thí nghiệm — không có cách nào biết rằng đã có sự sụp đổ. Với anh ấy, Friend + qubit lúc này đang ở một trạng thái chồng chập của hai qubit. Hai cách mô tả đều đúng cho cùng một sự kiện.`;
      } else if(s === 2){
        wignerEl.innerHTML = `|${friendOutcome}⟩ &nbsp;<span style="color:var(--muted)">(Tôi thấy cùng một đáp án)</span>`;
        document.querySelectorAll('.wig-actor')[1].classList.add('measured');
        msg.innerHTML = `Cuối cùng Wigner đo toàn bộ phòng thí nghiệm. Anh ấy nhận được ${friendOutcome}, khớp với Friend. Hai cách nhìn cuối cùng hòa hợp với nhau — nhưng chỉ là hồi cố, và chỉ vì Wigner tin rằng ghi chép của Friend là đúng.`;
      }
    }

    document.getElementById('wig-step1').onclick = () => stage === 0 && setState(1);
    document.getElementById('wig-step2').onclick = () => stage === 1 && setState(2);
    document.getElementById('wig-reset').onclick = () => setState(0);
    setState(0);
  })();

  // -------- Double-Slit (Wave-Particle Duality) --------
  (() => {
    const detEl = document.getElementById('ds-detector');
    const cv    = document.getElementById('ds-screen');
    const msg   = document.getElementById('ds-msg');
    const icon  = document.getElementById('ds-det-icon');
    if(!cv) return;
    const ctx   = cv.getContext('2d');
    let hits = [];

    function clear(){
      hits = []; draw();
      msg.textContent = 'Đã xóa màn hình. Nhấn "Send" để bắn photon.';
    }

    function draw(){
      const w = cv.width = cv.clientWidth, h = cv.height;
      ctx.clearRect(0,0,w,h);
      ctx.fillStyle = 'rgba(168,85,247,.04)';
      ctx.fillRect(0,0,w,h);
      // Histogram
      const BINS = 64;
      const bins = new Array(BINS).fill(0);
      hits.forEach(p => bins[Math.min(BINS-1, Math.max(0, Math.floor(p.x*BINS)))]++);
      const max = Math.max(1, ...bins);
      const bw = w / BINS;
      ctx.fillStyle = 'rgba(124,58,237,.55)';
      bins.forEach((c, i) => {
        const bh = (c/max) * (h * 0.5);
        ctx.fillRect(i*bw, h - bh, bw - 0.5, bh);
      });
      // Individual photon dots in the upper band
      ctx.fillStyle = 'rgba(168,85,247,.95)';
      hits.forEach(p => {
        ctx.beginPath();
        ctx.arc(p.x*w, p.y, 2, 0, Math.PI*2);
        ctx.fill();
      });
      // Top label
      ctx.fillStyle = '#8b93a7';
      ctx.font = '11px system-ui';
      ctx.fillText(`${hits.length} photon${hits.length===1?'':'s'}`, 10, 16);
    }

    function sample(detector){
      // Photon-screen position x ∈ [0,1].
      if(!detector){
        // Wave behaviour: cos²(5πx) interference pattern (rejection sampling).
        for(let i=0;i<200;i++){
          const x = Math.random();
          if(Math.random() < Math.cos(5*Math.PI*x)**2) return x;
        }
        return Math.random();
      } else {
        // Particle behaviour: 50/50 between two slit-centred Gaussians.
        const slit = Math.random() < 0.5 ? 0.35 : 0.65;
        const g = slit + (Math.random()+Math.random()+Math.random()-1.5) * 0.07;
        return Math.min(0.99, Math.max(0.01, g));
      }
    }

    function shoot(n){
      const det = detEl.checked;
      const h = cv.height;
      for(let i=0;i<n;i++){
        const x = sample(det);
        const y = h*0.18 + Math.random() * (h*0.25);
        hits.push({x, y});
      }
      draw();
      const total = hits.length;
      msg.innerHTML = det
        ? `Đã bắn ${n} photon với detector BẬT (nhòm vào khe A). Sau tổng cộng ${total} photon → <b>hai vệt đậm</b> tương ứng với hai khe. Không có giao thoa. Photon hành xử như <b>hạt</b>.`
        : `Đã bắn ${n} photon với detector TẮT. Sau tổng cộng ${total} photon → <b>các dải giao thoa</b> xuất hiện (mẫu cos²). Từng photon tự giao thoa với chính mình như một <b>sóng</b>.`;
    }

    document.getElementById('ds-shoot1').onclick  = () => shoot(1);
    document.getElementById('ds-shootN').onclick  = () => shoot(200);
    document.getElementById('ds-clear').onclick   = clear;

    detEl.onchange = () => {
      icon.classList.toggle('active', detEl.checked);
      msg.innerHTML = detEl.checked
        ? '👁 Detector BẬT — việc đo photon đi qua khe nào buộc photon phải hành xử như hạt. Dữ liệu cũ trên màn hình được giữ nguyên; các photon mới sẽ rơi thành hai vệt đậm.'
        : '🌊 Detector TẮT — không đo đường đi. Các photon tự giao thoa với chính mình và tạo thành mẫu sóng.';
    };

    window.addEventListener('resize', draw);
    clear();
  })();

  // -------- Quantum Eraser --------
  (() => {
    const detEl = document.getElementById('er-detector');
    const eraEl = document.getElementById('er-eraser');
    const cv    = document.getElementById('er-screen');
    const ctx   = cv.getContext('2d');
    const msg   = document.getElementById('er-msg');
    let hits = [];

    function clear(){ hits = []; draw(); }
    function draw(){
      const w = cv.width = cv.clientWidth, h = cv.height;
      ctx.clearRect(0,0,w,h);
      // backdrop
      ctx.fillStyle = 'rgba(124,58,237,.05)'; ctx.fillRect(0,0,w,h);
      // bin into histogram
      const BINS = 60;
      const bins = new Array(BINS).fill(0);
      hits.forEach(x => bins[Math.min(BINS-1, Math.max(0, Math.floor(x*BINS)))]++);
      const max = Math.max(1, ...bins);
      const bw = w / BINS;
      bins.forEach((c, i) => {
        const bh = (c/max) * (h - 20);
        ctx.fillStyle = '#06b6d4';
        ctx.fillRect(i*bw, h - bh, bw - 1, bh);
      });
      // recent hits as dots
      ctx.fillStyle = 'rgba(255,255,255,.5)';
      hits.slice(-20).forEach(x => {
        ctx.beginPath();
        ctx.arc(x*w, h - 6, 2, 0, Math.PI*2);
        ctx.fill();
      });
    }

    function sample(detector, eraser){
      const interfering = !detector || (detector && eraser);
      if(interfering){
        // P(x) ∝ cos²(5πx) on x ∈ [0,1] — rejection sampling
        for(let i=0;i<200;i++){
          const x = Math.random();
          const p = Math.cos(5*Math.PI*x) ** 2;
          if(Math.random() < p) return x;
        }
        return Math.random();
      } else {
        // No interference: sum of two gaussians (one per slit)
        const slit = Math.random() < 0.5 ? 0.35 : 0.65;
        const g = slit + (Math.random()+Math.random()+Math.random()-1.5) * 0.07;
        return Math.min(0.99, Math.max(0.01, g));
      }
    }

    document.getElementById('er-run').onclick = () => {
      const det = detEl.checked, era = eraEl.checked;
      for(let i=0;i<800;i++) hits.push(sample(det, era));
      draw();
      msg.textContent = !det        ? `Detector OFF → interference fringes (cos² pattern).`
                       : det && era ? `Detector ON, eraser ON → fringes restored. The which-path information was washed out.`
                       :              `Detector ON, no eraser → no fringes. Two clumps from the two slits.`;
    };
    document.getElementById('er-clear').onclick = clear;
    window.addEventListener('resize', draw);
    clear();
  })();

  // -------- Delayed-Choice Quantum Eraser --------
  (() => {
    const grid = document.getElementById('dl-grid');
    const msg  = document.getElementById('dl-msg');

    function drawCanvas(host, samples){
      const cv = document.createElement('canvas');
      cv.className = 'dl-canvas';
      host.appendChild(cv);
      const w = cv.width = host.clientWidth - 24, h = cv.height = 80;
      const ctx = cv.getContext('2d');
      const BINS = 50;
      const bins = new Array(BINS).fill(0);
      samples.forEach(x => bins[Math.min(BINS-1, Math.max(0, Math.floor(x*BINS)))]++);
      const max = Math.max(1, ...bins);
      const bw = w / BINS;
      ctx.fillStyle = '#7c3aed';
      bins.forEach((c, i) => {
        const bh = (c/max) * h;
        ctx.fillRect(i*bw, h - bh, bw - 1, bh);
      });
    }

    function panel(title, samples, sub){
      const p = document.createElement('div');
      p.className = 'dl-panel';
      p.innerHTML = `<h5>${title}</h5>`;
      grid.appendChild(p);
      drawCanvas(p, samples);
      const note = document.createElement('div');
      note.className = 'muted';
      note.style.fontSize = '.78rem';
      note.style.marginTop = '4px';
      note.textContent = sub;
      p.appendChild(note);
    }

    document.getElementById('dl-run').onclick = () => {
      grid.innerHTML = '';
      // Generate paired data: each photon has a path label and an eraser-outcome label.
      // "Erased+" subset shows cos²; "erased−" shows sin² (shifted pattern).
      const N = 1500;
      const all = [];
      const erasedPlus = [];
      const erasedMinus = [];
      for(let i=0;i<N;i++){
        const which = Math.random() < 0.5 ? 0 : 1;
        const eraseOutcome = Math.random() < 0.5 ? '+' : '-';
        let x;
        if(eraseOutcome === '+'){
          // cos²(5πx)
          for(let k=0;k<200;k++){ const t = Math.random(); if(Math.random() < Math.cos(5*Math.PI*t)**2){ x=t; break; } }
          erasedPlus.push(x);
        } else {
          // sin²(5πx) — shifted fringes
          for(let k=0;k<200;k++){ const t = Math.random(); if(Math.random() < Math.sin(5*Math.PI*t)**2){ x=t; break; } }
          erasedMinus.push(x);
        }
        if(x === undefined) x = Math.random();
        all.push(x);
      }
      panel('All photons (raw screen)', all, 'No fringes — interference appears washed out.');
      panel('Subset: eraser outcome "+"', erasedPlus, 'Conditioning on later "+" reveals cos² fringes.');
      panel('Subset: eraser outcome "−"', erasedMinus, 'The "−" subset shows complementary fringes (shifted by π).');
      msg.innerHTML = `<b>The trick:</b> the raw screen looks fringe-free. The "delayed choice" doesn't physically alter past photons — it labels them. Sorting the data on the eraser outcome <i>reveals</i> two fringe patterns that were always hidden in the data, summing to the smeared-out total.`;
    };
  })();

  // -------- Quantum Zeno --------
  (() => {
    const slider = document.getElementById('zeno-int');
    const lbl    = document.getElementById('zeno-int-v');
    const cv     = document.getElementById('zeno-canvas');
    const ctx    = cv.getContext('2d');
    const msg    = document.getElementById('zeno-msg');
    slider.oninput = () => lbl.textContent = slider.value;

    function run(){
      const TOTAL = 60;
      const interval = +slider.value;
      const dθ = Math.PI / TOTAL; // would reach |1⟩ after TOTAL steps unmeasured

      const trajectory = [];
      let angle = 0, decayed = false;
      for(let i=1;i<=TOTAL;i++){
        angle += dθ;
        if(i % interval === 0){
          const p1 = Math.sin(angle/2)**2;
          if(Math.random() < p1){
            trajectory.push({i, p:1, m:true, dec:true}); decayed = true; break;
          } else {
            trajectory.push({i, p:0, m:true, dec:false});
            angle = 0; // collapsed to |0⟩
          }
        } else {
          trajectory.push({i, p:Math.sin(angle/2)**2, m:false, dec:false});
        }
      }

      // draw
      const w = cv.width = cv.clientWidth, h = cv.height;
      ctx.clearRect(0,0,w,h);
      // axes
      ctx.strokeStyle = 'rgba(255,255,255,.15)'; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(40, 10); ctx.lineTo(40, h-26); ctx.lineTo(w-10, h-26); ctx.stroke();
      ctx.fillStyle = 'var(--muted)'; ctx.font = '11px system-ui';
      ctx.fillStyle = '#8b93a7';
      ctx.fillText('P(|1⟩)', 6, 18);
      ctx.fillText('1', 24, 14);
      ctx.fillText('0', 24, h-22);
      ctx.fillText('time →', w-60, h-8);

      // free-evolution reference (no measurements): sin²(i·dθ/2)
      ctx.strokeStyle = 'rgba(124,58,237,.35)';
      ctx.setLineDash([4,4]);
      ctx.beginPath();
      for(let i=0;i<=TOTAL;i++){
        const p = Math.sin(i*dθ/2)**2;
        const x = 40 + (i/TOTAL) * (w-50);
        const y = (h-26) - p*(h-40);
        i===0 ? ctx.moveTo(x,y) : ctx.lineTo(x,y);
      }
      ctx.stroke();
      ctx.setLineDash([]);

      // measured trajectory
      ctx.strokeStyle = '#06b6d4'; ctx.lineWidth = 2;
      ctx.beginPath();
      let prevP = 0;
      ctx.moveTo(40, h-26);
      trajectory.forEach(pt => {
        const x = 40 + (pt.i/TOTAL) * (w-50);
        const y = (h-26) - pt.p*(h-40);
        ctx.lineTo(x, y);
        prevP = pt.p;
      });
      ctx.stroke();
      // measurement markers
      trajectory.forEach(pt => {
        if(!pt.m) return;
        const x = 40 + (pt.i/TOTAL) * (w-50);
        const y = (h-26) - pt.p*(h-40);
        ctx.fillStyle = pt.dec ? '#ef4444' : '#10b981';
        ctx.beginPath(); ctx.arc(x, y, 3, 0, Math.PI*2); ctx.fill();
      });

      msg.innerHTML = decayed
        ? `Qubit decayed at step ${trajectory[trajectory.length-1].i}. Dashed = free evolution; solid cyan = measured trajectory; green dots = "still |0⟩" projections; red dot = first time it was caught in |1⟩.`
        : `Qubit stayed in |0⟩ for the full 60 steps. ✨ The Zeno effect — frequent measurements freeze the evolution. With interval = ${interval} steps, P(decay per check) = sin²(${interval}·π/120) ≈ ${(Math.sin(interval*Math.PI/120)**2*100).toFixed(2)}%.`;
    }

    document.getElementById('zeno-run').onclick = run;
    run();
    window.addEventListener('resize', run);
  })();
}

// ----- Quantum Cryptography (QKD overview + BB84) -----
function initCrypto(){
// Tab switching
  document.querySelectorAll('.qc-tab').forEach(b => {
    b.onclick = () => {
      document.querySelectorAll('.qc-tab').forEach(x => x.classList.toggle('active', x===b));
      document.querySelectorAll('.qc-panel').forEach(p => p.classList.add('hidden'));
      const panel = document.getElementById('qc-' + b.dataset.qc);
      if(panel) panel.classList.remove('hidden');
    };
  });

  const nSlider = document.getElementById('bb-n');
  const nLbl    = document.getElementById('bb-n-v');
  const eveBox  = document.getElementById('bb-eve');
  const tableEl = document.getElementById('bb-table');
  const sumEl   = document.getElementById('bb-summary');
  nSlider.oninput = () => nLbl.textContent = nSlider.value;

  // bit + basis → state symbol
  const stateSym = (bit, bas) => {
    if(bas === 'Z') return bit === 0 ? '|0⟩' : '|1⟩';
    return bit === 0 ? '|+⟩' : '|−⟩';
  };

  function simulate(N, evePresent){
    const rows = [];
    let kept = 0, errs = 0;
    const keyA = [], keyB = [];
    for(let i=0;i<N;i++){
      const aBit = Math.random() < 0.5 ? 0 : 1;
      const aBas = Math.random() < 0.5 ? 'Z' : 'X';
      let chBit = aBit, chBas = aBas, eve = null;
      if(evePresent){
        const eBas = Math.random() < 0.5 ? 'Z' : 'X';
        const eBit = (eBas === aBas) ? aBit : (Math.random() < 0.5 ? 0 : 1);
        eve = {bit:eBit, bas:eBas};
        chBit = eBit; chBas = eBas;        // Eve resends in her basis with her result
      }
      const bBas = Math.random() < 0.5 ? 'Z' : 'X';
      const bBit = (bBas === chBas) ? chBit : (Math.random() < 0.5 ? 0 : 1);
      const match = (bBas === aBas);
      const error = match && (aBit !== bBit);
      if(match){ kept++; keyA.push(aBit); keyB.push(bBit); if(error) errs++; }
      rows.push({i, aBit, aBas, eve, bBas, bBit, match, error});
    }
    return {rows, kept, errs, keyA, keyB};
  }

  function render(N, evePresent){
    const {rows, kept, errs, keyA, keyB} = simulate(N, evePresent);
    tableEl.innerHTML = '';

    // header
    const cols = evePresent
      ? ['#','Bit A','Cơ sở A','Qubit','Cơ sở Eve','Bit Eve','Cơ sở B','Bit B','Trạng thái']
      : ['#','Bit A','Cơ sở A','Qubit','Cơ sở B','Bit B','Trạng thái'];
    const colTmpl = evePresent
      ? '36px 60px 70px 70px 80px 60px 70px 60px 1fr'
      : '36px 60px 70px 70px 70px 60px 1fr';

    const hdr = document.createElement('div');
    hdr.className = 'bb-row hdr';
    hdr.style.gridTemplateColumns = colTmpl;
    cols.forEach(c => {
      const span = document.createElement('div');
      span.className = 'bb-cell';
      span.textContent = c;
      hdr.appendChild(span);
    });
    tableEl.appendChild(hdr);

    rows.forEach(r => {
      const row = document.createElement('div');
      row.className = 'bb-row ' +
        (r.error ? 'error' : (r.match ? 'match' : 'discard'));
      row.style.gridTemplateColumns = colTmpl;

      const tag = r.error ? '<span class="tag err">✗ LỖI</span>'
                : r.match ? '<span class="tag kept">✓ giữ lại</span>'
                : '<span class="tag">bị loại</span>';

      let html = `
        <div class="bb-cell idx">${r.i + 1}</div>
        <div class="bb-cell bit">${r.aBit}</div>
        <div class="bb-cell"><span class="basis ${r.aBas==='X'?'x':''}">${r.aBas}</span></div>
        <div class="bb-cell"><span class="qubit">${stateSym(r.aBit, r.aBas)}</span></div>`;
      if(evePresent){
        html += `
          <div class="bb-cell"><span class="basis ${r.eve.bas==='X'?'x':''}">${r.eve.bas}</span></div>
          <div class="bb-cell bit">${r.eve.bit}</div>`;
      }
      html += `
        <div class="bb-cell"><span class="basis ${r.bBas==='X'?'x':''}">${r.bBas}</span></div>
        <div class="bb-cell bit">${r.bBit}</div>
        <div class="bb-cell">${tag}</div>`;
      row.innerHTML = html;
      tableEl.appendChild(row);
    });

    // summary
    const errRate = kept ? errs/kept : 0;
    let verdictHTML;
    if(evePresent){
      if(errRate > 0.10){
        verdictHTML = `<div class="bb-verdict danger">🚨 Phát hiện kẻ nghe lén — ${(errRate*100).toFixed(1)}% bit lệch trong khóa đã sàng lọc (cao hơn hẳn ngưỡng nhiễu). Hãy huỷ bỏ và thử lại.</div>`;
      } else if(errs > 0){
        verdictHTML = `<div class="bb-verdict warn">⚠ ${errs} bit lệch (${(errRate*100).toFixed(1)}%). Với nhiều bit hơn, sự can thiệp của Eve sẽ trở nên rõ ràng về mặt thống kê.</div>`;
      } else {
        verdictHTML = `<div class="bb-verdict warn">Eve chỉ gặp may — lần chạy nhỏ này không có bit lệch nào. Với nhiều bit hơn, mức nhiễu ~25% của cô ta sẽ không thể che giấu.</div>`;
      }
    } else {
      verdictHTML = errs === 0
        ? `<div class="bb-verdict safe">✓ Kênh sạch. Khóa đã sàng lọc gồm ${kept} bit — mọi bit được giữ lại đều khớp.</div>`
        : `<div class="bb-verdict danger">Có bit lệch bất thường dù không có Eve — trong một liên kết thực tế, điều này cho thấy nhiễu trên kênh.</div>`;
    }

    const keyStr = keyA.join('');
    sumEl.classList.add('show');
    sumEl.innerHTML = `
      <h4>Tóm tắt giao thức</h4>
      <div class="bb-stat">
        <span>Số bit đã gửi:</span>
        <div class="bb-stat-bar"><div class="bb-stat-fill good" style="width:100%"></div></div>
        <span><b>${rows.length}</b></span>
      </div>
      <div class="bb-stat">
        <span>Đã sàng lọc (trùng cơ sở):</span>
        <div class="bb-stat-bar"><div class="bb-stat-fill good" style="width:${rows.length?(kept/rows.length*100):0}%"></div></div>
        <span><b>${kept}</b></span>
      </div>
      <div class="bb-stat">
        <span>Tỷ lệ lỗi trong khóa đã sàng lọc:</span>
        <div class="bb-stat-bar"><div class="bb-stat-fill bad" style="width:${(errRate*100)}%"></div></div>
        <span><b>${(errRate*100).toFixed(1)}%</b></span>
      </div>
      <div><b>Khóa đã sàng lọc của Alice:</b> <span class="bb-key">${keyStr || '(trống)'}</span></div>
      <div><b>Khóa đã sàng lọc của Bob:</b>&nbsp;&nbsp; <span class="bb-key">${keyB.join('') || '(trống)'}</span></div>
      ${verdictHTML}`;
  }

  document.getElementById('bb-run').onclick = () => {
    render(+nSlider.value, eveBox.checked);
  };
}

// ----- Bell's inequality / CHSH demo -----
function initBell(){
  // Hai góc của Alice, hai góc của Bob. Lựa chọn CHSH chuẩn → |S| tối đa = 2√2 cho |Φ+⟩.
  const aA = [0,            Math.PI/2];
  const aB = [Math.PI/4, 3*Math.PI/4];
  const labels = [
    ['⟨a₀ · b₀⟩ &nbsp; (0°, 45°)',  '⟨a₀ · b₁⟩ &nbsp; (0°, 135°)'],
    ['⟨a₁ · b₀⟩ &nbsp; (90°, 45°)', '⟨a₁ · b₁⟩ &nbsp; (90°, 135°)'],
  ];

  let cells;
  const grid = document.getElementById('bell-grid');
  const sEl = document.getElementById('bell-S');
  const sAbsEl = document.getElementById('bell-Sabs');
  const needle = document.getElementById('bell-needle');
  const verdict = document.getElementById('bell-verdict');
  const msg = document.getElementById('bell-msg');

  function buildGrid(){
    grid.innerHTML = '';
    for(let i=0;i<2;i++) for(let j=0;j<2;j++){
      const cell = document.createElement('div');
      cell.className = 'bell-cell';
      cell.innerHTML = `
        <div class="bell-cell-label">${labels[i][j]}</div>
        <div class="bell-cell-bar"><div class="bell-bar-fill" id="bf-${i}${j}"></div></div>
        <div class="bell-cell-stats">E = <b id="be-${i}${j}">—</b>
          <span class="muted">(<span id="bn-${i}${j}">0</span> lần đo)</span></div>`;
    grid.appendChild(cell);
    }
  }

  function reset(){
    cells = [[{s:0,d:0},{s:0,d:0}],[{s:0,d:0},{s:0,d:0}]];
    render();
    verdict.className = 'bell-verdict';
    verdict.textContent = 'Nhấn một nút để bắt đầu.';
    msg.textContent = 'Dự đoán lượng tử: |S| → 2√2 ≈ 2.828. Giới hạn cổ điển: |S| ≤ 2.';
  }

  function E(i,j){
    const c = cells[i][j], total = c.s + c.d;
    return total ? (c.s - c.d) / total : 0;
  }

  function render(){
    let any = false;
    for(let i=0;i<2;i++) for(let j=0;j<2;j++){
      const total = cells[i][j].s + cells[i][j].d;
      if(total) any = true;
      const e = E(i,j);
      const eEl = document.getElementById(`be-${i}${j}`);
      const bf  = document.getElementById(`bf-${i}${j}`);
      document.getElementById(`bn-${i}${j}`).textContent = total;
      eEl.textContent = total ? e.toFixed(3) : '—';
      const mag = Math.abs(e) * 50;          // % của nửa thanh
      if(e >= 0){ bf.style.left = '50%'; bf.style.width = mag + '%'; bf.className = 'bell-bar-fill pos'; }
      else      { bf.style.left = (50 - mag) + '%'; bf.style.width = mag + '%'; bf.className = 'bell-bar-fill neg'; }
    }
    const s = E(0,0) - E(0,1) + E(1,0) + E(1,1);
    const abs = Math.abs(s);
    sEl.textContent = s.toFixed(3);
    sAbsEl.textContent = abs.toFixed(3);
    // thước đo 0..4
    needle.style.left = Math.min(100, abs/4 * 100) + '%';

    if(!any) return;
    if(abs <= 2.001){
      verdict.className = 'bell-verdict classical';
      verdict.textContent = `|S| = ${abs.toFixed(3)} ≤ 2 — nằm trong giới hạn cổ điển (Bell). Không có vi phạm lượng tử.`;
    } else if(abs <= 2*Math.SQRT2 + 0.05){
      verdict.className = 'bell-verdict quantum';
      verdict.textContent = `|S| = ${abs.toFixed(3)} > 2 — Bất đẳng thức Bell bị vi phạm! Chào mừng đến vùng lượng tử thực thụ.`;
    } else {
      verdict.className = 'bell-verdict over';
      verdict.textContent = `|S| = ${abs.toFixed(3)} vượt giới hạn Tsirelson — dao động lấy mẫu, bình thường khi N nhỏ.`;
    }
  }

  function trial(quantum){
    const i = Math.random() < 0.5 ? 0 : 1;
    const j = Math.random() < 0.5 ? 0 : 1;
    let same;
    if(quantum){
      // Tương quan |Φ+⟩: P(cùng) = (1 + cos(α − β)) / 2
      const p = (1 + Math.cos(aA[i] - aB[j])) / 2;
      same = Math.random() < p;
    } else {
      // Mô hình biến ẩn cục bộ: trục ngẫu nhiên chung λ; mỗi bên xuất dấu(cos(góc − λ)).
      const lam = Math.random() * 2 * Math.PI;
      const A = Math.cos(aA[i] - lam) > 0 ? 1 : -1;
      const B = Math.cos(aB[j] - lam) > 0 ? 1 : -1;
      same = (A === B);
    }
    if(same) cells[i][j].s++;
    else     cells[i][j].d++;
  }

  document.getElementById('bell-run-q').onclick = () => {
    for(let k=0;k<1000;k++) trial(true);
    render();
    msg.textContent = `+1000 lần đo lượng tử. Lý thuyết: |S| → 2√2 ≈ 2.828.`;
  };
  document.getElementById('bell-run-c').onclick = () => {
    for(let k=0;k<1000;k++) trial(false);
    render();
    msg.textContent = `+1000 lần đo biến ẩn cục bộ cổ điển. Lý thuyết: |S| tối đa ≤ 2.`;
  };
  document.getElementById('bell-reset').onclick = reset;

  buildGrid();
  reset();
}

// ----- Bảng tham chiếu cổng -----
const GATES = [
  {sym:'I', name:'Identity', sub:'không làm gì',
   matrix:[['1','0'],['0','1']],
   expl:'Giữ nguyên qubit. Đôi khi dùng làm chỗ "chờ" trong mạch.',
   effect:'I|0⟩ = |0⟩,  I|1⟩ = |1⟩'},
  {sym:'X', name:'Pauli-X', sub:'lật bit / NOT',
   matrix:[['0','1'],['1','0']],
   expl:'Phép NOT cổ điển: lật |0⟩ ↔ |1⟩. Là phép quay π quanh trục X của mặt cầu Bloch.',
   effect:'X|0⟩ = |1⟩,  X|1⟩ = |0⟩'},
  {sym:'Y', name:'Pauli-Y', sub:'lật bit + đổi pha',
   matrix:[['0','−i'],['i','0']],
   expl:'Lật bit kèm đổi pha. Là phép quay π quanh trục Y.',
   effect:'Y|0⟩ = i·|1⟩,  Y|1⟩ = −i·|0⟩'},
  {sym:'Z', name:'Pauli-Z', sub:'lật pha',
   matrix:[['1','0'],['0','−1']],
   expl:'Để yên |0⟩ nhưng đổi dấu của |1⟩. Là phép quay π quanh trục Z.',
   effect:'Z|0⟩ = |0⟩,  Z|1⟩ = −|1⟩'},
  {sym:'H', name:'Hadamard', sub:'tạo chồng chập',
   matrix:[['1/√2','1/√2'],['1/√2','−1/√2']],
   expl:'Biến một trạng thái xác định thành chồng chập đều. Cổng 1-qubit "thuần lượng tử" quan trọng nhất.',
   effect:'H|0⟩ = (|0⟩+|1⟩)/√2,  H|1⟩ = (|0⟩−|1⟩)/√2'},
  {sym:'S', name:'S — pha π/2', sub:'√Z',
   matrix:[['1','0'],['0','i']],
   expl:'Thêm pha 90° vào |1⟩. Bình phương nó thì được Z.',
   effect:'S|0⟩ = |0⟩,  S|1⟩ = i·|1⟩'},
  {sym:'T', name:'T — pha π/4', sub:'√S',
   matrix:[['1','0'],['0','e^(iπ/4)']],
   expl:'Thêm pha 45° vào |1⟩. Cùng với H và CNOT tạo thành một bộ cổng phổ dụng.',
   effect:'T|1⟩ = e^(iπ/4)·|1⟩'},
  {sym:'Rx', name:'Rx(θ)', sub:'quay quanh trục X', rot:true,
   matrix:[['cos(θ/2)','−i·sin(θ/2)'],['−i·sin(θ/2)','cos(θ/2)']],
   expl:'Quay một góc θ quanh trục X của mặt cầu Bloch.',
   effect:'Rx(π) = X  (sai khác một pha toàn cục)'},
  {sym:'Ry', name:'Ry(θ)', sub:'quay quanh trục Y', rot:true,
   matrix:[['cos(θ/2)','−sin(θ/2)'],['sin(θ/2)','cos(θ/2)']],
   expl:'Quay một góc θ quanh trục Y. Ma trận thực — rất tiện để chuẩn bị trạng thái.',
   effect:'Ry(π) = Y  (sai khác một pha toàn cục)'},
  {sym:'Rz', name:'Rz(θ)', sub:'quay quanh trục Z', rot:true,
   matrix:[['e^(−iθ/2)','0'],['0','e^(iθ/2)']],
   expl:'Quay một góc θ quanh trục Z. Thêm pha tương đối giữa |0⟩ và |1⟩.',
   effect:'Rz(π) = Z  (sai khác một pha toàn cục)'},
  {sym:'CNOT', name:'Controlled-NOT', sub:'2 qubit · tạo rối', two:true,
   matrix:[['1','0','0','0'],['0','1','0','0'],['0','0','0','1'],['0','0','1','0']],
   expl:'Nếu qubit điều khiển là 1 thì lật qubit đích. Cổng 2-qubit trụ cột — ghép với H sẽ tạo ra cặp Bell.',
   effect:'CNOT|00⟩=|00⟩,  CNOT|01⟩=|01⟩,  CNOT|10⟩=|11⟩,  CNOT|11⟩=|10⟩'},
  {sym:'M', name:'Phép đo', sub:'sụp trạng thái', meas:true,
   matrix:null,
   expl:'Không unita — nó chiếu qubit về |0⟩ hoặc |1⟩ với xác suất bằng bình phương biên độ. Kết quả là cổ điển.',
   effect:'đo(α|0⟩+β|1⟩) → 0 với xác suất |α|²,  1 với xác suất |β|²'},
];

function initGates(){
  const grid = document.getElementById('gates-grid');
  if(!grid) return;
  grid.innerHTML = '';
  GATES.forEach(g => {
    const card = document.createElement('div');
    card.className = 'gate-card';
    const symClasses = ['gate-symbol'];
    if(g.rot) symClasses.push('rot');
    if(g.two || g.sym.length > 2) symClasses.push('two');
    let matrixHTML = '';
    if(g.matrix){
      const cols = g.matrix[0].length;
      const cells = g.matrix.flat().map(v => `<span>${v}</span>`).join('');
      matrixHTML = `
        <div class="matrix">
          <span class="br l"></span>
          <div class="grid" style="grid-template-columns:repeat(${cols},auto)">${cells}</div>
          <span class="br r"></span>
        </div>`;
    }
    card.innerHTML = `
      <div class="gate-head">
        <div class="${symClasses.join(' ')}">${g.sym}</div>
        <div class="gate-name">${g.name}<small>${g.sub}</small></div>
      </div>
      ${matrixHTML}
      <div class="gate-expl">${g.expl}</div>
      <div class="gate-effect">${g.effect}</div>`;
    grid.appendChild(card);
  });
}

// ----- Measurement chart -----
function initMeasurement(){
  let counts = {0:0, 1:0};
  const slider = document.getElementById('m-slider');
  const pv = document.getElementById('m-pval');
  const c0 = document.getElementById('m-c0'), c1 = document.getElementById('m-c1');
  const cv = document.getElementById('m-chart'); const ctx = cv.getContext('2d');
  const dirac = document.getElementById('m-dirac');

  const FRAC_1_SQRT2 = '<span class="frac"><span class="num">1</span><span class="den">√2</span></span>';
  function prettyAmp(p){
    if(p === 0)   return '0';
    if(p === 100) return '1';
    if(p === 50)  return FRAC_1_SQRT2;
    return `√<span style="font-style:normal">${(p/100).toFixed(2)}</span>`;
  }
  function renderDirac(p1pct){
    const p0pct = 100 - p1pct;
    const a = Math.sqrt(p0pct/100);
    const b = Math.sqrt(p1pct/100);
    let main;
    if(p0pct === 0)      main = `<span class="beta">${prettyAmp(p1pct)}</span><span class="ket">|1⟩</span>`;
    else if(p1pct === 0) main = `<span class="alpha">${prettyAmp(p0pct)}</span><span class="ket">|0⟩</span>`;
    else
      main = `<span class="alpha">${prettyAmp(p0pct)}</span><span class="ket">|0⟩</span> + ` +
             `<span class="beta">${prettyAmp(p1pct)}</span><span class="ket">|1⟩</span>`;
    dirac.innerHTML = `
      <span class="label">Trạng thái trước khi đo</span>
      <div class="eq">|ψ⟩ = ${main}</div>
      <span class="approx">≈ ${a.toFixed(3)} |0⟩ + ${b.toFixed(3)} |1⟩
        &nbsp;·&nbsp; |α|² = ${p0pct}%, &nbsp; |β|² = ${p1pct}%</span>`;
  }

  slider.oninput = () => { pv.textContent = slider.value; renderDirac(+slider.value); };
  renderDirac(+slider.value);

  function shoot(n){
    const p = +slider.value / 100;
    for(let i=0;i<n;i++) counts[Math.random() < p ? 1 : 0]++;
    c0.textContent = counts[0]; c1.textContent = counts[1];
    draw();
  }
  function draw(){
    const w = cv.width = cv.clientWidth, h = cv.height;
    ctx.clearRect(0,0,w,h);
    const total = counts[0] + counts[1] || 1;
    const bar = (i, color, val) => {
      const bw = w/2 - 30, bh = (h-30) * (val/total);
      ctx.fillStyle = color;
      ctx.fillRect(20 + i*(bw+30), h - bh - 20, bw, bh);
      ctx.fillStyle = '#e6e8ef';
      ctx.font = '12px system-ui';
      ctx.fillText(`|${i}⟩  ${val}`, 20 + i*(bw+30), h - 6);
    };
    bar(0, '#06b6d4', counts[0]);
    bar(1, '#ec4899', counts[1]);
  }
  document.getElementById('m-once').onclick  = () => shoot(1);
  document.getElementById('m-many').onclick  = () => shoot(100);
  document.getElementById('m-shots').onclick = () => shoot(1024);
  document.getElementById('m-reset').onclick = () => { counts={0:0,1:0}; c0.textContent='0'; c1.textContent='0'; draw(); };
  draw();
  window.addEventListener('resize', draw);
}

// ----- Circuits (IBM Composer-style: column-aligned, multi-qubit, full gate set) -----
function initCircuits(){
  let nQ = 2;
  // ops: array of {type, qubits:[...], params:{angle?}}
  // Each op occupies its own column (simple model — easy to align CNOT rows).
  let ops = [];
  let pending = null;       // {type, qubits:[]}  — cổng đang chờ đặt
  const out = document.getElementById('cir-output');
  const canvas = document.getElementById('circuit-canvas');
  const hint = document.getElementById('cir-hint');
  const qLabel = document.getElementById('qcount-label');
  const paletteBtns = () => document.querySelectorAll('#circuits .gate-btn');

  const setHint = m => hint.textContent = m;

  // Format radians as a multiple of π (e.g. π/2, 3π/4, -π).
  function formatPi(rad){
    if(rad === 0) return '0';
    const k = rad / Math.PI;                  // value in units of π
    const denoms = [1,2,3,4,6,8,12];
    const eps = 1e-3;
    for(const d of denoms){
      const num = Math.round(k * d);
      if(Math.abs(k * d - num) < eps && num !== 0){
        const sign = num < 0 ? '-' : '';
        const n = Math.abs(num);
        if(d === 1) return `${sign}${n === 1 ? '' : n}π`;
        return `${sign}${n === 1 ? '' : n}π/${d}`;
      }
    }
    return `${k.toFixed(2)}π`;
  }
  // Accept "0.5" (→ 0.5π), "0.5π", or "1.2 rad".
  function parseAngle(raw){
    const s = String(raw).trim().toLowerCase().replace(/\s+/g,'');
    if(!s) return null;
    if(s.endsWith('rad')){
      const v = parseFloat(s.slice(0,-3));
      return isNaN(v) ? null : v;
    }
    const stripped = s.replace(/π|pi/g,'');
    const v = parseFloat(stripped);
    if(isNaN(v)) return null;
    return v * Math.PI;
  }
  const clearPending = () => {
    pending = null;
    paletteBtns().forEach(b => b.classList.remove('active'));
    setHint('Kéo một cổng lên dây mạch — hoặc nhấp cổng rồi nhấp vào dây.');
  };

  // Arm a gate for placement (used by both click and drag start).
  // Preserves a partially-placed CNOT (after control was set) so the user can finish via drag.
  function startPending(type){
    const isTwoQubit = (t) => t === 'CNOT' || t === 'CZ' || t === 'SWAP';
    if(pending && isTwoQubit(pending.type) && pending.qubits.length === 1 && pending.type === type){
      paletteBtns().forEach(b => b.classList.toggle('active', b.dataset.gate === type));
      setHint(`Giờ thả xuống dây thứ hai để hoàn tất ${type}.`);
      return;
    }
    paletteBtns().forEach(b => b.classList.toggle('active', b.dataset.gate === type));
    pending = {type, qubits:[]};
    if(type === 'CNOT')          setHint('Thả xuống một dây để đặt qubit ĐIỀU KHIỂN.');
    else if(type === 'CZ')       setHint('Thả xuống một dây để đặt qubit đầu tiên của CZ (CZ đối xứng).');
    else if(type === 'SWAP')     setHint('Thả xuống một dây để đặt qubit đầu tiên của SWAP (SWAP đối xứng).');
    else if(type === 'BARRIER')  setHint('Thả xuống dây bất kỳ để chèn vạch ngăn.');
    else if(type === 'M')        setHint('Thả xuống một dây để thêm phép đo.');
    else if(['Rx','Ry','Rz'].includes(type)) setHint(`Thả ${type} lên một dây — bạn sẽ được hỏi góc quay.`);
    else                         setHint(`Thả ${type} lên một dây.`);
  }

  // ---------- Render ----------
  function render(){
    qLabel.textContent = `${nQ} qubit`;
    canvas.innerHTML = '';
    for(let q=0; q<nQ; q++){
      const wire = document.createElement('div');
      wire.className = 'qwire';
      const lbl = document.createElement('span');
      lbl.className = 'wire-label';
      lbl.textContent = 'q'+q;
      wire.appendChild(lbl);

      const cells = document.createElement('div');
      cells.className = 'cells';

      ops.forEach((op, i) => {
        const cell = document.createElement('div');
        cell.className = 'cell';

        if(op.type === 'BARRIER'){
          cell.classList.add('barrier-cell');
        } else if(op.type === 'CNOT' || op.type === 'CZ' || op.type === 'SWAP'){
          const [c, t] = op.qubits;
          const lo = Math.min(c,t), hi = Math.max(c,t);
          if(q === c || q === t){
            const removeFn = () => { ops.splice(i,1); render(); };
            if(op.type === 'SWAP'){
              cell.classList.add('swap');
              cell.innerHTML = '<div class="swap-x" title="Nhấp để xoá · SWAP">×</div>';
            } else if(op.type === 'CZ'){
              cell.classList.add('ctrl');
              cell.innerHTML = '<div class="ctrl-dot" title="Nhấp để xoá · CZ"></div>';
            } else if(q === c){
              // CNOT control
              cell.classList.add('ctrl');
              cell.innerHTML = '<div class="ctrl-dot" title="Nhấp để xoá"></div>';
            } else {
              // CNOT target
              cell.classList.add('target');
              cell.innerHTML = '<div class="xor" title="Nhấp để xoá">⊕</div>';
            }
            cell.onclick = removeFn;
          }
          if(q > lo && q < hi) cell.classList.add('cnot-line');
        } else if(op.qubits.includes(q)){
          cell.classList.add('gate-cell');
          const box = document.createElement('div');
          box.className = 'gate-box';
          const isRot = ['Rx','Ry','Rz'].includes(op.type);
          if(isRot) box.classList.add('rot');
          if(op.type === 'M') box.classList.add('meas');

          if(isRot && op.params && op.params.angle !== undefined){
            // IBM-Composer-style two-line layout: gate name on top, angle below.
            const nameEl = document.createElement('span');
            nameEl.className = 'gate-name';
            nameEl.textContent = op.type;
            const angleEl = document.createElement('span');
            angleEl.className = 'gate-angle';
            angleEl.textContent = '(' + formatPi(op.params.angle) + ')';
            box.appendChild(nameEl);
            box.appendChild(angleEl);
          } else {
            box.textContent = op.type;
          }

          box.title = isRot ? 'Nhấp để xoá · Nhấp chuột phải để sửa góc' : 'Nhấp để xoá';
          box.onclick = () => { ops.splice(i,1); render(); };
          if(isRot){
            box.oncontextmenu = (ev) => {
              ev.preventDefault();
              const cur = (op.params.angle / Math.PI).toFixed(4).replace(/\.?0+$/,'');
              const raw = prompt(
                `Sửa góc cho ${op.type} (đơn vị π).  Ví dụ: 0.5 → π/2, 1 → π.\nThêm hậu tố "rad" để nhập theo radian.`,
                cur
              );
              if(raw === null) return;
              const a = parseAngle(raw);
              if(a === null){ setHint('Góc không hợp lệ — giữ giá trị cũ.'); return; }
              op.params.angle = a;
              render();
            };
          }
          cell.appendChild(box);
        }
        cells.appendChild(cell);
      });

      // tail / placement zone
      const tail = document.createElement('div');
      tail.className = 'cell tail' + (pending ? ' armed' : '');
      tail.onclick = () => placeOnWire(q);
      cells.appendChild(tail);

      // Drag-and-drop target: dropping a gate anywhere on this wire places it on q.
      wire.addEventListener('dragover', (ev) => {
        if(!pending) return;
        ev.preventDefault();
        ev.dataTransfer.dropEffect = 'copy';
        wire.classList.add('drag-over');
      });
      wire.addEventListener('dragleave', () => wire.classList.remove('drag-over'));
      wire.addEventListener('drop', (ev) => {
        ev.preventDefault();
        wire.classList.remove('drag-over');
        placeOnWire(q);
      });

      wire.appendChild(cells);
      canvas.appendChild(wire);
    }
  }

  function placeOnWire(q){
    if(!pending){ setHint('Hãy chọn một cổng từ bảng phía trên trước.'); return; }
    const t = pending.type;

    if(t === 'CNOT' || t === 'CZ' || t === 'SWAP'){
      pending.qubits.push(q);
      if(pending.qubits.length === 1){
        const msg = t === 'CZ'
          ? `Đã đặt qubit đầu tiên trên q${q}. Giờ thả nút CZ lên (hoặc nhấp) dây thứ hai — CZ đối xứng.`
          : t === 'SWAP'
            ? `Đã đặt qubit đầu tiên trên q${q}. Giờ thả nút SWAP lên (hoặc nhấp) dây thứ hai — SWAP đối xứng.`
            : `Đã đặt điều khiển trên q${q}. Giờ thả nút CNOT lên (hoặc nhấp) dây ĐÍCH.`;
        setHint(msg);
      } else {
        if(pending.qubits[0] === pending.qubits[1]){
          const otherWire = pending.qubits[0] === 0 ? 'q1' : 'q0';
          const errMsg = t === 'CNOT'
            ? `Trùng dây với qubit điều khiển rồi. CNOT tác động GIỮA hai qubit — điều khiển ở dây này, đích ở dây KHÁC. Thử ${otherWire} nhé.`
            : t === 'SWAP'
              ? `SWAP hoán đổi HAI qubit khác nhau. Chọn dây khác — thử ${otherWire}.`
              : `CZ tác động GIỮA hai qubit khác nhau. Chọn dây khác — thử ${otherWire}.`;
          setHint(errMsg);
          pending.qubits.pop();
          return;
        }
        ops.push({type:t, qubits:pending.qubits.slice()});
        clearPending();
      }
    } else if(t === 'BARRIER'){
      ops.push({type:'BARRIER', qubits:Array.from({length:nQ}, (_,i)=>i)});
      clearPending();
    } else {
      const params = {};
      if(['Rx','Ry','Rz'].includes(t)){
        const raw = prompt(
          `Góc cho ${t}. Nhập theo đơn vị π — ví dụ  0.5  →  π/2,  1  →  π,  0.25  →  π/4.\nHoặc nhập số thường kèm hậu tố "rad" (ví dụ "1.2 rad").`,
          '0.5'
        );
        if(raw === null){ clearPending(); return; }
        const a = parseAngle(raw);
        if(a === null){ setHint('Góc không hợp lệ — đã huỷ.'); clearPending(); return; }
        params.angle = a;
      }
      ops.push({type:t, qubits:[q], params});
      clearPending();
    }
    render();
  }

  // ---------- Palette wiring (click + drag) ----------
  paletteBtns().forEach(btn => {
    btn.draggable = true;
    btn.onclick = () => {
      // Toggle off if user clicks the already-active gate (and it is not mid-CNOT)
      if(btn.classList.contains('active') && !(pending && pending.type === 'CNOT' && pending.qubits.length === 1)){
        clearPending(); render(); return;
      }
      startPending(btn.dataset.gate);
      render();
    };
    btn.addEventListener('dragstart', (ev) => {
      startPending(btn.dataset.gate);
      ev.dataTransfer.effectAllowed = 'copy';
      ev.dataTransfer.setData('text/plain', btn.dataset.gate);
      render();
    });
    btn.addEventListener('dragend', () => {
      // Refresh wire highlights after drag ends
      document.querySelectorAll('#circuits .qwire.drag-over').forEach(w => w.classList.remove('drag-over'));
    });
  });

  document.getElementById('add-qubit').onclick = () => {
    if(nQ < 6){ nQ++; render(); }
  };
  document.getElementById('rm-qubit').onclick = () => {
    if(nQ > 1){
      nQ--;
      ops = ops.filter(o => o.qubits.every(q => q < nQ));
      render();
    }
  };

  document.getElementById('cir-clear').onclick = () => {
    ops = []; clearPending(); render();
    showInitialChart();
  };

  // ---------- Probability bar chart (IBM-Composer style) ----------
  const chart = document.getElementById('cir-chart');
  const chartCtx = chart ? chart.getContext('2d') : null;
  const measuredEl = document.getElementById('cir-measured');
  const subEl = document.getElementById('cir-result-sub');

  function drawProbChart(probs, N, measuredOutcome){
    if(!chartCtx) return;
    const dpr = window.devicePixelRatio || 1;
    const cssW = chart.clientWidth || 600;
    const cssH = 260;
    chart.style.height = cssH + 'px';
    chart.width  = Math.round(cssW * dpr);
    chart.height = Math.round(cssH * dpr);
    chartCtx.setTransform(dpr, 0, 0, dpr, 0, 0);
    chartCtx.clearRect(0, 0, cssW, cssH);

    const padL = 50, padR = 14, padT = 14, padB = 44;
    const chartW = cssW - padL - padR;
    const chartH = cssH - padT - padB;

    // Y-axis gridlines + labels
    chartCtx.font = '11px system-ui, -apple-system, sans-serif';
    chartCtx.textBaseline = 'middle';
    for(let p = 0; p <= 100; p += 20){
      const y = padT + chartH * (1 - p/100);
      chartCtx.fillStyle = '#8b93a7';
      chartCtx.textAlign = 'right';
      chartCtx.fillText(p.toString(), padL - 8, y);
      chartCtx.strokeStyle = p === 0 ? 'rgba(255,255,255,.18)' : 'rgba(255,255,255,.07)';
      chartCtx.lineWidth = 1;
      chartCtx.beginPath();
      chartCtx.moveTo(padL, y);
      chartCtx.lineTo(padL + chartW, y);
      chartCtx.stroke();
    }

    // Y-axis line
    chartCtx.strokeStyle = 'rgba(255,255,255,.18)';
    chartCtx.beginPath();
    chartCtx.moveTo(padL, padT);
    chartCtx.lineTo(padL, padT + chartH);
    chartCtx.stroke();

    // Y-axis title
    chartCtx.save();
    chartCtx.translate(14, padT + chartH/2);
    chartCtx.rotate(-Math.PI/2);
    chartCtx.textAlign = 'center';
    chartCtx.textBaseline = 'middle';
    chartCtx.fillStyle = '#8b93a7';
    chartCtx.fillText('Xác suất (%)', 0, 0);
    chartCtx.restore();

    // X-axis title
    chartCtx.fillStyle = '#8b93a7';
    chartCtx.textAlign = 'center';
    chartCtx.textBaseline = 'bottom';
    chartCtx.fillText('Các trạng thái cơ bản', padL + chartW/2, cssH - 8);

    // Bars
    const dim = 1 << N;
    const slotW = chartW / dim;
    const barW  = Math.min(40, slotW * 0.6);
    for(let i = 0; i < dim; i++){
      const p = probs[i];
      const bx = padL + i * slotW + (slotW - barW) / 2;
      const barH = p * chartH;
      const by = padT + chartH - barH;

      // Highlight measured outcome bar in pink
      const isMeasured = (measuredOutcome === i);
      if(barH > 0){
        const grad = chartCtx.createLinearGradient(0, by, 0, by + barH);
        if(isMeasured){
          grad.addColorStop(0, '#f472b6');
          grad.addColorStop(1, '#ec4899');
        } else {
          grad.addColorStop(0, '#22d3ee');
          grad.addColorStop(1, '#06b6d4');
        }
        chartCtx.fillStyle = grad;
        chartCtx.fillRect(bx, by, barW, barH);
      }

      // X-axis basis label
      const label = i.toString(2).padStart(N, '0');
      chartCtx.fillStyle = isMeasured ? '#f472b6' : '#cbd5e1';
      chartCtx.textAlign = 'center';
      chartCtx.textBaseline = 'top';
      chartCtx.font = '11px "JetBrains Mono", monospace';
      chartCtx.fillText(label, bx + barW/2, padT + chartH + 8);

      // Percentage above the bar (only if visible & there's space)
      if(p > 0.005 && barW > 22){
        chartCtx.fillStyle = isMeasured ? '#f472b6' : '#06b6d4';
        chartCtx.textBaseline = 'bottom';
        chartCtx.font = '10px "JetBrains Mono", monospace';
        chartCtx.fillText(`${(p*100).toFixed(1)}%`, bx + barW/2, by - 2);
      }

      // Restore default font for the next iteration
      chartCtx.font = '11px system-ui, -apple-system, sans-serif';
    }
  }

  function showInitialChart(){
    const N = nQ;
    const dim = 1 << N;
    const probs = new Array(dim).fill(0);
    probs[0] = 1;
    drawProbChart(probs, N);
    if(subEl) subEl.textContent = `Trạng thái: |${'0'.repeat(N)}⟩  (ban đầu)`;
    if(measuredEl){ measuredEl.textContent = ''; measuredEl.classList.add('empty'); }
    if(out) out.textContent = `|${'0'.repeat(N)}⟩  100.00%`;
  }
  window.addEventListener('resize', () => {
    if(chart && document.getElementById('circuits').classList.contains('active')){
      // Re-render the most recent chart on resize. Simplest: re-run the run handler.
      // We don't have stored probs, so just redraw initial if no ops.
      // (Caller can re-click Run for fresh data.)
    }
  });

  // ---------- Simulator (complex amplitudes) ----------
  const c = (re, im=0) => [re, im];
  const cAdd = (a,b) => [a[0]+b[0], a[1]+b[1]];
  const cMul = (a,b) => [a[0]*b[0]-a[1]*b[1], a[0]*b[1]+a[1]*b[0]];

  function apply1(state, q, M, N){
    const dim = 1 << N;
    const out = new Array(dim);
    for(let i=0;i<dim;i++) out[i] = [0,0];
    for(let i=0;i<dim;i++){
      const bit = (i >> q) & 1;
      const partner = i ^ (1 << q);
      const i0 = bit === 0 ? i : partner;
      const i1 = bit === 0 ? partner : i;
      out[i] = cAdd(cMul(M[bit][0], state[i0]), cMul(M[bit][1], state[i1]));
    }
    return out;
  }
  function applyCNOT(state, ctrl, tgt, N){
    const dim = 1 << N;
    const r = state.slice();
    for(let i=0;i<dim;i++){
      if(((i >> ctrl) & 1) === 1){
        const j = i ^ (1 << tgt);
        if(j > i){ const tmp = r[i]; r[i] = r[j]; r[j] = tmp; }
      }
    }
    return r;
  }

  function applyCZ(state, q1, q2, N){
    // CZ flips the sign of basis states where both q1 and q2 are 1.
    const dim = 1 << N;
    const r = state.slice();
    for(let i=0;i<dim;i++){
      if((((i >> q1) & 1) === 1) && (((i >> q2) & 1) === 1)){
        r[i] = [-r[i][0], -r[i][1]];
      }
    }
    return r;
  }

  function applySWAP(state, q1, q2, N){
    // SWAP exchanges amplitudes of basis states that differ only in (q1, q2) bits.
    // Iterate through pairs (i, j) where bit-q1=0,bit-q2=1 in i, opposite in j.
    const dim = 1 << N;
    const r = state.slice();
    for(let i=0;i<dim;i++){
      const b1 = (i >> q1) & 1;
      const b2 = (i >> q2) & 1;
      if(b1 === 0 && b2 === 1){
        const j = i ^ (1 << q1) ^ (1 << q2);   // partner with bits flipped
        const tmp = r[i]; r[i] = r[j]; r[j] = tmp;
      }
    }
    return r;
  }

  function gateMatrix(op){
    const I = c(1), Z0 = c(0);
    switch(op.type){
      case 'X': return [[Z0, c(1)], [c(1), Z0]];
      case 'Y': return [[Z0, c(0,-1)], [c(0,1), Z0]];
      case 'Z': return [[I, Z0], [Z0, c(-1)]];
      case 'H': { const s = 1/Math.SQRT2; return [[c(s),c(s)],[c(s),c(-s)]]; }
      case 'S': return [[I, Z0], [Z0, c(0,1)]];
      case 'T': return [[I, Z0], [Z0, c(Math.cos(Math.PI/4), Math.sin(Math.PI/4))]];
      case 'Rx': { const th=op.params.angle, cc=Math.cos(th/2), ss=Math.sin(th/2);
        return [[c(cc), c(0,-ss)], [c(0,-ss), c(cc)]]; }
      case 'Ry': { const th=op.params.angle, cc=Math.cos(th/2), ss=Math.sin(th/2);
        return [[c(cc), c(-ss)], [c(ss), c(cc)]]; }
      case 'Rz': { const th=op.params.angle, cc=Math.cos(th/2), ss=Math.sin(th/2);
        return [[c(cc,-ss), Z0], [Z0, c(cc, ss)]]; }
    }
    return null;
  }

  document.getElementById('cir-run').onclick = () => {
    const N = nQ;
    const dim = 1 << N;
    let state = new Array(dim);
    for(let i=0;i<dim;i++) state[i] = [0,0];
    state[0] = [1,0];

    let measured = false;
    for(const op of ops){
      if(op.type === 'BARRIER') continue;
      if(op.type === 'M'){ measured = true; continue; }
      if(op.type === 'CNOT'){
        state = applyCNOT(state, op.qubits[0], op.qubits[1], N);
      } else if(op.type === 'CZ'){
        state = applyCZ(state, op.qubits[0], op.qubits[1], N);
      } else if(op.type === 'SWAP'){
        state = applySWAP(state, op.qubits[0], op.qubits[1], N);
      } else {
        const M = gateMatrix(op);
        if(M) state = apply1(state, op.qubits[0], M, N);
      }
    }

    const probs = state.map(a => a[0]*a[0] + a[1]*a[1]);

    // Single-shot measurement outcome (when an M gate is in the circuit)
    let pick = undefined;
    if(measured){
      const rnd = Math.random();
      let acc = 0;
      pick = 0;
      for(let i=0;i<dim;i++){ acc += probs[i]; if(rnd < acc){ pick = i; break; } }
    }

    drawProbChart(probs, N, pick);

    if(subEl) subEl.textContent = `${N} qubit · ${ops.length} phép toán`;
    if(measuredEl){
      if(measured){
        measuredEl.textContent = `Đo một lần → |${pick.toString(2).padStart(N,'0')}⟩`;
        measuredEl.classList.remove('empty');
      } else {
        measuredEl.textContent = '';
        measuredEl.classList.add('empty');
      }
    }

    // Numeric values (collapsed by default, available for power users)
    const lines = [];
    for(let i=0;i<dim;i++){
      if(probs[i] > 1e-6){
        const bin = i.toString(2).padStart(N,'0');
        lines.push(`|${bin}⟩  ${(probs[i]*100).toFixed(2)}%`);
      }
    }
    if(out) out.textContent = lines.length ? lines.join('\n') : '(không — mạch rỗng)';
  };

  render();
  showInitialChart();
}

// ----- Noise on a quantum channel -----
function initNoise(){
  const pSlider = document.getElementById('n-slider');
  const pLbl    = document.getElementById('n-val');
  const lenSlider = document.getElementById('n-len');
  const lenLbl    = document.getElementById('n-len-v');
  const channel = document.getElementById('n-channel');
  const out     = document.getElementById('n-output');
  const shotMsg = document.getElementById('n-shot-msg');

  pSlider.oninput   = () => { pLbl.textContent = pSlider.value; renderEmpty(); };
  lenSlider.oninput = () => { lenLbl.textContent = lenSlider.value; renderEmpty(); };

  function renderEmpty(){
    const N = +lenSlider.value;
    channel.innerHTML = '';
    for(let i=0;i<N;i++){
      const seg = document.createElement('div');
      seg.className = 'n-seg';
      seg.title = 'channel step ' + (i+1);
      channel.appendChild(seg);
    }
    out.textContent = '?';
    out.className = 'n-end out';
  }

  function renderShot(flips, finalState){
    const N = flips.length;
    channel.innerHTML = '';
    flips.forEach((f, i) => {
      const seg = document.createElement('div');
      seg.className = 'n-seg' + (f ? ' flipped' : '');
      seg.title = `step ${i+1}: ${f ? 'flip!' : 'no flip'}`;
      seg.textContent = f ? '⚡' : '';
      seg.style.animationDelay = (i * 30) + 'ms';
      channel.appendChild(seg);
    });
    out.textContent = `|${finalState}⟩`;
    out.className = 'n-end out ' + (finalState === 0 ? 'good' : 'bad');
  }

  document.getElementById('n-shot').onclick = () => {
    const N = +lenSlider.value;
    const p = +pSlider.value / 100;
    const flips = [];
    let state = 0;
    for(let i=0;i<N;i++){
      const f = Math.random() < p;
      flips.push(f);
      if(f) state = 1 - state;
    }
    renderShot(flips, state);
    const flipCount = flips.filter(x => x).length;
    shotMsg.textContent = state === 0
      ? `✓ Đã sống sót. ${flipCount} lần lật trên đường đi — số chẵn, các lỗi triệt tiêu nhau.`
      : `✗ Đầu ra là |1⟩ — ${flipCount} lần lật (số lẻ), nên qubit bị sai.`;
  };

  document.getElementById('n-run').onclick = () => {
    const N = +lenSlider.value;
    const p = +pSlider.value / 100;
    const M = 1000;
    let counts = {0:0, 1:0};
    for(let s=0; s<M; s++){
      let state = 0;
      for(let i=0;i<N;i++) if(Math.random() < p) state = 1 - state;
      counts[state]++;
    }
    document.getElementById('n-c0').textContent = counts[0];
    document.getElementById('n-c1').textContent = counts[1];
    document.getElementById('n-c0pct').textContent = (counts[0]/M*100).toFixed(1) + '%';
    document.getElementById('n-c1pct').textContent = (counts[1]/M*100).toFixed(1) + '%';
    document.getElementById('n-bar0').style.width = (counts[0]/M*100) + '%';
    document.getElementById('n-bar1').style.width = (counts[1]/M*100) + '%';
    const theo = (1 - Math.pow(1 - 2*p, N)) / 2;
    document.getElementById('n-theo').textContent = (theo*100).toFixed(2) + '%';
    shotMsg.textContent = `Đã gửi 1000 qubit. ${counts[1]} qubit đến nơi bị lật (lỗi ${(counts[1]/M*100).toFixed(1)}%).`;
  };

  renderEmpty();
}

// ----- Quantum Error Correction (3-step build-up: bit-flip → phase-flip → Shor) -----
function initQEC(){
  let logical = '1';
  let mode = 'bit';                       // 'bit' | 'phase' | 'shor'
  const noiseSlider = document.getElementById('qec-noise');
  const noiseLbl    = document.getElementById('qec-noise-v');
  const channel = document.getElementById('qec-channel');
  const decoded = document.getElementById('qec-decoded');
  const msg     = document.getElementById('qec-msg');
  const flow    = document.getElementById('qec-flow');
  const legend  = document.getElementById('qec-legend');
  const badge   = document.getElementById('qec-code-badge');
  const codeLabel = document.getElementById('qec-code-label');
  const theoLine  = document.getElementById('qec-theo-line');

  noiseSlider.oninput = () => noiseLbl.textContent = noiseSlider.value;

  document.querySelectorAll('.qec-bit').forEach(b => {
    b.onclick = () => {
      logical = b.dataset.bit;
      document.querySelectorAll('.qec-bit').forEach(x => x.classList.toggle('active', x===b));
      runOnce();
    };
  });

  document.querySelectorAll('.qec-mode').forEach(b => {
    b.onclick = () => {
      mode = b.dataset.mode;
      document.querySelectorAll('.qec-mode').forEach(x => x.classList.toggle('active', x===b));
      runOnce();
    };
  });

  // ---------- Step 1 3-qubit bit-flip code ----------
  function runBit(){
    const bit = +logical;
    const p = +noiseSlider.value / 100;
    const flips = [0,1,2].map(() => Math.random() < p);
    const after = [0,1,2].map(i => flips[i] ? 1-bit : bit);
    const dec = after.reduce((a,b)=>a+b,0) >= 2 ? 1 : 0;

    channel.className = 'qec-channel';
    channel.innerHTML = '';
    for(let i=0;i<3;i++){
      const f = flips[i];
      const row = document.createElement('div');
      row.className = 'qec-row';
      row.innerHTML = `
        <span class="qec-label">q${i}</span>
        <span class="qec-state in">|${bit}⟩</span>
        <span class="qec-track${f?' flip x':''}">${f ? '⚡ lật bit (X)' : 'sạch'}</span>
        <span class="qec-state${f?' err':''}">|${after[i]}⟩</span>`;
      channel.appendChild(row);
    }

    decoded.textContent = `|${dec}⟩`;
    decoded.className = 'qec-decoded ' + (dec === bit ? 'ok' : 'err');
    const fc = flips.filter(Boolean).length;
    msg.className = 'qec-msg';
    msg.innerHTML = dec === bit
      ? `✓ <b>Đã khôi phục |${bit}⟩.</b> ${fc} trong 3 qubit bị lật bit — nhưng 2 trong 3 vẫn đồng ý, nên <b>bỏ phiếu theo đa số</b> thắng.`
      : `✗ <b>Thất bại.</b> ${fc} trong 3 qubit bị lật — khi có 2 lần lật trở lên, đa số chỉ sai hướng. Mã này chỉ sửa được <b>một</b> lần lật bit.`;
  }

  // ---------- Step 2 3-qubit phase-flip code ----------
  // Same majority-vote trick, but in the |+⟩/|−⟩ basis: |0⟩→|+++⟩, |1⟩→|−−−⟩.
  // A Z error swaps |+⟩↔|−⟩, exactly like X swaps |0⟩↔|1⟩.
  function runPhase(){
    const bit = +logical;
    const sc = ['+','−'];
    const start = bit;                    // 0 → '+', 1 → '−'
    const p = +noiseSlider.value / 100;
    const flips = [0,1,2].map(() => Math.random() < p);
    const after = [0,1,2].map(i => flips[i] ? 1-start : start);
    const minusCount = after.reduce((a,b)=>a+b,0);   // how many ended as |−⟩
    const dec = minusCount >= 2 ? 1 : 0;             // majority |−⟩ → logical 1

    channel.className = 'qec-channel';
    channel.innerHTML = '';
    for(let i=0;i<3;i++){
      const f = flips[i];
      const row = document.createElement('div');
      row.className = 'qec-row';
      row.innerHTML = `
        <span class="qec-label">q${i}</span>
        <span class="qec-state in">|${sc[start]}⟩</span>
        <span class="qec-track${f?' flip z':''}">${f ? '🌀 lật pha (Z)' : 'sạch'}</span>
        <span class="qec-state${f?' err':''}">|${sc[after[i]]}⟩</span>`;
      channel.appendChild(row);
    }

    decoded.textContent = `|${dec}⟩`;
    decoded.className = 'qec-decoded ' + (dec === bit ? 'ok' : 'err');
    const fc = flips.filter(Boolean).length;
    msg.className = 'qec-msg';
    msg.innerHTML = dec === bit
      ? `✓ <b>Đã khôi phục |${bit}⟩.</b> ${fc} trong 3 qubit bị lật pha (|+⟩↔|−⟩) — <b>bỏ phiếu theo dấu đa số</b> vẫn thắng. `
        + `Đây chính là cùng một mã như ở bước 1, chỉ viết trong cơ sở |+⟩/|−⟩, nơi Z trông giống một phép lật.`
      : `✗ <b>Thất bại.</b> ${fc} trong 3 dấu bị lật — từ 2 lần lật pha trở lên sẽ lấn át đa số về dấu. Chỉ sửa được <b>một</b> lần lật pha.`;
  }

  // ---------- Step 3 Shor 9-qubit code (bit-flip blocks nested in a phase-flip code) ----------
  function runShor(){
    const errX = true, errZ = true;
    const bit = +logical;
    const s0 = bit ? -1 : +1;                 // initial sign of every block
    const p = +noiseSlider.value / 100;
    const blocks = [[0,1,2],[3,4,5],[6,7,8]];

    const xe = Array(9).fill(false), ze = Array(9).fill(false);
    for(let i=0;i<9;i++){
      if(errX && Math.random() < p) xe[i] = true;
      if(errZ && Math.random() < p) ze[i] = true;
    }

    // A block's logical-carrying SIGN flips with the parity of Z errors in it.
    // Bit-flips never change the value of an encoded basis state (complement
    // symmetry returns the block to the code space), so the logical bit is
    // decided purely by the outer majority vote over the three block signs.
    const info = blocks.map(qs => {
      const xc = qs.filter(i => xe[i]).length;
      const zc = qs.filter(i => ze[i]).length;
      const signFlip = (zc % 2) === 1;
      return { qs, xc, zc, signFlip, sign: signFlip ? -s0 : s0 };
    });
    const signFlips = info.filter(b => b.signFlip).length;
    const dec = signFlips >= 2 ? 1 - bit : bit;

    const initC = s0 > 0 ? '+' : '−';            // every block starts with this sign
    channel.className = 'qec-channel shor';
    channel.innerHTML = '';
    info.forEach((bi, bx) => {
      const wrap = document.createElement('div');
      wrap.className = 'qec-block' + (bi.signFlip ? ' signflip' : '');
      const finalC = bi.sign > 0 ? '+' : '−';
      const head = bi.signFlip
        ? `(|000⟩ ${initC} |111⟩) → (|000⟩ <b>${finalC}</b> |111⟩)`
        : `(|000⟩ ${initC} |111⟩)`;
      wrap.innerHTML = `<div class="qec-block-head">
          <span>khối ${bx+1} · ${head}</span>
          <span class="qec-bsign ${bi.signFlip?'flip':''}">${bi.signFlip ? '⟲ dấu bị lật' : 'dấu giữ nguyên'}</span>
        </div>`;
      bi.qs.forEach(i => {
        // each qubit independently rolls X and Z → clean / X / Z / Y(=both)
        let label = 'sạch', cls = '';
        if(xe[i] && ze[i]){ label = '✦ Y · bit + pha'; cls = ' flip y'; }
        else if(xe[i]){     label = '⚡ X · lật bit';     cls = ' flip x'; }
        else if(ze[i]){     label = '🌀 Z · lật pha';   cls = ' flip z'; }
        const row = document.createElement('div');
        row.className = 'qec-row mini';
        row.innerHTML = `
          <span class="qec-label">q${i}</span>
          <span class="qec-track${cls}">${label}</span>`;
        wrap.appendChild(row);
      });
      const st = document.createElement('div');
      st.className = 'qec-block-status';
      const inner = bi.xc === 0 ? 'không có lỗi lật bit' : `${bi.xc} lỗi lật bit ${bi.xc<=1?'→ Bước 1 sửa được':'(quá nhiều ở đây)'}`;
      const outer = bi.signFlip ? 'dấu BỊ LẬT ✗' : 'dấu ỔN ✓';
      st.innerHTML = `mã bên trong: ${inner}<br>${outer} ở khối này`;
      wrap.appendChild(st);
      channel.appendChild(wrap);
    });

    const totX = xe.filter(Boolean).length, totZ = ze.filter(Boolean).length;
    decoded.textContent = `|${dec}⟩`;
    decoded.className = 'qec-decoded ' + (dec === bit ? 'ok' : 'err');
    msg.className = 'qec-msg';
    msg.innerHTML = dec === bit
      ? `✓ <b>Đã khôi phục bit logic.</b> ${totX} lỗi lật bit + ${totZ} lỗi lật pha đánh vào 9 qubit. `
        + `Các lỗi lật bit đã được dọn sạch bên trong từng khối; ${signFlips === 0 ? 'không khối nào bị lật dấu' : signFlips + ' khối bị lật dấu'}, nên cuộc bỏ phiếu đa số bên ngoài vẫn giữ được.`
      : `✗ <b>Lỗi logic.</b> ${signFlips} trong 3 khối bị lật pha đổi dấu — cuộc bỏ phiếu đa số bên ngoài nghiêng sai hướng. `
        + `Shor sửa được <i>mọi</i> lỗi trên một qubit; phải có ≥2 khối bị lật dấu mới đánh bại được nó.`;
  }

  function runOnce(){
    if(mode === 'shor'){
      flow.textContent = '1 Mã hoá (9 qubit = 3 khối lật bit)  →  2 Nhiễu X và Z  →  3 Mỗi khối sửa lỗi lật bit, rồi 3 dấu của khối bỏ phiếu';
      badge.innerHTML = 'Mã 3 — <b>Shor</b>: ba khối lật bit của Bước 1, bọc trong một mã lật pha của Bước 2. Sửa được mọi lỗi đơn thuộc cả hai loại.';
      badge.className = 'qec-code-badge shor';
      legend.hidden = false;
      runShor();
    } else if(mode === 'phase'){
      flow.textContent = '1 Mã hoá trong |+⟩/|−⟩  →  2 Một qubit có thể bị lật pha (|+⟩↔|−⟩)  →  3 Bỏ phiếu theo dấu đa số';
      badge.innerHTML = 'Mã 2 — bảo vệ chống <b>lật pha</b>, dùng 3 qubit trong cơ sở |+⟩/|−⟩. Cùng mẹo bỏ phiếu đa số như mã 1, chỉ xoay trục.';
      badge.className = 'qec-code-badge';
      legend.hidden = true;
      runPhase();
    } else {
      flow.textContent = '1 Mã hoá (sao chép ra 3 qubit)  →  2 Một qubit có thể bị lật bit  →  3 Bỏ phiếu đa số';
      badge.innerHTML = 'Mã 1 — chỉ bảo vệ chống <b>lật bit</b>, dùng 3 qubit và một cuộc bỏ phiếu đa số.';
      badge.className = 'qec-code-badge';
      legend.hidden = true;
      runBit();
    }
  }

  document.getElementById('qec-run').onclick = runOnce;

  document.getElementById('qec-stats').onclick = () => {
    const p = +noiseSlider.value / 100, N = 1000;
    let bare = 0, code = 0;

    if(mode === 'shor'){
      for(let t=0;t<N;t++){
        // a lone qubit has no redundancy — any X or Z disturbs its state
        if(Math.random() < (1-(1-p)*(1-p))) bare++;
        let sf = 0;
        for(let b=0;b<3;b++){
          let zc = 0;
          for(let k=0;k<3;k++) if(Math.random() < p) zc++;
          if(zc % 2 === 1) sf++;
        }
        if(sf >= 2) code++;
      }
      const q = 3*p*(1-p)*(1-p) + p*p*p;          // P(odd # of Z in a block)
      const theo = 3*q*q*(1-q) + q*q*q;            // P(≥2 of 3 blocks sign-flip)
      codeLabel.textContent = 'Tỉ lệ lỗi logic của mã Shor 9 qubit';
      theoLine.innerHTML = `Tỉ lệ Shor lý thuyết ≈ 3q2(1−q) + q3 = <b>${(theo*100).toFixed(2)}%</b>, `
        + `với q = 3p(1−p)2 + p3 = ${(q*100).toFixed(1)}% là tính chẵn lẻ pha của một khối. `
        + `Các lỗi lật pha quyết định số phận logic — lỗi lật bit được hấp thụ bên trong các khối. `
        + `Qubit trần bị làm hỏng bởi <i>bất kỳ</i> lỗi X hay Z nào.`;
      var bareRate = bare/N, codeRate = code/N;
    } else {
      for(let t=0;t<N;t++){
        if(Math.random() < p) bare++;
        let f = 0;
        for(let k=0;k<3;k++) if(Math.random() < p) f++;
        if(f >= 2) code++;
      }
      const theo = 3*p*p*(1-p) + p*p*p;
      const kind = mode === 'phase' ? 'lật pha' : 'lật bit';
      codeLabel.textContent = `Tỉ lệ lỗi của mã ${kind} 3 qubit`;
      theoLine.innerHTML = `Tỉ lệ đã mã hoá lý thuyết = 3p2(1−p) + p3 = <b>${(theo*100).toFixed(2)}%</b>. `
        + `Cả hai mã 3 qubit dùng chung đường cong này — chúng thắng một qubit trần mỗi khi p &lt; 50%.`;
      var bareRate = bare/N, codeRate = code/N;
    }

    document.getElementById('qec-bare').textContent  = (bareRate*100).toFixed(1) + '%';
    document.getElementById('qec-coded').textContent = (codeRate*100).toFixed(1) + '%';
    document.getElementById('qec-bare-bar').style.width  = Math.min(100, bareRate*100) + '%';
    document.getElementById('qec-coded-bar').style.width = Math.min(100, codeRate*100) + '%';
  };

  runOnce();
}

// ----- Mini-circuit renderer (used by Algorithms) -----
// Each spec: { rows:[label,...], steps:[ [placement, ...], ... ] }
// placement: {q, gate, cls?} | {cnot:[c,t]} | {span:[from,to], gate, cls?}
function renderMiniCircuit(host, spec, caption){
  const nQ = spec.rows.length;
  const nC = spec.steps.length;
  host.innerHTML = '';
  const grid = document.createElement('div');
  grid.className = 'mc-grid';
  grid.style.setProperty('--cols', nC);

  spec.rows.forEach((label, q) => {
    const lbl = document.createElement('div');
    lbl.className = 'mc-rowlabel';
    lbl.style.gridRow = (q+1);
    lbl.style.gridColumn = 1;
    lbl.textContent = label;
    grid.appendChild(lbl);

    // wire background line per qubit, spanning all step columns
    const wire = document.createElement('div');
    wire.className = 'mc-wirebg';
    wire.style.gridRow = (q+1);
    wire.style.gridColumn = `2 / ${nC + 2}`;
    grid.appendChild(wire);
  });

  spec.steps.forEach((step, ci) => {
    const col = ci + 2;
    step.forEach(p => {
      if(p.cnot){
        const [c, t] = p.cnot;
        const lo = Math.min(c, t), hi = Math.max(c, t);
        const v = document.createElement('div');
        v.className = 'mc-vline';
        v.style.gridRow = `${lo+1} / ${hi+2}`;
        v.style.gridColumn = col;
        grid.appendChild(v);
        const ctrl = document.createElement('div');
        ctrl.className = 'mc-cell';
        ctrl.style.gridRow = c+1;
        ctrl.style.gridColumn = col;
        ctrl.innerHTML = '<span class="mc-ctrl"></span>';
        grid.appendChild(ctrl);
        const targ = document.createElement('div');
        targ.className = 'mc-cell';
        targ.style.gridRow = t+1;
        targ.style.gridColumn = col;
        if(p.label){
          const cls = 'mc-gate' + (p.cls ? ' ' + p.cls : '');
          targ.innerHTML = `<span class="${cls}">${p.label}</span>`;
        } else {
          targ.innerHTML = '<span class="mc-targ">⊕</span>';
        }
        grid.appendChild(targ);
      } else if(p.swap){
        const [a, b] = p.swap;
        const lo = Math.min(a, b), hi = Math.max(a, b);
        const v = document.createElement('div');
        v.className = 'mc-vline';
        v.style.gridRow = `${lo+1} / ${hi+2}`;
        v.style.gridColumn = col;
        grid.appendChild(v);
        [a, b].forEach(qq => {
          const cell = document.createElement('div');
          cell.className = 'mc-cell';
          cell.style.gridRow = qq+1;
          cell.style.gridColumn = col;
          cell.innerHTML = '<span class="mc-cross">×</span>';
          grid.appendChild(cell);
        });
      } else if(p.span){
        const [from, to] = p.span;
        const cell = document.createElement('div');
        cell.className = 'mc-cell mc-spangate';
        cell.style.gridRow = `${from+1} / ${to+2}`;
        cell.style.gridColumn = col;
        const box = document.createElement('span');
        box.className = 'mc-gate ' + (p.cls || 'oracle');
        box.textContent = p.gate;
        cell.appendChild(box);
        grid.appendChild(cell);
      } else {
        // classical-control wire from a measured qubit down to this gate
        if(p.cc !== undefined){
          const lo = Math.min(p.cc, p.q), hi = Math.max(p.cc, p.q);
          const cl = document.createElement('div');
          cl.className = 'mc-ccline';
          cl.style.gridRow = `${lo+1} / ${hi+2}`;
          cl.style.gridColumn = col;
          grid.appendChild(cl);
          const node = document.createElement('div');
          node.className = 'mc-cell';
          node.style.gridRow = p.cc+1;
          node.style.gridColumn = col;
          node.innerHTML = '<span class="mc-cctrl"></span>';
          grid.appendChild(node);
        }
        const cell = document.createElement('div');
        cell.className = 'mc-cell';
        cell.style.gridRow = p.q+1;
        cell.style.gridColumn = col;
        const box = document.createElement('span');
        box.className = 'mc-gate' + (p.cls ? ' ' + p.cls : '');
        box.textContent = p.gate;
        cell.appendChild(box);
        grid.appendChild(cell);
      }
    });
  });

  host.appendChild(grid);
  if(caption){
    const cap = document.createElement('div');
    cap.className = 'mc-caption';
    cap.textContent = caption;
    host.appendChild(cap);
  }
}

const ALGO_CIRCUITS = {
  coin: {
    spec: {
      rows: ['q0: |0⟩'],
      steps: [
        [{q:0, gate:'H'}],
        [{q:0, gate:'M', cls:'meas'}],
      ],
    },
    caption: 'H xoay |0⟩ thành một chồng chập đều; phép đo sụp về 0 hoặc 1 với xác suất 50/50.',
  },
  grover: {
    spec: {
      rows: ['q0: |0⟩', 'q1: |0⟩'],
      steps: [
        [{q:0, gate:'H'}, {q:1, gate:'H'}],
        [{span:[0,1], gate:'Oracle Uω', cls:'oracle'}],
        [{span:[0,1], gate:'Diffusion', cls:'diff'}],
        [{q:0, gate:'M', cls:'meas'}, {q:1, gate:'M', cls:'meas'}],
      ],
    },
    caption: 'Các cổng Hadamard tạo một chồng chập đều trên cả 4 đầu vào. Oracle đánh dấu mục tiêu bằng cách lật pha của nó; toán tử khuếch tán (diffusion) phóng đại biên độ đã được đánh dấu. Với N = 4 chỉ cần một vòng lặp là đủ.',
  },
  dj: {
    spec: {
      rows: ['q0: |0⟩', 'q1: |1⟩'],
      steps: [
        [{q:0, gate:'H'}, {q:1, gate:'H'}],
        [{span:[0,1], gate:'Uf', cls:'oracle'}],
        [{q:0, gate:'H'}],
        [{q:0, gate:'M', cls:'meas'}],
      ],
    },
    caption: 'Qubit truy vấn đi qua H–Uf–H. Hiệu ứng đá pha (phase kickback) từ qubit phụ |1⟩ khiến phép đo cuối cùng cho kết quả 0 nếu f hằng số và 1 nếu f cân bằng — chỉ cần một truy vấn là xong.',
  },
  tele: {
    spec: {
      rows: ['q0: |ψ⟩', 'q1: |0⟩', 'q2: |0⟩'],
      steps: [
        [{q:1, gate:'H'}],
        [{cnot:[1,2]}],
        [{cnot:[0,1]}],
        [{q:0, gate:'H'}],
        [{q:0, gate:'M', cls:'meas'}],
        [{q:1, gate:'M', cls:'meas'}],
        [{q:2, gate:'X^m2', cls:'cond', cc:1}],
        [{q:2, gate:'Z^m1', cls:'cond', cc:0}],
      ],
    },
    caption: 'Cột 1–2 tạo cặp Bell dùng chung trên q1/q2. Cột 3–4 là phép đổi sang cơ sở Bell của Alice. Cột 5–6 đo các qubit của Alice → m1,m2. Cột 7–8 là các phép hiệu chỉnh được điều khiển cổ điển của Bob (dây đôi): X được kích hoạt bởi m2 (kết quả của q1), Z bởi m1 (kết quả của q0) — lúc này q2 đang giữ |ψ⟩.',
  },
  qft: {
    spec: {
      rows: ['q0: |x0⟩', 'q1: |x1⟩', 'q2: |x2⟩'],
      steps: [
        [{q:0, gate:'H'}],
        [{cnot:[1,0], label:'R2', cls:'qft'}],
        [{cnot:[2,0], label:'R3', cls:'qft'}],
        [{q:1, gate:'H'}],
        [{cnot:[2,1], label:'R2', cls:'qft'}],
        [{q:2, gate:'H'}],
        [{swap:[0,2]}],
      ],
    },
    caption: 'Với mỗi qubit: một cổng Hadamard rồi đến các phép quay pha có điều khiển Rk = diag(1, e^(2πi/2k)) từ mọi qubit phía sau. Một cổng SWAP ở cuối đảo ngược thứ tự bit. Toàn mạch chỉ cần O(n2) cổng cho một thanh ghi n qubit.',
  },
  shor: {
    spec: {
      rows: ['Thanh ghi 1: |0⟩n', 'Thanh ghi 2: |0⟩m'],
      steps: [
        [{q:0, gate:'H⊗n'}],
        [{span:[0,1], gate:'ax mod N', cls:'oracle'}],
        [{q:0, gate:'QFT−1', cls:'qft'}],
        [{q:0, gate:'M', cls:'meas'}],
      ],
    },
    caption: 'Thanh ghi 1 được đưa vào chồng chập đều trên x. Oracle luỹ thừa mô-đun làm rối Thanh ghi 1 với f(x)=ax mod N. QFT nghịch đảo trích ra chu kỳ r — phần còn lại của Shor là xử lý hậu kỳ cổ điển (các gcd).',
  },
  bv: {
    spec: {
      rows: ['x: |0⟩n', 'y: |1⟩'],
      steps: [
        [{q:0, gate:'H⊗n'}, {q:1, gate:'H'}],
        [{span:[0,1], gate:'Uf', cls:'oracle'}],
        [{q:0, gate:'H⊗n'}],
        [{q:0, gate:'M', cls:'meas'}],
      ],
    },
    caption: 'Hiệu ứng đá pha ghi chuỗi bí mật n bit s lên các pha tương đối của thanh ghi dữ liệu. Phép H⊗n cuối cùng biến các pha đó thành một trạng thái cơ sở duy nhất — đo thanh ghi dữ liệu sẽ đọc trực tiếp ra s.',
  },
  simon: {
    spec: {
      rows: ['x: |0⟩n', 'y: |0⟩n'],
      steps: [
        [{q:0, gate:'H⊗n'}],
        [{span:[0,1], gate:'Uf', cls:'oracle'}],
        [{q:1, gate:'M', cls:'meas'}],
        [{q:0, gate:'H⊗n'}],
        [{q:0, gate:'M', cls:'meas'}],
      ],
    },
    caption: 'Sau oracle, thanh ghi dữ liệu sụp (sau khi đo y) về lớp cùng dư hai phần tử {x, x⊕s}. Phép H⊗n thứ hai tạo một mẫu đều trên các y thoả mãn y·s = 0. n−1 mẫu như vậy cùng phép khử Gauss cổ điển sẽ khôi phục s.',
  },
  vqe: {
    spec: {
      rows: ['q0: |0⟩', 'q1: |0⟩'],
      steps: [
        [{q:0, gate:'Ry(θ1)', cls:'rot'}, {q:1, gate:'Ry(θ2)', cls:'rot'}],
        [{cnot:[0,1]}],
        [{q:0, gate:'Ry(θ3)', cls:'rot'}, {q:1, gate:'Ry(θ4)', cls:'rot'}],
        [{q:0, gate:'⟨H⟩', cls:'meas'}, {q:1, gate:'⟨H⟩', cls:'meas'}],
      ],
    },
    caption: 'Một ansatz "thân thiện với phần cứng" đơn giản — các lớp xen kẽ gồm phép quay một qubit và cổng tạo rối. Giá trị kỳ vọng ⟨H⟩ = ⟨ψ(θ)|Ĥ|ψ(θ)⟩ được lấy mẫu và đưa vào bộ tối ưu cổ điển để cập nhật θ. Lặp lại cho đến khi năng lượng hội tụ.',
  },
  qaoa: {
    spec: {
      rows: ['q0: |0⟩', 'q1: |0⟩'],
      steps: [
        [{q:0, gate:'H'}, {q:1, gate:'H'}],
        [{span:[0,1], gate:'e^{−iγ H_C}', cls:'oracle'}],
        [{q:0, gate:'Rx(2β)', cls:'rot'}, {q:1, gate:'Rx(2β)', cls:'rot'}],
        [{q:0, gate:'M', cls:'meas'}, {q:1, gate:'M', cls:'meas'}],
      ],
    },
    caption: 'Một lớp QAOA: tiến hoá theo Hamiltonian chi phí trong thời gian γ (ví dụ các liên kết ZZ trên đồ thị bài toán), rồi tiến hoá theo Hamiltonian trộn trong thời gian β (Rx trên mỗi qubit). Xếp chồng p lớp; bộ tối ưu cổ điển chỉnh 2p tham số (γ_k, β_k) để tối đa hoá chi phí lấy mẫu được.',
  },
};

// ----- Algorithms -----
function initAlgorithms(){
  // Render one circuit per tab.
  Object.entries(ALGO_CIRCUITS).forEach(([key, info]) => {
    const host = document.getElementById('circ-' + key);
    if(host) renderMiniCircuit(host, info.spec, info.caption);
  });
  // Tab switching
  document.querySelectorAll('.tab-btn').forEach(b => {
    b.onclick = () => {
      document.querySelectorAll('.tab-btn').forEach(x => x.classList.toggle('active', x===b));
      document.querySelectorAll('.tab-panel').forEach(p => p.classList.add('hidden'));
      document.getElementById('tab-' + b.dataset.tab).classList.remove('hidden');
    };
  });

  // Coin flip
  const coinEl = document.getElementById('coin-result');
  document.getElementById('coin-flip').onclick = () => {
    coinEl.classList.remove('flipping');
    void coinEl.offsetWidth;
    coinEl.classList.add('flipping');
    setTimeout(() => coinEl.textContent = Math.random() < 0.5 ? '0' : '1', 700);
  };

  // Grover
  const boxes = document.getElementById('grover-boxes');
  const gMsg = document.getElementById('grover-msg');
  function paintBoxes(target=-1){
    boxes.innerHTML = '';
    for(let i=0;i<4;i++){
      const d = document.createElement('div');
      d.className = 'grover-box' + (i===target ? ' target':'');
      d.textContent = i===target ? '★' : '·';
      boxes.appendChild(d);
    }
  }
  paintBoxes();
  document.getElementById('grover-run').onclick = () => {
    const target = Math.floor(Math.random()*4);
    paintBoxes();
    gMsg.textContent = 'Đang tìm… khuếch đại biên độ…';
    setTimeout(() => {
      paintBoxes(target);
      gMsg.textContent = `Tìm thấy ★ ở hộp ${target} chỉ sau 1 bước lượng tử. Tìm kiếm cổ điển phải lật tới 4 lần.`;
    }, 700);
  };

  // Deutsch-Jozsa
  let djFn = null;
  const djMsg = document.getElementById('dj-msg');
  document.getElementById('dj-new').onclick = () => {
    const isConstant = Math.random() < 0.5;
    if(isConstant){
      const c = Math.random() < 0.5 ? 0 : 1;
      djFn = {type:'constant', value:c};
    }else{
      const flip = Math.random() < 0.5;
      djFn = {type:'balanced', flip};
    }
    djMsg.textContent = 'Đã tạo hàm ẩn. Nhấn Chạy.';
  };
  document.getElementById('dj-run').onclick = () => {
    if(!djFn){ djMsg.textContent = 'Hãy tạo hàm trước.'; return; }
    djMsg.textContent = `Một lần hỏi lượng tử → đáp án: ${djFn.type === 'constant' ? 'HẰNG ĐỊNH' : 'CÂN BẰNG'}.`;
  };

  // Teleportation
  document.getElementById('tele-run').onclick = () => {
    const stepsEl = document.getElementById('tele-steps');
    stepsEl.innerHTML = '';
    const m1 = Math.random() < 0.5 ? 0 : 1;
    const m2 = Math.random() < 0.5 ? 0 : 1;
    const correction = (m1 ? 'Z' : 'I') + ' · ' + (m2 ? 'X' : 'I');
    const steps = [
      '① Alice có một qubit bí ẩn |ψ⟩ muốn gửi cho Bob.',
      '② Hai người dùng chung một cặp Bell vướng víu: H trên q1, rồi CNOT(q1→q2). q1 ở lại với Alice, q2 gửi cho Bob.',
      '③ Alice áp dụng CNOT(ψ → nửa của mình) rồi H lên ψ.',
      `④ Alice đo cả hai qubit của mình → m₁ = ${m1}, m₂ = ${m2}. Gửi 2 bit cổ điển này cho Bob.`,
      `⑤ Bob áp dụng phép hiệu chỉnh (${correction}) lên qubit của mình. Nó giờ ở trạng thái |ψ⟩.`,
      '✓ Dịch chuyển hoàn tất. Qubit gốc của Alice đã sụp (không-nhân-bản) — chỉ có *trạng thái* được di chuyển.',
    ];
    steps.forEach((s,i) => setTimeout(() => {
      const d = document.createElement('div');
      d.className = 'tele-step' + (i === steps.length-1 ? ' last' : '');
      d.textContent = s;
      stepsEl.appendChild(d);
    }, i*650));
  };

  // Deutsch (1-bit)
  (() => {
    const fns = [
      {id:0, label:'f₀: f(x)=0',   type:'constant', f:(x)=>0},
      {id:1, label:'f₁: f(x)=1',   type:'constant', f:(x)=>1},
      {id:2, label:'f₂: f(x)=x',   type:'balanced', f:(x)=>x},
      {id:3, label:'f₃: f(x)=1−x', type:'balanced', f:(x)=>1-x},
    ];
    let pickedId = 0;
    const btns   = document.querySelectorAll('.deutsch-f');
    const circEl = document.getElementById('deutsch-circuit');
    const stepsEl= document.getElementById('deutsch-steps');
    const runBtn = document.getElementById('deutsch-run');
    if(!circEl || !runBtn) return;

    function drawCircuit(){
      circEl.innerHTML = `
        <div class="dc-grid">
          <span class="dc-wire-label" style="grid-area:1/1">q₀ (dữ liệu)</span>
          <span class="dc-init"  style="grid-area:1/2">|0⟩</span>
          <span class="dc-gate"  style="grid-area:1/3">H</span>
          <span class="dc-oracle dc-oracle-span" style="grid-area:1/4/3/5" title="Oracle U_f — một cổng 2-qubit; bảng chân trị của nó mã hoá hàm f đã chọn">Uƒ</span>
          <span class="dc-gate"  style="grid-area:1/5">H</span>
          <span class="dc-meter" style="grid-area:1/6">M</span>
          <span class="dc-wire-label" style="grid-area:2/1">q₁ (ancilla)</span>
          <span class="dc-init"  style="grid-area:2/2">|1⟩</span>
          <span class="dc-gate"  style="grid-area:2/3">H</span>
        </div>
      `;
    }
    drawCircuit();

    btns.forEach(b => b.onclick = () => {
      btns.forEach(z => z.classList.toggle('active', z === b));
      pickedId = parseInt(b.dataset.fid, 10);
      stepsEl.innerHTML = '';
    });

    runBtn.onclick = () => {
      const f = fns[pickedId];
      const f0 = f.f(0), f1 = f.f(1);
      const d  = f0 ^ f1;
      const meas = d;             // 0 → constant, 1 → balanced
      const verdict = d === 0 ? 'HẰNG ĐỊNH' : 'CÂN BẰNG';
      stepsEl.innerHTML = '';
      const lines = [
        `① Chọn: ${f.label}  →  f(0)=${f0}, f(1)=${f1}.`,
        `② Chuẩn bị |ψ₀⟩ = |0⟩|1⟩, rồi H⊗H  →  |ψ₁⟩ = |+⟩|−⟩.`,
        `③ Oracle (bắn ngược pha):  Uƒ|x⟩|−⟩ = (−1)^f(x) |x⟩|−⟩.`,
        `   ⟹  |ψ₂⟩ = (1/√2) [ (−1)^${f0} |0⟩ + (−1)^${f1} |1⟩ ] ⊗ |−⟩`,
        `④ Rút nhân tử (−1)^f(0):  qubit dữ liệu = (1/√2) [ |0⟩ + (−1)^${d} |1⟩ ] = ${d===0?'|+⟩':'|−⟩'}.`,
        `⑤ H lên qubit dữ liệu:  ${d===0?'H|+⟩ = |0⟩':'H|−⟩ = |1⟩'}.`,
        `✓ Đo được ${meas} sau 1 lần gọi oracle  →  f là ${verdict}.   (cổ điển cần 2 lần hỏi)`,
      ];
      lines.forEach((s,i) => setTimeout(() => {
        const el = document.createElement('div');
        el.className = 'tele-step' + (i === lines.length-1 ? ' last' : '');
        el.textContent = s;
        stepsEl.appendChild(el);
      }, i*500));
    };
  })();

  // QFT — 3-qubit Quantum Fourier Transform on a single basis state |x⟩.
  (() => {
    const N = 8; // 2³
    const inputsHost = document.getElementById('qft-inputs');
    const resultsEl  = document.getElementById('qft-results');
    const msg        = document.getElementById('qft-msg');
    if(!inputsHost) return;
    inputsHost.innerHTML = '';
    for(let x=0; x<N; x++){
      const b = document.createElement('button');
      b.className = 'qft-input' + (x===1 ? ' active' : '');
      b.dataset.x = x;
      b.textContent = `|${x}⟩`;
      b.onclick = () => {
        document.querySelectorAll('.qft-input').forEach(z =>
          z.classList.toggle('active', z === b));
        run(x);
      };
      inputsHost.appendChild(b);
    }

    function fmtPhase(theta){
      // Show phase as a multiple of π/4 (since 2π·xk/8 always lands on multiples of π/4).
      const k = Math.round(theta / (Math.PI/4)) % 8;
      const m = ((k % 8) + 8) % 8;
      const tab = ['0', 'π/4', 'π/2', '3π/4', 'π', '5π/4', '3π/2', '7π/4'];
      return tab[m];
    }

    function run(x){
      resultsEl.innerHTML = '';
      const mag = 1/Math.sqrt(N);
      for(let k=0; k<N; k++){
        const theta = (2 * Math.PI * x * k / N) % (2*Math.PI);
        const deg = theta * 180 / Math.PI;
        const bin = document.createElement('div');
        bin.className = 'qft-bin';
        bin.innerHTML = `
          <div class="qft-clock"><div class="qft-clock-arm" style="transform:translate(0,-50%) rotate(${-deg}deg)"></div></div>
          <div class="qft-phase">e^(i·${fmtPhase(theta)})</div>
          <div class="qft-bar"><div class="qft-bar-fill" style="height:${mag*mag*N*100}%"></div></div>
          <div class="qft-label">|${k}⟩</div>`;
        resultsEl.appendChild(bin);
      }
      msg.innerHTML = x === 0
        ? `QFT|0⟩ = (1/√8)·Σ|k⟩ — chồng chập đều với mọi pha bằng 0.`
        : `QFT|${x}⟩ = (1/√8)·Σ e^(2πi·${x}k/8)·|k⟩ — độ lớn đều, pha xoay thêm ${x}·2π/8 mỗi bước. "Tốc độ" xoay của pha mã hoá giá trị x.`;
    }

    run(1);
  })();

  // Shor (factor 15)
  const gcd = (a,b) => { a=Math.abs(a); b=Math.abs(b); while(b){ [a,b]=[b,a%b]; } return a; };
  document.getElementById('shor-run').onclick = () => {
    const out = document.getElementById('shor-out');
    const N = 15;
    const candidates = [2,4,7,8,11,13,14].filter(a => gcd(a,N) === 1);
    const a = candidates[Math.floor(Math.random()*candidates.length)];

    // Find period r classically (the quantum part finds it exponentially faster)
    let r = 1, val = a % N;
    while(val !== 1){ val = (val*a) % N; r++; if(r>50){ break; } }

    let txt = `Bước 1 · Chọn ngẫu nhiên a nguyên tố cùng nhau với N=15 → a = ${a}.\n`;
    txt += `Bước 2 · Tìm chu kỳ lượng tử (phần "ma thuật") trả về r = ${r},\n`;
    txt += `         r nhỏ nhất sao cho a^r mod 15 = 1.\n`;
    if(r % 2 !== 0){
      txt += `Bước 3 · r lẻ — chọn a khác rồi thử lại.`;
    } else {
      const half = Math.pow(a, r/2);
      const f1 = gcd(half - 1, N);
      const f2 = gcd(half + 1, N);
      txt += `Bước 3 · Tính  gcd(${a}^${r/2} − 1, 15) = ${f1}\n`;
      txt += `                  gcd(${a}^${r/2} + 1, 15) = ${f2}\n`;
      if(f1 > 1 && f1 < N && f2 > 1 && f2 < N){
        txt += `\n✓ Tìm được các thừa số của 15:  15 = ${f1} × ${f2}.`;
      } else {
        txt += `\n…thừa số tầm thường — chọn a khác rồi thử lại.`;
      }
    }
    out.textContent = txt;
  };
}

// ----- Final challenge -----
function initChallenge(){
  const status = document.getElementById('challenge-status');
  const area = document.getElementById('challenge-area');
  const done = MODULES.filter(m => progress[m].done).length;
  if(done < 6){
    status.textContent = `Đang khoá — hoàn thành thêm ${6-done} module nữa để mở khoá.`;
    area.innerHTML = '';
    return;
  }
  status.textContent = 'Đã mở khoá! 5 câu hỏi hỗn hợp đang chờ bạn.';
  renderQuiz('challenge', FINAL_QUIZ, area, score => {
    if(!progress.challenge.done){
      progress.challenge.done = true;
      progress.challenge.score = score;
      save(); render();
      toast('🏆 Đã đạt huy hiệu Nhà thám hiểm Lượng tử!');
    } else {
      progress.challenge.score = Math.max(progress.challenge.score, score);
      save(); render();
    }
  });
}

// ============================================================
// Init
// ============================================================
function init(){
  renderGlossary();
  renderFaq();
  initQubits();
  initBloch();
  initSuperposition();
  initEntanglement();
  initBell();
  initMeasurement();
  initGates();
  initCircuits();
  initKickback();
  initNoise();
  initQEC();
  initAlgorithms();
  initParadox();
  initCrypto();
  attachQuizzes();
  initChallenge();
  render();

  // Re-init challenge when navigated to (in case progress changed)
  window.addEventListener('hashchange', () => {
    if(location.hash === '#challenge') initChallenge();
  });

  showSection((location.hash || '#qubits').slice(1));

  // Nút "Sao chép" cho các khối mã (module Qiskit)
  document.querySelectorAll('.code-block').forEach(block => {
    const btn = block.querySelector('.copy-btn');
    const code = block.querySelector('code');
    if(!btn || !code) return;
    btn.addEventListener('click', () => {
      const text = code.textContent;
      const done = () => { btn.textContent = 'Đã sao chép ✓'; btn.classList.add('ok');
        setTimeout(() => { btn.textContent = 'Sao chép'; btn.classList.remove('ok'); }, 1600); };
      if(navigator.clipboard && navigator.clipboard.writeText){
        navigator.clipboard.writeText(text).then(done).catch(() => fallbackCopy(text, done));
      } else fallbackCopy(text, done);
    });
  });
  function fallbackCopy(text, done){
    const ta = document.createElement('textarea');
    ta.value = text; ta.style.position = 'fixed'; ta.style.opacity = '0';
    document.body.appendChild(ta); ta.select();
    try{ document.execCommand('copy'); done(); }catch{}
    ta.remove();
  }
}

document.addEventListener('DOMContentLoaded', init);

})();
