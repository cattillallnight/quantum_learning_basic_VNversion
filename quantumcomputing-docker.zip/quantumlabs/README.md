<div align="center">

# QuantumLab cho Người mới bắt đầu

[![HTML5](https://img.shields.io/badge/HTML5-E34F26?logo=html5&logoColor=white)](https://developer.mozilla.org/docs/Web/HTML)
[![CSS3](https://img.shields.io/badge/CSS3-1572B6?logo=css3&logoColor=white)](https://developer.mozilla.org/docs/Web/CSS)
[![JavaScript](https://img.shields.io/badge/JavaScript-F7DF1E?logo=javascript&logoColor=000)](https://developer.mozilla.org/docs/Web/JavaScript)
[![No backend](https://img.shields.io/badge/không_backend-10b981)](#)
[![License: MIT](https://img.shields.io/badge/Giấy_phép-MIT-blue.svg)](LICENSE)

**Học Điện toán Lượng tử qua Hình ảnh — bài học tương tác, trình mô phỏng, nghịch lý &amp; thuật toán ngay trong trình duyệt.**

> Đây là bản dịch tiếng Việt của [quantumlabs](https://github.com/alfredang/quantumlabs) (MIT), có bổ sung **Trợ lý AI** chạy bằng Ollama cục bộ.

</div>

## Ảnh chụp màn hình

![Screenshot](screenshot.png)

## Giới thiệu

**QuantumLab cho Người mới bắt đầu** là một ứng dụng web thuần frontend, khép kín, giúp học
điện toán lượng tử qua những bản demo nhỏ, tương tác. Mỗi khái niệm có một sân chơi trực quan
riêng — thanh trượt, trình dựng mạch kéo-thả, bảng đọc vector trạng thái trực tiếp, trình mô
phỏng nghịch lý — để bạn xây dựng trực giác trước khi đụng tới toán.

Toàn bộ ứng dụng chạy trong trình duyệt. Không backend, không cơ sở dữ liệu, không API ngoài.
Tiến độ được lưu trong `localStorage`.

### Tính năng chính

- **24 mục nội dung** trải từ nền tảng tới nâng cao — từ toán học &amp; các tiên đề đến thuật
  toán, nghịch lý, mật mã và sửa lỗi.
- **Trình mô phỏng tương tác** cho mọi chủ đề: nút gạt qubit trên đĩa Bloch, thanh trượt xác
  suất với ký hiệu Dirac trực tiếp, vướng víu cặp Bell, kiểm tra bất đẳng thức CHSH, trình dựng
  mạch nhiều qubit kéo-thả với bộ cổng đầy đủ, khám phá phase-kickback, phân phối khóa BB84,
  mô phỏng Monte-Carlo sửa lỗi 3 qubit, lan truyền nhiễu trên kênh.
- **Thuật toán lượng tử** kèm sơ đồ mạch: Tung đồng xu, Grover, Deutsch–Jozsa, Dịch chuyển
  trạng thái, QFT, phân tích thừa số Shor.
- **Nghịch lý lượng tử** kèm sơ đồ SVG bố trí thí nghiệm: Mèo Schrödinger, Bạn của Wigner,
  Frauchiger–Renner, Cục tẩy lượng tử, Cục tẩy lựa chọn trễ, Hiệu ứng Zeno lượng tử.
- **Trắc nghiệm theo mô-đun** với theo dõi điểm, thanh tiến độ, huy hiệu, và thử thách cuối cùng
  mở khóa khi hoàn thành 6/8 mô-đun.
- **Trình bày công thức kiểu LaTeX** cho ký hiệu Dirac, phân số, ma trận và phương trình toán tử.
- **Giao diện tối, hiện đại**, responsive xuống tới di động.
- **Trợ lý AI (bổ sung)** — chatbot trả lời được cả câu hỏi lượng tử lẫn câu hỏi ngoài lề, chạy
  bằng Ollama cục bộ (`gemma4:e2b`), có chế độ dự phòng offline khi không có Ollama.

## Công nghệ

| Loại        | Công nghệ                                                       |
|-------------|-----------------------------------------------------------------|
| Đánh dấu    | HTML5                                                           |
| Giao diện   | CSS3 (biến CSS, grid, flex, hoạt hình keyframe)                 |
| Logic       | JavaScript thuần (ES2020, một IIFE duy nhất, không bước build)  |
| Font toán   | STIX Two Math / Cambria Math / Times New Roman dự phòng         |
| Lưu trữ     | `localStorage` (tiến độ, điểm, huy hiệu)                        |
| Sơ đồ       | SVG nội tuyến, Canvas HTML5 (biểu đồ &amp; hoạt hình)           |
| Trợ lý AI   | Ollama cục bộ qua `http://127.0.0.1:11434` (tùy chọn)           |

**Không phụ thuộc gì.** Không framework, không bundler, không CDN.

## Bắt đầu

### Yêu cầu

Một trình duyệt hiện đại (Chrome, Firefox, Safari, Edge). Không cần gì thêm.

### Chạy cục bộ

```bash
git clone https://github.com/alfredang/quantumlabs.git
cd quantumlabs

# Hoặc mở thẳng index.html, hoặc phục vụ qua HTTP:
python3 -m http.server 8000
# rồi truy cập http://localhost:8000
```

Vậy là xong. Không có bước cài đặt nào.

### Chạy bằng Docker

```bash
docker compose up -d
# rồi truy cập http://localhost:8080
```

Hoặc thủ công:

```bash
docker build -t quantumlabs .
docker run -d -p 8080:80 --name quantumlabs quantumlabs
```

> **Lưu ý về chatbot trong Docker:** trình duyệt của bạn gọi thẳng tới Ollama tại
> `http://127.0.0.1:11434` — Ollama chạy trên máy bạn chứ không nằm trong container, nên
> chatbot vẫn hoạt động bình thường khi trang được phục vụ từ Docker. Nếu Ollama chạy trên
> máy khác, đặt URL qua `localStorage` khóa `quantumlab.ollamaUrl`.

### Bật Trợ lý AI (tùy chọn)

Trợ lý AI hoạt động ở hai chế độ:

1. **Chế độ AI đầy đủ** — cần [Ollama](https://ollama.com) chạy cục bộ:
   ```bash
   ollama serve
   ollama pull gemma4:e2b
   ```
   Sau đó mở trang và bấm nút **Trợ lý AI** ở góc dưới bên phải.

2. **Chế độ dự phòng** — nếu không kết nối được Ollama, trợ lý vẫn trả lời các khái niệm có sẵn
   trong khóa học (lấy từ bảng thuật ngữ và nội dung phần đang mở).

Đổi địa chỉ Ollama bằng cách đặt `localStorage` khóa `quantumlab.ollamaUrl`.

## Triển khai

### Bất kỳ đâu (chỉ là file tĩnh)

Thả các file (`index.html`, `style.css`, `script.js`, `chatbot.js`) lên bất kỳ host tĩnh nào:
Netlify, Vercel, S3, Cloudflare Pages, nginx của riêng bạn — bất cứ đâu phục vụ file.

## Các mô-đun trong khóa

| #  | Mô-đun                 | Loại      | Điểm nhấn                                          |
|----|------------------------|-----------|----------------------------------------------------|
| —  | Kiến thức Toán học     | Tham khảo | Vector, số phức, Hermitian, unitary                |
| —  | Tiên đề Cơ học Lượng tử| Tham khảo | Năm tiên đề kèm công thức                          |
| —  | Ma trận Mật độ         | Tham khảo | Trạng thái hỗn hợp, vết riêng phần, thanh khiết    |
| —  | Lịch sử Cơ học Lượng tử| Tham khảo | Dòng thời gian từ Planck tới nay                   |
| 1  | Qubit                  | Trắc nghiệm | Nút gạt đĩa Bloch 0/1/chồng chập                 |
| 2  | Chồng chập             | Trắc nghiệm | Thanh trượt xác suất + bảng Dirac trực tiếp      |
| 3  | Rối lượng tử           | Trắc nghiệm | Cặp Bell + bảng vector trạng thái động           |
| —  | Bất đẳng thức Bell     | Demo      | Đồng hồ CHSH — chặn 2 vs 2√2                       |
| 4  | Phép đo                | Trắc nghiệm | Biểu đồ đo lặp lại + bảng Dirac                  |
| —  | Cổng lượng tử          | Tham khảo | Thư viện cổng: ma trận · tác dụng · giải thích      |
| 5  | Mạch lượng tử          | Trắc nghiệm | Trình dựng kéo-thả, mô phỏng 2ⁿ                  |
| —  | Đá ngược pha           | Demo      | So sánh 4 trạng thái đích → kickback               |
| 6  | Thuật toán lượng tử    | Trắc nghiệm | Xu / Grover / DJ / Teleport / QFT / Shor         |
| —  | Nghịch lý lượng tử     | Demo      | 6 nghịch lý kèm SVG thí nghiệm                     |
| —  | Thông tin lượng tử     | Tham khảo | Entropy von Neumann, định lý không-nhân-bản        |
| —  | Mật mã lượng tử        | Demo      | Giao thức BB84 với nút bật/tắt Eve                 |
| —  | An ninh hậu lượng tử   | Tham khảo | Mật mã dựa trên lưới, ML-KEM/ML-DSA                |
| 7  | Nhiễu                  | Trắc nghiệm | Kênh lật bit nhiều bước                          |
| 8  | Sửa lỗi lượng tử (QEC) | Trắc nghiệm | Mã lật bit 3 qubit + Monte Carlo                 |

## Điểm khác biệt so với bản gốc

- Toàn bộ nội dung giao diện, mô-đun, câu hỏi trắc nghiệm và thuật ngữ đã **dịch sang tiếng Việt**.
- Thêm **`chatbot.js`** — trợ lý AI tự chứa, tự dò Ollama, tự dựng giao diện, trả lời được cả
  câu hỏi ngoài lề (toán, lập trình, đời sống…), tự lấy ngữ cảnh từ phần đang mở.
- Thêm module **Lập trình với Qiskit** — code Python thật (Bell, Grover, chạy trên QPU), bảng tra
  API Qiskit 1.0+, các lỗi người mới hay gặp, kèm trắc nghiệm riêng.
- Thêm CSS tương ứng trong `style.css` cho trợ lý AI và khối mã.

## Cấu trúc project

```
quantumlabs/
├── index.html          # Vỏ SPA — điều hướng sidebar + 25 mục nội dung (tiếng Việt)
├── style.css           # Chủ đề tối hiện đại, layout responsive, hoạt hình
├── script.js           # Toàn bộ logic — router, mô phỏng, engine trắc nghiệm, lưu trữ
├── chatbot.js          # Trợ lý AI Ollama (bổ sung)
├── Dockerfile          # Đóng gói Docker (nginx)
├── docker-compose.yml  # Chạy 1 lệnh: docker compose up
├── screenshot.png      # Ảnh README
└── README.md           # File này
```

## Phát triển bởi (bản gốc)

**Tertiary Infotech Academy Pte Ltd**
[https://www.tertiarycourses.com.sg/](https://www.tertiarycourses.com.sg/)

## Ghi nhận

- Lấy cảm hứng từ Q-CTRL Black Opal, IBM Quantum Composer và Microsoft Quantum Katas.
- Kiểu chữ toán dùng STIX Two Math / Cambria Math (không MathJax/KaTeX).
- Mọi mô phỏng lượng tử đều được viết tay bằng JavaScript thuần ở mức độ phù hợp người mới.

---

Nếu bạn thấy hữu ích, hãy ⭐ repo nhé!
