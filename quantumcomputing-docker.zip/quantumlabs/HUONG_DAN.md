# QuantumLab — Hướng dẫn chạy từ file ZIP

Nền tảng học điện toán lượng tử bằng tiếng Việt, có Trợ lý AI cục bộ.
Toàn bộ chạy bằng Docker — không cần cài Python, Node hay thư viện nào.

## Yêu cầu

| Thành phần | Bắt buộc? | Ghi chú |
|---|---|---|
| Docker Desktop | **Có** | Tải tại https://www.docker.com/products/docker-desktop/ |
| Ollama | Tùy chọn | Tải tại https://ollama.com — cần cho Trợ lý AI đầy đủ |

## Bước 1 — Giải nén

Giải nén file ZIP vào một thư mục bất kỳ, ví dụ `D:\quantumlabs`. Sau khi
giải nén bạn sẽ thấy:

```
quantumlabs/
├── index.html            # Trang chính (tiếng Việt)
├── style.css             # Giao diện
├── script.js             # Logic mô phỏng lượng tử
├── chatbot.js            # Trợ lý AI
├── Dockerfile            # Công thức đóng gói Docker
├── docker-compose.yml    # Cấu hình chạy 1 lệnh
├── .dockerignore
├── README.md             # Tài liệu dự án
├── screenshot.png
└── HUONG_DAN.md          # File này
```

## Bước 2 — Chạy bằng Docker

Mở PowerShell (hoặc Terminal) tại thư mục vừa giải nén:

```powershell
docker compose up -d
```

Lần đầu chạy sẽ mất khoảng 30 giây để tải image nginx. Khi xong, mở
trình duyệt truy cập:

**http://localhost:8080**

Cách khác (không dùng compose):

```powershell
docker build -t quantumlabs .
docker run -d -p 8080:80 --name quantumlabs quantumlabs
```

Dừng/ gỡ container:

```powershell
docker compose down        # khi dùng compose
docker rm -f quantumlabs   # khi chạy thủ công
```

## Bước 3 — Bật Trợ lý AI (tùy chọn nhưng nên làm)

Trợ lý AI hoạt động ở hai chế độ:

1. **Chế độ AI đầy đủ** (khuyến nghị): cài Ollama rồi tải model:

```powershell
ollama pull gemma4:e2b
```

Ollama tự chạy ở nền sau khi cài. Sau đó mở lại trang — góc dưới phải
sẽ hiện **"Ollama · gemma4:e2b"** với chấm xanh.

2. **Chế độ dự phòng**: nếu chưa cài Ollama, trợ lý vẫn trả lời được các
khái niệm có sẵn trong khóa học (tra bảng thuật ngữ + nội dung phần đang
mở), kèm hướng dẫn cài Ollama ngay trong khung chat.

## Sử dụng

- **Thanh trái**: 20 mô-đun học theo thứ tự — toán nền, tiên đề, qubit,
  Bloch, phép đo, chồng chập, rối lượng tử, Bell, cổng, mạch, đá ngược
  pha, thuật toán, nghịch lý, thông tin lượng tử, mật mã, hậu lượng tử,
  nhiễu, sửa lỗi, **Lập trình với Qiskit**.
- **Trắc nghiệm**: mỗi mô-đun có quiz; đạt ≥ 2/3 câu được tính hoàn thành.
  Hoàn thành 6/9 mô-đun sẽ mở khóa Thử thách cuối cùng.
- **Trình dựng mạch**: kéo cổng từ bảng chọn thả lên dây mạch, nhấn
  **Chạy** để xem phân bố xác suất.
- **Trợ lý AI**: bấm nút 🤖 góc dưới phải — hỏi được cả câu hỏi lượng tử
  lẫn câu hỏi ngoài lề (toán, lập trình, đời sống…).

## Câu hỏi thường gặp

**Chatbot báo "Không kết nối được Ollama"?**
— Kiểm tra Ollama đang chạy: mở PowerShell chạy `ollama serve` (hoặc
đảm bảo app Ollama đang mở), và đã tải model: `ollama pull gemma4:e2b`.

**Muốn đổi cổng 8080 sang cổng khác?**
— Sửa file `docker-compose.yml`, dòng `"8080:80"` thành
`"<cổng_bạn_muốn>:80"` rồi chạy lại `docker compose up -d`.

**Muốn đổi model AI?**
— Sửa dòng `PREFERRED = 'gemma4:e2b'` trong `chatbot.js` thành tên model
đã tải (ví dụ `qwen2.5:7b`), hoặc đặt trong console trình duyệt:
`localStorage.setItem('quantumlab.ollamaUrl', 'http://IP_MÁY_KHÁC:11434')`
nếu Ollama chạy trên máy khác.

**Tiến độ học có bị mất khi tắt container?**
— Không. Tiến độ lưu trong `localStorage` của trình duyệt, không nằm
trong container.
