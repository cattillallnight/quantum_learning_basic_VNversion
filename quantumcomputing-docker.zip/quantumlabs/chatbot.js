/* =========================================================
   QuantumLab — Trợ lý AI (Ollama cục bộ)
   Tự chứa: tự dựng UI, tự dò Ollama, có chế độ dự phòng offline.
   Trả lời được cả câu hỏi lượng tử lẫn câu hỏi ngoài lề.
   ========================================================= */
(() => {
  'use strict';

  const OLLAMA = (localStorage.getItem('quantumlab.ollamaUrl') || 'http://127.0.0.1:11434').replace(/\/+$/, '');
  const PREFERRED = 'gemma4:e2b';
  const HISTORY_KEY = 'quantumlab.chat.history.v1';
  const MAX_HISTORY = 12;          // số lượt hội thoại gửi kèm để model có ngữ cảnh

  // Tên tiếng Việt của từng phần, dùng làm ngữ cảnh cho model.
  const SECTION_NAMES = {
    math: 'Toán nền tảng', postulates: '5 tiên đề cơ học lượng tử', 'density-matrix': 'Ma trận mật độ',
    history: 'Lịch sử cơ học lượng tử', qubits: 'Qubit', bloch: 'Mặt cầu Bloch',
    measurement: 'Phép đo', superposition: 'Chồng chập', entanglement: 'Vướng víu lượng tử',
    bell: 'Bất đẳng thức Bell', gates: 'Cổng lượng tử', circuits: 'Mạch lượng tử',
    kickback: 'Phase kickback', algorithms: 'Thuật toán lượng tử', paradox: 'Nghịch lý lượng tử',
    qinfo: 'Thông tin lượng tử', crypto: 'Mật mã lượng tử', pqc: 'An ninh hậu lượng tử',
    noise: 'Nhiễu', qec: 'Sửa lỗi lượng tử', simulators: 'Trình mô phỏng',
    glossary: 'Thuật ngữ', faq: 'Câu hỏi thường gặp', challenge: 'Thử thách cuối khóa'
  };

  const SYSTEM_PROMPT = [
    'Bạn là gia sư lượng tử thông minh của QuantumLab, trả lời bằng TIẾNG VIỆT, thân thiện, ngắn gọn, chính xác.',
    'Bạn vừa là chuyên gia lượng tử, vừa là trợ lý đa năng: câu hỏi NGOÀI lượng tử (toán, lập trình, đời sống, khoa học...) cứ trả lời bình thường bằng kiến thức của bạn — đừng từ chối.',
    'Khi giải thích lượng tử, ưu tiên trực quan và ví dụ đời thường vì người học là người mới hoàn toàn.',
    '',
    'Kiến thức nền phải luôn đúng:',
    '- Qubit ở trạng thái |ψ⟩ = α|0⟩ + β|1⟩ với |α|² + |β|² = 1; đo cho 0 với xác suất |α|², cho 1 với xác suất |β|².',
    '- n qubit mô tả bởi 2ⁿ biên độ phức — nên mô phỏng rất tốn bộ nhớ khi n tăng.',
    '- Cổng H tạo chồng chập: |0⟩ → (|0⟩+|1⟩)/√2. Cổng X là lật bit. Cổng Z đổi pha.',
    '- H rồi CNOT tạo trạng thái Bell vướng víu (|00⟩+|11⟩)/√2.',
    '- Vướng víu: các qubit có tương quan không thể giải thích bằng biến ẩn cục bộ (bất đẳng thức Bell/CHSH: cổ điển ≤ 2, lượng tử tới 2√2).',
    '- Đo làm sụp đổ hàm sóng; kết quả mang tính ngẫu nhiên, chỉ phân phối xác suất là xác định.',
    '- Không thể sao chép một trạng thái lượng tử chưa biết (định lý không-nhân-bản), nhưng có thể dịch chuyển trạng thái (teleportation) nhờ vướng víu + 2 bit cổ điển.',
    '- Grover tìm kiếm O(√N) lần gọi oracle (cổ điển O(N)); Shor phân tích thừa số trong thời gian đa thức.',
    '- Qiskit (≥1.0) đã bỏ hàm execute(); bộ mô phỏng nằm ở gói qiskit_aer: dùng AerSimulator().run(transpile(qc, sim), shots=1024).result().get_counts().',
    '- Mạch Qiskit cần measure/measure_all mới có counts; qubit đánh số từ 0; Qiskit đọc chuỗi bit theo little-endian (qubit 0 ở ngoài cùng bên phải).',
    '',
    'Cách trả lời: đi thẳng vào vấn đề, dùng gạch đầu dòng khi cần, có công thức thì viết rõ, có mã thì đặt trong khối ```python.'
  ].join('\n');

  // ---------- Trạng thái ----------
  let installed = [];      // model Ollama đã cài
  let currentModel = PREFERRED;
  let online = false;      // có kết nối được Ollama không
  let busy = false;
  let history = loadHistory();
  let controller = null;   // cho nút Dừng

  function loadHistory() {
    try { return JSON.parse(localStorage.getItem(HISTORY_KEY)) || []; } catch { return []; }
  }
  function saveHistory() {
    try { localStorage.setItem(HISTORY_KEY, JSON.stringify(history.slice(-40))); } catch {}
  }

  // ---------- Tiện ích ----------
  const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

  // Render tối giản: khối ```code```, `inline`, **đậm**, *nghiêng*, và danh sách.
  function mdLite(src) {
    const blocks = [];
    src = src.replace(/```(\w*)\n?([\s\S]*?)```/g, (_, lang, code) => {
      blocks.push(code.replace(/\s+$/, ''));
      return `\u0000B${blocks.length - 1}\u0000`;
    });
    const inl = t => esc(t)
      .replace(/`([^`]+)`/g, '<code>$1</code>')
      .replace(/\*\*([^*]+)\*\*/g, '<b>$1</b>')
      .replace(/(^|[\s(])\*([^*\n]+)\*(?=[\s).,!?:;]|$)/g, '$1<i>$2</i>');
    let out = '', list = null;
    const close = () => { if (list) { out += `</${list}>`; list = null; } };
    for (const ln of src.split('\n')) {
      let m;
      if (m = ln.match(/^\u0000B(\d+)\u0000$/)) {
        close();
        out += `<pre class="chat-code"><code>${esc(blocks[+m[1]])}</code></pre>`;
      }
      else if (m = ln.match(/^\s*[-*•]\s+(.+)/)) { if (list !== 'ul') { close(); out += '<ul>'; list = 'ul'; } out += `<li>${inl(m[1])}</li>`; }
      else if (m = ln.match(/^\s*\d+[.)]\s+(.+)/)) { if (list !== 'ol') { close(); out += '<ol>'; list = 'ol'; } out += `<li>${inl(m[1])}</li>`; }
      else if (m = ln.match(/^#{1,4}\s+(.+)/)) { close(); out += `<p class="chat-hd">${inl(m[1])}</p>`; }
      else if (ln.trim()) { close(); out += `<p>${inl(ln)}</p>`; }
      else close();
    }
    close();
    return out;
  }

  // ---------- Dựng UI ----------
  function buildUI() {
    const btn = document.createElement('button');
    btn.id = 'ai-fab';
    btn.type = 'button';
    btn.setAttribute('aria-label', 'Mở trợ lý AI');
    btn.innerHTML = '<span class="fab-ico">🤖</span><span class="fab-txt">Trợ lý AI</span>';
    document.body.appendChild(btn);

    const panel = document.createElement('aside');
    panel.id = 'ai-panel';
    panel.setAttribute('aria-hidden', 'true');
    panel.innerHTML = `
      <div class="ai-head">
        <div class="ai-title"><span class="ai-dot" id="ai-dot"></span>
          <div><b>Trợ lý AI</b><div class="ai-sub" id="ai-sub">Đang kiểm tra Ollama…</div></div>
        </div>
        <div class="ai-head-actions">
          <button class="ai-ico-btn" id="ai-clear" title="Xoá hội thoại">🗑</button>
          <button class="ai-ico-btn" id="ai-close" title="Đóng">✕</button>
        </div>
      </div>
      <div class="ai-ctx" id="ai-ctx" hidden></div>
      <div class="ai-msgs" id="ai-msgs"></div>
      <div class="ai-sugg" id="ai-sugg"></div>
      <form class="ai-foot" id="ai-form">
        <textarea id="ai-in" rows="1" placeholder="Hỏi bất cứ điều gì — lượng tử hoặc ngoài lề…"></textarea>
        <button type="submit" class="ai-send" id="ai-send" title="Gửi (Enter)">➤</button>
      </form>
      <div class="ai-note" id="ai-note"></div>`;
    document.body.appendChild(panel);
    return { btn, panel };
  }

  const $id = id => document.getElementById(id);

  // ---------- Dò Ollama ----------
  async function probe() {
    const dot = $id('ai-dot'), sub = $id('ai-sub'), note = $id('ai-note');
    try {
      const r = await fetch(OLLAMA + '/api/tags', { method: 'GET' });
      if (!r.ok) throw new Error('HTTP ' + r.status);
      const j = await r.json();
      installed = (j.models || []).map(m => m.name);
      online = installed.length > 0;
      if (online) {
        currentModel = installed.find(m => m === PREFERRED)
          || installed.find(m => m.split(':')[0] === PREFERRED.split(':')[0])
          || installed.find(m => /gemma/i.test(m))
          || installed[0];
        dot.className = 'ai-dot on';
        sub.textContent = 'Ollama · ' + currentModel;
        note.textContent = installed.length > 1
          ? 'Model khả dụng: ' + installed.join(', ')
          : 'Đã kết nối Ollama cục bộ.';
        note.className = 'ai-note ok';
      } else {
        throw new Error('chưa cài model');
      }
    } catch (e) {
      online = false;
      dot.className = 'ai-dot off';
      sub.textContent = 'Chế độ dự phòng (offline)';
      note.innerHTML = 'Không kết nối được Ollama tại <code>' + esc(OLLAMA) + '</code> — vẫn trả lời được các khái niệm có trong khóa. '
        + 'Muốn dùng AI đầy đủ: mở terminal chạy <code>ollama serve</code> và <code>ollama pull ' + PREFERRED + '</code>.';
      note.className = 'ai-note warn';
    }
    renderSuggestions();
    return online;
  }

  // ---------- Ngữ cảnh trang hiện tại ----------
  function currentSection() {
    const id = (location.hash || '').replace('#', '');
    if (!id || !SECTION_NAMES[id]) return null;
    const el = document.getElementById(id);
    if (!el) return null;
    const text = (el.innerText || '').replace(/\s+/g, ' ').trim();
    return { id, name: SECTION_NAMES[id], text: text.slice(0, 1400) };
  }

  function refreshContext() {
    const box = $id('ai-ctx');
    const s = currentSection();
    if (!s) { box.hidden = true; return; }
    box.hidden = false;
    box.innerHTML = `Đang xem: <b>${esc(s.name)}</b> — AI sẽ dùng nội dung này làm ngữ cảnh.`;
  }

  // ---------- Kho kiến thức dự phòng (lấy từ chính trang) ----------
  // GLOSSARY nằm trong IIFE khác nên đọc thẳng từ DOM đã render.
  function glossaryFromDom() {
    const root = document.getElementById('quick-glossary') || document.getElementById('glossary-list');
    if (!root) return '';
    const items = [...root.querySelectorAll('div')]
      .map(e => (e.innerText || '').replace(/\s+/g, ' ').trim()).filter(Boolean);
    return items.length ? items.join('\n') : (root.innerText || '').trim().slice(0, 1200);
  }

  function offlineAnswer(q) {
    const norm = s => s.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/đ/g, 'd');
    const nq = norm(q);
    const q_lines = glossaryFromDom().split('\n');
    for (const line of q_lines) {
      const m = line.match(/^([^—\-–:]{2,40})[—\-–:]\s*(.+)$/);
      if (!m) continue;
      const key = norm(m[1].trim());
      if (key.length > 2 && nq.includes(key)) {
        return `**${m[1].trim()}** — ${m[2].trim()}\n\n_(Chế độ dự phòng: câu trả lời lấy từ thuật ngữ có sẵn trong khóa. Bật Ollama để hỏi sâu hơn.)_`;
      }
    }
    const sec = currentSection();
    if (sec && sec.text) {
      return `Mình chưa kết nối được AI nên trả lời từ nội dung bài **${sec.name}** đang mở:\n\n${mdLiteQuote(sec.text)}\n\n_(Bật Ollama để có câu trả lời linh hoạt hơn.)_`;
    }
    return 'Hiện chưa kết nối được Ollama nên mình chỉ trả lời được các khái niệm có trong khóa học. '
      + 'Hãy chạy `ollama serve` rồi mở lại trợ lý để hỏi bất cứ điều gì.';
  }
  function mdLiteQuote(t) { return t.split(/(?<=\.)\s+/).slice(0, 6).join(' '); }

  // ---------- Gọi Ollama ----------
  async function askOllama(userText, onPiece) {
    const s = currentSection();
    const msgs = [{ role: 'system', content: SYSTEM_PROMPT }];
    if (s) msgs.push({ role: 'system', content: `Người học đang mở phần "${s.name}". Nội dung rút gọn:\n${s.text}` });
    for (const h of history.slice(-MAX_HISTORY)) msgs.push(h);
    msgs.push({ role: 'user', content: userText });

    controller = new AbortController();
    const res = await fetch(OLLAMA + '/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      signal: controller.signal,
      body: JSON.stringify({
        model: currentModel, stream: true, keep_alive: '30m', think: false,
        options: { temperature: 0.4, num_ctx: 8192, num_predict: 1200 },
        messages: msgs
      })
    });
    if (!res.ok) throw new Error('Ollama HTTP ' + res.status);

    const reader = res.body.getReader();
    const dec = new TextDecoder();
    let buf = '', full = '';
    try {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buf += dec.decode(value, { stream: true });
        const lines = buf.split('\n');
        buf = lines.pop();
        for (const line of lines) {
          if (!line.trim()) continue;
          let j; try { j = JSON.parse(line); } catch { continue; }
          const piece = j.message && j.message.content;
          if (piece) { full += piece; if (onPiece) onPiece(full); }
          if (j.error) throw new Error(j.error);
        }
      }
    } catch (e) {
      if (e.name === 'AbortError' && full) { e.partial = full; }
      throw e;
    }
    return full;
  }

  // ---------- Hiển thị ----------
  let deltaTarget = null;
  function onDelta(full) {
    if (!deltaTarget) return;
    deltaTarget.classList.add('streaming');
    deltaTarget.innerHTML = mdLite(full) || '<span class="ai-cursor"></span>';
    scrollMsgs();
  }
  function scrollMsgs() { const m = $id('ai-msgs'); m.scrollTop = m.scrollHeight; }

  function addMsg(cls, html) {
    const d = document.createElement('div');
    d.className = 'ai-msg ' + cls;
    d.innerHTML = html;
    $id('ai-msgs').appendChild(d);
    scrollMsgs();
    return d;
  }

  function suggestions() {
    const s = currentSection();
    const base = ['Qubit là gì?', 'Vì sao đo lại làm sụp trạng thái?', 'Vướng víu khác gì tương quan thường?'];
    if (s) return [`Giải thích phần "${s.name}" dễ hiểu hơn`, ...base.slice(0, 2)];
    return base;
  }
  function renderSuggestions() {
    const box = $id('ai-sugg');
    box.innerHTML = '';
    suggestions().forEach(t => {
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'ai-chip';
      b.textContent = t;
      b.onclick = () => { $id('ai-in').value = t; send(t); };
      box.appendChild(b);
    });
  }

  async function send(textFromArg) {
    if (busy) return;
    const input = $id('ai-in');
    const text = (textFromArg != null ? textFromArg : input.value).trim();
    if (!text) return;
    if (!textFromArg) input.value = '';
    autoGrow();

    addMsg('user', esc(text));
    history.push({ role: 'user', content: text });

    const sendBtn = $id('ai-send');
    sendBtn.classList.add('stop'); sendBtn.textContent = '■';
    sendBtn.title = 'Dừng';
    busy = true;

    if (!online) {
      const d = addMsg('bot', '');
      d.classList.add('streaming');
      d.innerHTML = mdLite(offlineAnswer(text));
      d.classList.remove('streaming');
      history.push({ role: 'assistant', content: offlineAnswer(text) });
      saveHistory();
      sendBtn.classList.remove('stop'); sendBtn.textContent = '➤'; sendBtn.title = 'Gửi (Enter)';
      busy = false;
      return;
    }

    deltaTarget = addMsg('bot', '<span class="ai-cursor"></span>');
    let full = '';
    try {
      full = await askOllama(text, f => { full = f; onDelta(f); });
      deltaTarget.classList.remove('streaming');
      deltaTarget.innerHTML = mdLite(full) || '<i>(không có nội dung)</i>';
      history.push({ role: 'assistant', content: full });
      saveHistory();
    } catch (e) {
      deltaTarget.classList.remove('streaming');
      const aborted = e.name === 'AbortError';
      const kept = e.partial || full;
      if (aborted && kept) {
        deltaTarget.innerHTML = mdLite(kept) + '<div class="ai-stopped">⏹ Đã dừng</div>';
        history.push({ role: 'assistant', content: kept });
        saveHistory();
      } else if (aborted) {
        deltaTarget.remove();
      } else {
        deltaTarget.innerHTML = '<b>Không gọi được Ollama.</b> ' + esc(e.message)
          + '<br>Kiểm tra: <code>ollama serve</code> đang chạy, và model <code>' + esc(currentModel) + '</code> đã cài.';
        online = false;
        probe();
      }
    } finally {
      deltaTarget = null;
      sendBtn.classList.remove('stop'); sendBtn.textContent = '➤'; sendBtn.title = 'Gửi (Enter)';
      busy = false;
    }
  }

  // ---------- Nút Dừng ----------
  function onSendClick(e) {
    if (busy) { e.preventDefault(); if (controller) controller.abort(); }
  }

  function autoGrow() {
    const t = $id('ai-in');
    t.style.height = 'auto';
    t.style.height = Math.min(t.scrollHeight, 140) + 'px';
  }

  function openPanel(open) {
    const p = $id('ai-panel');
    p.classList.toggle('open', open);
    p.setAttribute('aria-hidden', open ? 'false' : 'true');
    if (open) {
      refreshContext();
      renderSuggestions();
      if (!history.length) {
        addMsg('bot', 'Xin chào! Mình là trợ lý AI của QuantumLab. Hỏi mình về bất kỳ khái niệm lượng tử nào trong khóa, hoặc bất cứ điều gì khác bạn tò mò — mình trả lời được cả câu hỏi ngoài lề.');
      }
      setTimeout(() => $id('ai-in').focus(), 120);
    }
  }

  // ---------- Khởi động ----------
  function init() {
    const { btn, panel } = buildUI();
    // phục hồi hội thoại cũ
    if (history.length) {
      for (const h of history) addMsg(h.role === 'user' ? 'user' : 'bot', mdLite(h.content));
    }

    btn.onclick = () => openPanel(!panel.classList.contains('open'));
    $id('ai-close').onclick = () => openPanel(false);
    $id('ai-clear').onclick = () => {
      history = []; saveHistory();
      $id('ai-msgs').innerHTML = '';
      addMsg('bot', 'Đã xoá hội thoại. Hỏi mình điều gì mới nhé!');
    };
    $id('ai-form').addEventListener('submit', e => { e.preventDefault(); onSendClick(e); if (!busy) send(); });
    const ta = $id('ai-in');
    ta.addEventListener('input', autoGrow);
    ta.addEventListener('keydown', e => {
      if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); if (!busy) send(); }
    });
    window.addEventListener('hashchange', () => { if (panel.classList.contains('open')) refreshContext(); });
    window.addEventListener('keydown', e => { if (e.key === 'Escape') openPanel(false); });

    probe();
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
