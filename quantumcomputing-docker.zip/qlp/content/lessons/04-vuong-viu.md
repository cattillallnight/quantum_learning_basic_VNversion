---
id: 04-vuong-viu
title: Bài 4. Vướng víu lượng tử: Bell và GHZ
level: Cơ bản
minutes: 25
summary: Cổng CNOT, trạng thái Bell và mở rộng thành GHZ 3 qubit.
---
## CNOT và trạng thái Bell
**CNOT (cx)** lật qubit đích nếu qubit điều khiển là |1⟩. H trên q0 rồi CNOT(q0→q1) tạo trạng thái Bell (|00⟩+|11⟩)/√2: hai qubit *vướng víu*, kết quả đo luôn giống nhau.

```python run
from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator
from qiskit.visualization import plot_histogram

qc = QuantumCircuit(2, 2)
qc.h(0)
qc.cx(0, 1)
qc.measure([0, 1], [0, 1])

sim = AerSimulator()
counts = sim.run(transpile(qc, sim), shots=1024).result().get_counts()
print(counts)
plot_histogram(counts)
```
Chỉ xuất hiện `00` và `11`, không bao giờ `01` hay `10`.

## Bài tập
Mở rộng thành trạng thái **GHZ** 3 qubit (|000⟩+|111⟩)/√2, chạy 1000 shots, lưu vào `counts`.
```starter
from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator

qc = QuantumCircuit(3)
qc.h(0)
# TODO: dùng cx để vướng víu q1, q2 với q0
qc.measure_all()

sim = AerSimulator()
counts = sim.run(transpile(qc, sim), shots=1000).result().get_counts()
print(counts)
```
```solution
from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator

qc = QuantumCircuit(3)
qc.h(0)
qc.cx(0, 1)
qc.cx(1, 2)
qc.measure_all()

sim = AerSimulator()
counts = sim.run(transpile(qc, sim), shots=1000).result().get_counts()
print(counts)
```
```check
assert set(counts) == {'000', '111'}, f"Chỉ được phép xuất hiện 000 và 111, nhưng nhận {sorted(counts)}."
assert min(counts.values()) > 350, "Hai kết quả phải xấp xỉ 50/50."
```
