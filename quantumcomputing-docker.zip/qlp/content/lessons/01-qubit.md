---
id: 01-qubit
title: Bài 1. Qubit và trạng thái lượng tử
level: Cơ bản
minutes: 15
summary: Qubit, ký hiệu |0⟩ |1⟩, vector trạng thái và Statevector trong Qiskit.
---
## Qubit là gì
Bit cổ điển chỉ là 0 hoặc 1. **Qubit** có trạng thái tổng quát là a|0⟩ + b|1⟩, với a, b là số phức gọi là *biên độ* và |a|² + |b|² = 1. Khi đo, ta nhận 0 với xác suất |a|² và 1 với xác suất |b|².

## Vector trạng thái trong Qiskit
Lớp `Statevector` cho phép xem biên độ của một mạch trước khi đo.
```python run
from qiskit import QuantumCircuit
from qiskit.quantum_info import Statevector

qc = QuantumCircuit(1)   # 1 qubit, khởi đầu ở |0>
state = Statevector(qc)
print(state)
print("Xác suất đo được 0 và 1:", state.probabilities())
```
## Quy ước đánh số
Qiskit đánh số qubit từ 0. Với n qubit, trạng thái có 2^n biên độ — đây là lý do mô phỏng lượng tử tốn bộ nhớ rất nhanh khi n tăng.

## Bài tập
Tạo mạch 1 qubit, áp dụng cổng `x` để đưa qubit sang |1⟩, lưu trạng thái vào biến `state`.
```starter
from qiskit import QuantumCircuit
from qiskit.quantum_info import Statevector

qc = QuantumCircuit(1)
# TODO: đưa qubit sang |1>

state = Statevector(qc)
print(state)
```
```solution
from qiskit import QuantumCircuit
from qiskit.quantum_info import Statevector

qc = QuantumCircuit(1)
qc.x(0)

state = Statevector(qc)
print(state)
```
```check
assert abs(state.probabilities()[1] - 1) < 1e-9, "Qubit phải ở trạng thái |1> (xác suất đo được 1 bằng 100%)."
```
