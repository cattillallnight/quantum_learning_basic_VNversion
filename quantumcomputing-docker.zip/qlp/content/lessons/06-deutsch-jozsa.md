---
id: 06-deutsch-jozsa
title: Bài 6. Thuật toán Deutsch–Jozsa
level: Trung cấp
minutes: 30
summary: Phân biệt hàm hằng và hàm cân bằng chỉ với một lần gọi oracle.
---
## Bài toán
Cho hàm f: {0,1}ⁿ → {0,1} đảm bảo hoặc **hằng** (luôn 0 hoặc luôn 1) hoặc **cân bằng** (một nửa đầu vào cho 0, nửa còn lại cho 1). Cổ điển cần tới 2ⁿ⁻¹+1 lần gọi trong trường hợp xấu nhất; lượng tử chỉ cần **1 lần**.

## Mạch
Qubit phụ (ancilla) khởi tạo |1⟩; H lên tất cả; oracle; H lên các qubit đầu vào; đo các qubit đầu vào. Nếu toàn số 0 → hằng, ngược lại → cân bằng.

```python run
from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator

n = 2
qc = QuantumCircuit(n + 1, n)
qc.x(n)
qc.h(range(n + 1))
qc.barrier()
qc.cx(0, n)                # oracle cân bằng: f(x) = x0
qc.barrier()
qc.h(range(n))
qc.measure(range(n), range(n))

sim = AerSimulator()
counts = sim.run(transpile(qc, sim), shots=500).result().get_counts()
print(counts)              # không có '00' => hàm cân bằng
```
## Bài tập
Cài oracle cân bằng **f(x) = x1 XOR x0** (dùng hai cổng cx tới ancilla qubit 2). Kết quả đo không được chứa `'00'`.
```starter
from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator

n = 2
qc = QuantumCircuit(n + 1, n)
qc.x(n)
qc.h(range(n + 1))
qc.barrier()
# TODO: oracle f(x) = x0 XOR x1 (ancilla là qubit 2)
qc.barrier()
qc.h(range(n))
qc.measure(range(n), range(n))

sim = AerSimulator()
counts = sim.run(transpile(qc, sim), shots=500).result().get_counts()
print(counts)
```
```solution
from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator

n = 2
qc = QuantumCircuit(n + 1, n)
qc.x(n)
qc.h(range(n + 1))
qc.barrier()
qc.cx(0, n)
qc.cx(1, n)
qc.barrier()
qc.h(range(n))
qc.measure(range(n), range(n))

sim = AerSimulator()
counts = sim.run(transpile(qc, sim), shots=500).result().get_counts()
print(counts)
```
```check
assert counts.get('00', 0) == 0, "Oracle cân bằng thì không bao giờ đo được '00'. Hãy thêm cx(0,2) và cx(1,2)."
assert sum(counts.values()) == 500
```
