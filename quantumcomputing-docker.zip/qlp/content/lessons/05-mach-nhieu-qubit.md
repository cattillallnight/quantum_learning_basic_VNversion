---
id: 05-mach-nhieu-qubit
title: Bài 5. Mạch nhiều qubit và thứ tự bit (little-endian)
level: Cơ bản
minutes: 20
summary: Cổng hai/ba qubit, SWAP, Toffoli và quy ước thứ tự bit của Qiskit.
---
## Cổng nhiều qubit
`cx` (CNOT), `cz`, `swap`, và `ccx` (Toffoli: lật đích khi cả hai điều khiển là 1).

## Little-endian
Qiskit in chuỗi bit với **qubit 0 nằm bên phải**. Nếu chỉ qubit 0 ở |1⟩ trong mạch 3 qubit, kết quả đo là `'001'`, không phải `'100'`.

```python run
from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator

qc = QuantumCircuit(3)
qc.x(0)
qc.measure_all()
sim = AerSimulator()
counts = sim.run(transpile(qc, sim), shots=100).result().get_counts()
print(counts)   # {'001': 100}
```
## Bài tập
Mạch 3 qubit: đưa **qubit 0 và qubit 1** sang |1⟩, đo, chạy 500 shots. Kết quả phải luôn là `'011'`.
```starter
from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator

qc = QuantumCircuit(3)
# TODO: đặt qubit 0 và 1 ở |1>
qc.measure_all()

sim = AerSimulator()
counts = sim.run(transpile(qc, sim), shots=500).result().get_counts()
print(counts)
```
```solution
from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator

qc = QuantumCircuit(3)
qc.x(0)
qc.x(1)
qc.measure_all()

sim = AerSimulator()
counts = sim.run(transpile(qc, sim), shots=500).result().get_counts()
print(counts)
```
```check
assert counts == {'011': 500}, f"Kỳ vọng {{'011': 500}}, nhận {counts}."
```
