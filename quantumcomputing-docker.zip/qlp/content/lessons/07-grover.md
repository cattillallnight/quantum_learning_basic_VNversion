---
id: 07-grover
title: Bài 7. Thuật toán tìm kiếm Grover
level: Trung cấp
minutes: 30
summary: Khuếch đại biên độ để tìm phần tử được đánh dấu; ví dụ 2 qubit.
---
## Ý tưởng
Grover tìm phần tử thỏa điều kiện trong N mục với khoảng √N lần lặp (cổ điển cần ~N). Mỗi lần lặp gồm **oracle** (đảo pha trạng thái cần tìm) và **toán tử khuếch đại** (phản xạ quanh trạng thái trung bình).

Với 2 qubit (N = 4), **một** lần lặp là đủ để đo ra trạng thái đích với xác suất 100% (lý tưởng).

```python run
from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator

qc = QuantumCircuit(2)
qc.h([0, 1])
qc.cz(0, 1)                 # oracle đánh dấu |11>
qc.h([0, 1]); qc.x([0, 1]); qc.cz(0, 1); qc.x([0, 1]); qc.h([0, 1])   # khuếch đại
qc.measure_all()

sim = AerSimulator()
print(sim.run(transpile(qc, sim), shots=500).result().get_counts())
```
## Bài tập
Đoạn mã đã có khởi tạo và oracle. Hãy viết phần **khuếch đại** (H, X, CZ, X, H) để đo được `'11'` với ≥ 95% số lần.
```starter
from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator

qc = QuantumCircuit(2)
qc.h([0, 1])
qc.cz(0, 1)                 # oracle
# TODO: toán tử khuếch đại
qc.measure_all()

sim = AerSimulator()
counts = sim.run(transpile(qc, sim), shots=1000).result().get_counts()
print(counts)
```
```solution
from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator

qc = QuantumCircuit(2)
qc.h([0, 1])
qc.cz(0, 1)
qc.h([0, 1])
qc.x([0, 1])
qc.cz(0, 1)
qc.x([0, 1])
qc.h([0, 1])
qc.measure_all()

sim = AerSimulator()
counts = sim.run(transpile(qc, sim), shots=1000).result().get_counts()
print(counts)
```
```check
assert counts.get('11', 0) >= 950, f"Cần ≥ 950/1000 lần đo '11', nhận {counts.get('11', 0)}."
```
