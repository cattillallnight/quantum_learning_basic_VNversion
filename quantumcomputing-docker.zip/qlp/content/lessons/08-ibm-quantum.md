---
id: 08-ibm-quantum
title: Bài 8. Biên dịch và chạy trên IBM Quantum
level: Nâng cao
minutes: 25
summary: Basis gates, transpile cho phần cứng thật và quy trình gửi job qua qiskit-ibm-runtime.
---
## Vì sao phải biên dịch
Phần cứng thật chỉ hỗ trợ một tập **cổng cơ sở (basis gates)** và sơ đồ kết nối qubit hạn chế. `transpile` chuyển mạch của bạn thành mạch tương đương dùng đúng các cổng đó.

```python run
from qiskit import QuantumCircuit, transpile

qc = QuantumCircuit(2, 2)
qc.h(0); qc.cx(0, 1); qc.measure([0, 1], [0, 1])
t = transpile(qc, basis_gates=['cx', 'rz', 'sx', 'x'], optimization_level=1)
print(t.count_ops())
print(t.draw('text'))
```
## Gửi job lên máy thật (tham khảo — không chạy trong trang này)
Website **không** gửi job lên IBM Quantum thay bạn. Chạy trên máy của bạn sau khi tạo API key và CRN tại IBM Quantum Platform:
```python
from qiskit_ibm_runtime import QiskitRuntimeService, SamplerV2 as Sampler
from qiskit.transpiler.preset_passmanagers import generate_preset_pass_manager

service = QiskitRuntimeService()          # đã save_account trước đó
backend = service.least_busy(operational=True, simulator=False)
isa = generate_preset_pass_manager(backend=backend, optimization_level=1).run(qc)
job = Sampler(backend).run([isa])
print(job.job_id())
```
Không dán API key vào mã chia sẻ công khai.

## Bài tập
Biên dịch mạch Bell về tập cổng `['cx', 'rz', 'sx', 'x']` và lưu vào biến `t`.
```starter
from qiskit import QuantumCircuit, transpile

qc = QuantumCircuit(2, 2)
qc.h(0)
qc.cx(0, 1)
qc.measure([0, 1], [0, 1])

# TODO: t = transpile(...)
print(t.count_ops())
```
```solution
from qiskit import QuantumCircuit, transpile

qc = QuantumCircuit(2, 2)
qc.h(0)
qc.cx(0, 1)
qc.measure([0, 1], [0, 1])

t = transpile(qc, basis_gates=['cx', 'rz', 'sx', 'x'], optimization_level=1)
print(t.count_ops())
```
```check
ops = set(t.count_ops())
allowed = {'cx', 'rz', 'sx', 'x', 'measure', 'barrier'}
assert ops <= allowed, f"Còn cổng ngoài tập cho phép: {sorted(ops - allowed)}"
assert 'h' not in ops
```
