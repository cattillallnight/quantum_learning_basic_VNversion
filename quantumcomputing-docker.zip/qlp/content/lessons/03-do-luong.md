---
id: 03-do-luong
title: Bài 3. Đo lường và mô phỏng với Qiskit Aer
level: Cơ bản
minutes: 20
summary: Phép đo, shots, histogram và chạy mạch trên AerSimulator.
---
## Đo lường
Đo làm chồng chập "sụp" về một kết quả cổ điển. Một lần đo chỉ cho một kết quả ngẫu nhiên, nên ta lặp lại nhiều lần (**shots**) và thống kê.

```python run
from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator
from qiskit.visualization import plot_histogram

qc = QuantumCircuit(1)
qc.h(0)
qc.measure_all()

sim = AerSimulator()
counts = sim.run(transpile(qc, sim), shots=1000).result().get_counts()
print(counts)
plot_histogram(counts)
```
Quy trình chuẩn: xây mạch → `transpile` cho backend → `run(shots=...)` → `get_counts()`.

## Bài tập
Chạy mạch H + đo với đúng 2000 shots và lưu kết quả vào `counts`.
```starter
from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator

qc = QuantumCircuit(1)
qc.h(0)
qc.measure_all()

sim = AerSimulator()
# TODO: chạy mạch với 2000 shots, gán kết quả vào counts
print(counts)
```
```solution
from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator

qc = QuantumCircuit(1)
qc.h(0)
qc.measure_all()

sim = AerSimulator()
counts = sim.run(transpile(qc, sim), shots=2000).result().get_counts()
print(counts)
```
```check
assert sum(counts.values()) == 2000, "Tổng số lần đo phải bằng 2000 (shots=2000)."
assert 850 < counts.get('0', 0) < 1150, "Với H, xác suất đo 0 phải xấp xỉ 50%."
```
