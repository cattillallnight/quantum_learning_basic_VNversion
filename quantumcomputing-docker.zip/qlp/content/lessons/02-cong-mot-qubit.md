---
id: 02-cong-mot-qubit
title: Bài 2. Cổng một qubit: X, H, Z
level: Cơ bản
minutes: 20
summary: Cổng X (NOT), Hadamard tạo chồng chập, cổng Z đổi pha.
---
## Các cổng cơ bản
- **X**: đảo |0⟩ ↔ |1⟩ (tương tự NOT).
- **H (Hadamard)**: biến |0⟩ thành (|0⟩+|1⟩)/√2, tức *chồng chập* với xác suất 50/50.
- **Z**: giữ |0⟩, đổi dấu |1⟩ (đổi *pha*). Pha không đổi xác suất đo trực tiếp nhưng ảnh hưởng đến giao thoa khi dùng thêm cổng khác.

```python run
from qiskit import QuantumCircuit
from qiskit.quantum_info import Statevector

qc = QuantumCircuit(1)
qc.h(0)
print(Statevector(qc))          # (|0> + |1>)/sqrt2
qc.h(0)
print(Statevector(qc))          # H hai lần trở về |0>: giao thoa
```
## Bài tập
Tạo trạng thái |−⟩ = (|0⟩ − |1⟩)/√2 từ |0⟩ bằng hai cổng. Biến mạch phải tên `qc`.
```starter
from qiskit import QuantumCircuit
from qiskit.quantum_info import Statevector

qc = QuantumCircuit(1)
# TODO: dùng hai cổng để tạo |->

print(Statevector(qc))
```
```solution
from qiskit import QuantumCircuit
from qiskit.quantum_info import Statevector

qc = QuantumCircuit(1)
qc.h(0)
qc.z(0)

print(Statevector(qc))
```
```check
from qiskit.quantum_info import Statevector
target = Statevector([2**-0.5, -(2**-0.5)])
assert Statevector(qc).equiv(target), "Trạng thái chưa phải |−> = (|0> − |1>)/√2. Gợi ý: H rồi Z."
```
