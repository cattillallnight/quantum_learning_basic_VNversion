---
title: Hướng dẫn cài đặt môi trường thực hành
---
## 1. Yêu cầu
Python 3.10–3.13, pip, khoảng 1 GB dung lượng trống. Docker là tùy chọn.

## 2. Cài đặt trên máy (Windows / macOS / Linux)
Tạo môi trường ảo, cài thư viện và khởi động website:
```bash
python -m venv .venv
# Windows PowerShell:  .\.venv\Scripts\Activate.ps1
# macOS/Linux:         source .venv/bin/activate
pip install -r requirements.txt
python app.py
```
Mở http://127.0.0.1:5000. Trên Windows, mã giới hạn tài nguyên của sandbox yêu cầu Linux/macOS — nên dùng Docker hoặc WSL2 (xem README).

## 3. Chạy bằng Docker
```bash
docker compose up --build
```
## 4. Bật chatbot AI mã nguồn mở (tùy chọn, miễn phí)
Chatbot luôn hoạt động ở chế độ **offline-RAG** (tra cứu tài liệu + chẩn đoán lỗi theo luật). Để có câu trả lời diễn đạt tự nhiên hơn, cài Ollama (https://ollama.com) và tải một model mở:
```bash
ollama pull gemma4:e2b
```
Website tự phát hiện Ollama tại http://localhost:11434.

## 5. Kiểm tra cài đặt
Chạy `python -m pytest tests -q`; tất cả bài kiểm thử phải đạt.
