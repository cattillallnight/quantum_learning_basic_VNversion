---
id: faq
title: Câu hỏi thường gặp
---
## Cần bao nhiêu qubit để mô phỏng trên laptop?
Khoảng 20–25 qubit là thoải mái trên máy 8 GB; mỗi qubit thêm làm bộ nhớ tăng gấp đôi.
## Khác biệt giữa AerSimulator và Statevector?
Statevector trả về biên độ chính xác của mạch không đo. AerSimulator mô phỏng việc đo với nhiều shots, giống phần cứng thật, kể cả mô hình nhiễu.
## Vì sao kết quả mỗi lần chạy khác nhau?
Phép đo lượng tử là ngẫu nhiên; chỉ phân phối xác suất ổn định. Đặt seed_simulator=1 trong run để tái lập.
## Grover nhanh hơn bao nhiêu?
Tìm kiếm không cấu trúc N mục: cổ điển O(N), Grover O(√N) lần gọi oracle.
## Deutsch–Jozsa có ứng dụng thực tế không?
Chủ yếu mang tính minh họa ưu thế lượng tử về số lần gọi oracle; nó là bước đệm hiểu các thuật toán như Simon, Shor.
## Làm sao chạy trên máy lượng tử thật?
Tạo tài khoản IBM Quantum Platform, lấy API key và CRN, dùng qiskit-ibm-runtime; xem Bài 8.
