---
id: errors
title: Lỗi thường gặp khi dùng Qiskit
---
## ImportError: cannot import name 'execute'
Hàm execute đã bị gỡ từ Qiskit 1.0. Dùng sim = AerSimulator(); sim.run(transpile(qc, sim), shots=1024).result().get_counts().
## Không import được Aer từ qiskit
Aer nằm ở gói riêng qiskit-aer. Cài pip install qiskit-aer và from qiskit_aer import AerSimulator.
## QiskitError: No counts for experiment
Mạch chưa có phép đo. Thêm qc.measure_all() hoặc qc.measure(q, c) trước khi run.
## CircuitError: chỉ số qubit vượt phạm vi
QuantumCircuit(n) có qubit 0..n-1. Truy cập qubit n gây lỗi; kiểm tra số qubit khi tạo mạch.
## Mô phỏng hết bộ nhớ
Trạng thái n qubit cần 2^n biên độ (16 byte mỗi biên độ phức). 30 qubit cần khoảng 16 GB. Giảm số qubit hoặc dùng mạch Clifford với method='stabilizer'.
## Kết quả đo có thứ tự bit ngược
Qiskit dùng little-endian: qubit 0 là bit bên phải. Dùng counts và đảo chuỗi nếu cần đối chiếu sách.
## Quên transpile khi chạy trên backend thật
Phần cứng chỉ hiểu basis gates. Gọi transpile hoặc generate_preset_pass_manager trước khi gửi job.
## SyntaxError hoặc IndentationError
Lỗi cú pháp Python: kiểm tra thụt lề (4 dấu cách), dấu ngoặc đóng và dấu hai chấm sau for, if, def.
