---
id: glossary
title: Thuật ngữ lượng tử
---
## Qubit
Đơn vị thông tin lượng tử, trạng thái a|0⟩ + b|1⟩ với |a|²+|b|²=1.
## Superposition (chồng chập)
Qubit tồn tại đồng thời ở tổ hợp |0⟩ và |1⟩ cho đến khi đo. Cổng Hadamard tạo chồng chập.
## Entanglement (vướng víu)
Các qubit có trạng thái không thể mô tả riêng lẻ; kết quả đo tương quan. Tạo bằng H và CNOT.
## Shots
Số lần lặp chạy mạch và đo để thu thống kê xác suất. Nhiều shots cho phân phối ổn định hơn.
## Transpile
Biên dịch mạch sang tập cổng cơ sở và sơ đồ kết nối của backend. Gọi trước khi run trên phần cứng thật.
## Backend
Thiết bị thực thi mạch: AerSimulator (mô phỏng) hoặc máy lượng tử thật của IBM.
## Statevector
Vector 2^n biên độ phức của hệ n qubit; dùng quantum_info.Statevector để xem trạng thái trước khi đo.
## NISQ
Giai đoạn máy lượng tử quy mô vừa, còn nhiễu và chưa sửa lỗi hoàn toàn.
## Little-endian
Qiskit in qubit 0 ở bên phải chuỗi bit đo: chỉ qubit 0 bằng 1 cho '001'.
## Qiskit
Qiskit là bộ công cụ phát triển phần mềm (SDK) mã nguồn mở của IBM, viết bằng Python, dùng để tạo mạch lượng tử, biên dịch (transpile) và chạy trên bộ mô phỏng hoặc máy tính lượng tử thật. Các gói chính: qiskit (xây dựng mạch), qiskit-aer (bộ mô phỏng), qiskit-ibm-runtime (gửi job lên IBM Quantum).
## Qiskit Aer
Qiskit Aer là bộ mô phỏng hiệu năng cao cho Qiskit; AerSimulator chạy mạch trên máy tính thường, hỗ trợ đo nhiều shots và mô hình nhiễu.
## IBM Quantum
IBM Quantum là nền tảng đám mây của IBM cho phép chạy chương trình trên máy tính lượng tử thật qua qiskit-ibm-runtime; cần tài khoản, API key và CRN. Xem Bài 8.
## Quantum computing (điện toán lượng tử)
Điện toán lượng tử là cách tính toán dùng qubit, chồng chập và vướng víu thay vì bit cổ điển; một số bài toán có thể nhanh hơn, ví dụ tìm kiếm với Grover. Máy hiện nay thuộc giai đoạn NISQ.
## Quantum programming (lập trình lượng tử)
Lập trình lượng tử là viết chương trình dưới dạng mạch lượng tử gồm các cổng, rồi đo kết quả; trong khóa học này dùng Python và Qiskit.
