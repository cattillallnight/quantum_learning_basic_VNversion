"""Kiểm thử giao diện thật bằng Playwright + chụp ảnh. Chạy khi server đang chạy: python tests/e2e.py [URL]"""
import sys, os
from playwright.sync_api import sync_playwright, expect
URL = sys.argv[1] if len(sys.argv) > 1 else "http://127.0.0.1:5000"
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "docs", "screenshots")
os.makedirs(OUT, exist_ok=True)
results = []
def ok(name, cond):
    results.append((name, bool(cond))); print(("PASS " if cond else "FAIL ") + name)

with sync_playwright() as p:
    b = p.chromium.launch(); pg = b.new_page(viewport={"width": 1440, "height": 900}, device_scale_factor=2)
    errs = []; pg.on("pageerror", lambda e: errs.append(str(e)))
    pg.on("dialog", lambda d: d.accept())
    pg.goto(URL); pg.wait_for_selector(".card")
    ok("Trang chủ hiển thị 8 bài", pg.locator(".card").count() == 8)
    pg.screenshot(path=f"{OUT}/01_home.png")

    pg.goto(URL + "/#/lesson/04-vuong-viu"); pg.wait_for_selector("#codeL")
    pg.click("[data-run]"); pg.wait_for_selector("#outL img", timeout=40000)
    ok("Bài 4: chạy mã mẫu cho sơ đồ mạch + histogram", "┌" in pg.inner_text("#outL") and pg.locator("#outL img").count() >= 1)
    pg.screenshot(path=f"{OUT}/02_lesson_run.png")
    pg.fill("#codeL", pg.input_value("#codeL")); 
    pg.click("#chkL"); pg.wait_for_selector("#outL .res", timeout=40000)
    ok("Chấm bài: mã mẫu Bell (chưa phải GHZ) bị chấm sai", "res no" in pg.get_attribute("#outL .res", "class"))
    pg.click("#solL"); pg.click("#chkL"); pg.wait_for_selector("#outL .res.ok", timeout=40000)
    ok("Chấm bài: đáp án GHZ được chấm đúng", True)
    pg.screenshot(path=f"{OUT}/03_lesson_check_pass.png")
    pg.goto(URL + "/#/"); pg.wait_for_selector(".done")
    ok("Tiến độ được lưu (hiện ✔ Hoàn thành)", pg.locator(".card .done").count() == 1)

    pg.goto(URL + "/#/playground"); pg.wait_for_selector("#codeP")
    pg.click("#runP"); pg.wait_for_selector("#outP img", timeout=40000)
    ok("Playground chạy mã mặc định ra histogram", pg.locator("#outP img").count() == 1)
    pg.fill("#codeP", "from qiskit import execute\nprint('hi')")
    pg.click("#runP"); pg.wait_for_selector("#outP .err", timeout=40000)
    ok("Hiển thị traceback khi lỗi", "execute" in pg.inner_text("#outP .err"))
    pg.click("#dbgP"); pg.wait_for_selector(".m.b:nth-last-child(1):has-text('Chẩn đoán')", timeout=60000)
    ok("AI debug trả chẩn đoán lỗi execute", "execute" in pg.inner_text("#msgs .m.b:last-child"))
    pg.screenshot(path=f"{OUT}/04_playground_debug_chat.png")

    n = pg.locator("#msgs .m").count()
    pg.fill("#chatIn", "Entanglement (vướng víu) là gì?"); pg.press("#chatIn", "Enter")
    pg.wait_for_function(f"document.querySelectorAll('#msgs .m').length >= {n + 2} && !document.querySelector('#msgs .m:last-child').innerText.startsWith('…')", timeout=30000)
    last = pg.inner_text("#msgs .m.b:last-child")
    ok("Chatbot trả lời khái niệm kèm nguồn", "vướng" in last.lower() and "Nguồn" in last)

    pg.goto(URL + "/#/setup"); pg.wait_for_selector("h3")
    ok("Trang hướng dẫn cài đặt hiển thị", "pip install" in pg.inner_text("#main"))
    pg.screenshot(path=f"{OUT}/05_setup.png")
    m = b.new_page(viewport={"width": 390, "height": 800}, device_scale_factor=2); m.goto(URL + "/#/lesson/01-qubit"); m.wait_for_selector("#codeL")
    ok("Giao diện di động render", m.locator("#codeL").is_visible())
    ok("Không có lỗi JavaScript", not errs)
    b.close()
bad = [n for n, c in results if not c]
print(f"\n{len(results) - len(bad)}/{len(results)} đạt"); sys.exit(1 if bad else 0)
