import json, os, re, sys, threading
from http.server import BaseHTTPRequestHandler, HTTPServer
import pytest
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import app as appmod, chat
from rag import KB, parse_md
from sandbox import run_code

client = appmod.app.test_client()
LESSONS = appmod.LESSONS


def test_lesson_count():
    assert len(LESSONS) == 8


@pytest.mark.parametrize("lid", list(LESSONS))
def test_demo_blocks_run(lid):
    _, body = parse_md(open(f"content/lessons/{lid}.md", encoding="utf-8").read())
    demos = re.findall(r"```python run\n(.*?)```", body, re.S)
    assert demos
    for code in demos:
        r = run_code(code)
        assert r["ok"], r["error"]


@pytest.mark.parametrize("lid", list(LESSONS))
def test_grading_solution_passes_starter_fails(lid):
    l = LESSONS[lid]
    sol = client.post("/api/check", json={"lesson": lid, "code": l["solution"]}).get_json()
    assert sol["ok"] and sol["check"]["passed"], sol
    st = client.post("/api/check", json={"lesson": lid, "code": l["starter"]}).get_json()
    assert not (st["ok"] and st["check"] and st["check"]["passed"]), "starter chưa làm không được đạt"


def test_run_outputs_circuit_and_image():
    r = client.post("/api/run", json={"code": "from qiskit import QuantumCircuit\nqc=QuantumCircuit(2);qc.h(0);qc.cx(0,1)\nimport matplotlib.pyplot as plt\nplt.plot([1,2])"}).get_json()
    assert r["ok"] and r["circuits"][0]["name"] == "qc" and len(r["images"]) == 1


@pytest.mark.parametrize("code,kind", [("import os", "ImportError"), ("print(x)", "NameError"), ("def f(:\n pass", "SyntaxError"),
                                       ("while True: pass", "Timeout")])
def test_sandbox_errors(code, kind):
    r = run_code(code)
    assert not r["ok"] and r["error"]["type"] == kind


def test_sandbox_blocks_open_and_eval():
    assert not run_code("open('/etc/passwd').read()")["ok"]
    assert not run_code("eval('1+1')")["ok"]


def test_sandbox_memory_limit():
    code = ("from qiskit import QuantumCircuit\nfrom qiskit_aer import AerSimulator\nqc=QuantumCircuit(36);qc.h(range(36));qc.t(range(36));qc.h(range(36));qc.measure_all()\n"
            "AerSimulator(method='statevector').run(qc).result().get_counts()")
    r = run_code(code)
    assert not r["ok"]


DIAG_CASES = [
    ("from qiskit import execute", "execute"),
    ("from qiskit import Aer", "qiskit-aer"),
    ("from qiskit import QuantumCircuit\nfrom qiskit_aer import AerSimulator\nqc=QuantumCircuit(1)\nAerSimulator().run(qc).result().get_counts()", "phép đo"),
    ("from qiskit import QuantumCircuit\nqc=QuantumCircuit(2)\nqc.h(5)", "Chỉ số qubit"),
    ("from qiskit import QuantumCircuit\nqc=QuantumCircuit(2)\nqc.cx(0)", "thiếu tham số"),
    ("print(abc)", "chưa được định nghĩa"),
]


@pytest.mark.parametrize("code,expect", DIAG_CASES)
def test_debug_diagnosis(code, expect):
    r = client.post("/api/chat", json={"message": "Code của tôi bị lỗi, sửa giúp", "code": code}).get_json()
    assert r["ran"] and expect.lower() in r["answer"].lower(), r["answer"]
    assert r["mode"] in ("offline-rag",) or r["mode"].startswith("llm")


RETRIEVAL = [("trạng thái bell là gì", "04-vuong-viu"), ("cổng hadamard làm gì", "02-cong-mot-qubit"), ("shots là gì", "glossary"),
             ("grover tìm kiếm", "07-grover"), ("deutsch jozsa oracle cân bằng", "06-deutsch-jozsa"), ("little endian thứ tự bit", "05-mach-nhieu-qubit"),
             ("transpile basis gates", "08-ibm-quantum"), ("hết bộ nhớ khi mô phỏng nhiều qubit", "errors"), ("cong hadamard", "02-cong-mot-qubit"),
             ("vuong viu CNOT", "04-vuong-viu"), ("statevector biên độ", "01-qubit"), ("chạy trên máy lượng tử thật IBM", "faq"),
             ("NISQ là gì", "glossary"), ("quên measure no counts", "errors"), ("execute không import được", "errors"),
             ("histogram và AerSimulator run", "03-do-luong"), ("GHZ 3 qubit", "04-vuong-viu"), ("kết quả mỗi lần khác nhau seed", "faq")]


def test_retrieval_recall_at_3():
    kb = KB()
    hit = sum(any(h["doc"] == exp for h in kb.search(q, 3)) for q, exp in RETRIEVAL)
    print(f"recall@3 = {hit}/{len(RETRIEVAL)}")
    assert hit / len(RETRIEVAL) >= 0.85


def test_chat_offline_conceptual():
    r = client.post("/api/chat", json={"message": "Superposition là gì?"}).get_json()
    assert r["sources"] and "chồng chập" in r["answer"].lower()


def test_chat_empty_rejected():
    assert client.post("/api/chat", json={"message": " "}).status_code == 400


def test_llm_path_with_mock_ollama(monkeypatch):
    seen = {}

    class H(BaseHTTPRequestHandler):
        def log_message(self, *a): pass
        def do_GET(self):
            self.send_response(200); self.end_headers(); self.wfile.write(b'{"models":[]}')
        def do_POST(self):
            seen["body"] = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
            self.send_response(200); self.end_headers()
            self.wfile.write(json.dumps({"message": {"content": "MOCK-LLM-ANSWER"}}).encode())

    srv = HTTPServer(("127.0.0.1", 0), H)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    monkeypatch.setattr(chat, "OLLAMA_URL", f"http://127.0.0.1:{srv.server_port}")
    monkeypatch.setattr(chat, "_llm_cache", (0, False))
    r = client.post("/api/chat", json={"message": "sửa lỗi giúp", "code": "from qiskit import execute"}).get_json()
    srv.shutdown()
    assert r["answer"] == "MOCK-LLM-ANSWER" and r["mode"].startswith("llm")
    prompt = seen["body"]["messages"][1]["content"]
    assert "NGỮ CẢNH" in prompt and "execute" in prompt and "LỖI" in prompt


def test_health_and_setup():
    h = client.get("/api/health").get_json()
    assert h["ok"] and h["lessons"] == 8 and h["kb_chunks"] > 20
    assert "pip install" in client.get("/api/setup").get_json()["body"]
