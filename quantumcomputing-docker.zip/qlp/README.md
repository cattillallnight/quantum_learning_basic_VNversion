# Quantum Programming Learning Platform

Website học lập trình lượng tử (Qiskit) bằng tiếng Việt: 8 bài học, trình soạn thảo chạy mã trên Qiskit Aer, chấm bài tự động, chatbot AI hỗ trợ học tập và debug.

## Chạy nhanh (Linux/macOS/WSL2)
```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python app.py            # http://127.0.0.1:5000
```
Docker: `docker compose up --build` (Dockerfile chưa được kiểm thử trong môi trường phát triển).
Windows gốc: sandbox dùng module `resource` (chỉ Linux/macOS) nên hãy dùng WSL2 hoặc Docker.

## Chatbot AI
- Luôn có chế độ **offline-RAG**: BM25 trên cơ sở tri thức (`content/`) + chẩn đoán lỗi theo luật; không cần mạng.
- Tùy chọn LLM mã nguồn mở chạy cục bộ qua Ollama: `ollama pull gemma4:e2b`. Biến môi trường: `OLLAMA_URL`, `QLP_LLM_MODEL`. Kiểm tra giấy phép model trước khi dùng thương mại.

## Cấu trúc
`app.py` API Flask · `sandbox*.py` chạy mã có giới hạn · `rag.py` KB/BM25 · `chat.py` chatbot · `content/lessons|kb|setup.md` nội dung (thêm bài = thêm file .md) · `static/` giao diện · `tests/` pytest + E2E · `docs/screenshots/` ảnh thực tế.

## Kiểm thử
```bash
python -m pytest tests -q          # 35 test
python app.py &  python tests/e2e.py   # cần: playwright install chromium
```
## Giới hạn đã biết
Sandbox chỉ là lớp bảo vệ cơ bản (chặn import, giới hạn CPU/RAM/thời gian), không đủ cho dịch vụ công khai: hãy chạy trong Docker không có mạng. Không có tài khoản người dùng; tiến độ lưu trong localStorage. Không có tính năng gửi job lên IBM Quantum (chỉ có hướng dẫn ở Bài 8).
