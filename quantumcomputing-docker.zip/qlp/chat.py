"""Chatbot: chẩn đoán lỗi theo luật + RAG; nếu có LLM mã nguồn mở chạy cục bộ (Ollama) thì dùng để diễn đạt câu trả lời."""
import json, os, re, time, urllib.request
from rag import KB, fold
from sandbox import run_code

OLLAMA_URL = os.environ.get("OLLAMA_URL", "http://localhost:11434")
LLM_MODEL = os.environ.get("QLP_LLM_MODEL", "gemma4:e2b")
kb = KB()

RULES = [  # (regex trên "Type: message", chẩn đoán, gợi ý sửa)
    (r"cannot import name 'execute'", "Hàm `execute` đã bị gỡ khỏi Qiskit từ phiên bản 1.0.",
     "Dùng `AerSimulator().run(transpile(qc, sim), shots=1024).result().get_counts()`."),
    (r"cannot import name 'Aer' from 'qiskit'|No module named 'qiskit_aer'|cannot import name 'AerSimulator'",
     "`Aer` không còn nằm trong `qiskit`; bộ mô phỏng nằm ở gói `qiskit-aer`.",
     "Cài `pip install qiskit-aer` rồi `from qiskit_aer import AerSimulator`."),
    (r"No module named",  "Thiếu thư viện Python.", "Kiểm tra môi trường ảo đã kích hoạt và chạy `pip install` gói tương ứng."),
    (r"No counts for experiment", "Mạch không có phép đo nên không có kết quả đếm.",
     "Thêm `qc.measure_all()` hoặc `qc.measure(qubit, cbit)` trước khi chạy."),
    (r"CircuitError.*(out of range|Index)|IndexError.*(qubit|out of range)", "Chỉ số qubit/bit cổ điển vượt quá kích thước mạch.",
     "Qubit đánh số từ 0 đến n-1; kiểm tra `QuantumCircuit(n, m)`."),
    (r"CircuitError.*(duplicate|same)", "Cùng một qubit bị dùng hai lần trong một cổng hai qubit.", "Dùng hai chỉ số qubit khác nhau, ví dụ `qc.cx(0, 1)`."),
    (r"AttributeError.*QuantumCircuit.*has no attribute", "Tên phương thức không tồn tại trên `QuantumCircuit` (sai tên cổng hoặc phiên bản Qiskit cũ/mới).",
     "Cổng thường dùng: h, x, y, z, s, t, cx, cz, swap, ccx, measure, measure_all."),
    (r"TypeError.*(missing|positional argument)", "Gọi cổng thiếu tham số.", "`qc.cx(điều_khiển, đích)`, `qc.h(qubit)`, `qc.measure(qubit, cbit)`."),
    (r"NameError.*'(\w+)'", "Dùng biến/tên chưa được định nghĩa hoặc chưa import.", "Kiểm tra chính tả và các dòng `import` ở đầu mã."),
    (r"IndentationError|SyntaxError", "Lỗi cú pháp Python.", "Kiểm tra thụt lề, dấu ngoặc, dấu hai chấm và dòng được báo."),
    (r"MemoryError|insufficient memory|Memory|TooLarge|ResourceLimit", "Mô phỏng cần quá nhiều bộ nhớ: trạng thái n qubit cần 2^n biên độ phức.",
     "Giảm số qubit (thực hành thường ≤ 20) hoặc dùng mạch Clifford với phương pháp stabilizer."),
    (r"Timeout", "Chương trình chạy quá lâu.", "Kiểm tra vòng lặp vô hạn, giảm `shots` hoặc số qubit."),
    (r"ImportError.*bị chặn", "Module này bị chặn trong môi trường thực hành vì lý do an toàn.", "Chỉ dùng qiskit, numpy, matplotlib, math, random, cmath…"),
    (r"QiskitError.*(basis|Cannot unroll|not in basis|unknown instruction)", "Mô phỏng/backend không hiểu cổng trong mạch.",
     "Gọi `transpile(qc, backend)` trước khi `run`."),
    (r"ZeroDivisionError|ValueError", "Giá trị đầu vào không hợp lệ.", "Đọc dòng cuối của traceback để biết tham số nào sai."),
]


def diagnose(err):
    if not err:
        return None
    text = f'{err["type"]}: {err["message"]}'
    for pat, what, fix in RULES:
        if re.search(pat, text, re.S):
            return {"what": what, "fix": fix}
    return {"what": "Chưa có luật chẩn đoán riêng cho lỗi này.", "fix": "Đọc dòng cuối traceback và đối chiếu dòng mã được báo."}


_llm_cache = (0, False)
last_llm_error = None


def llm_available():
    global _llm_cache
    if time.time() - _llm_cache[0] < 30:
        return _llm_cache[1]
    try:
        urllib.request.urlopen(OLLAMA_URL + "/api/tags", timeout=1.5).read()
        ok = True
    except Exception:
        ok = False
    _llm_cache = (time.time(), ok)
    return ok


SYSTEM = ("Bạn là gia sư lập trình lượng tử (Qiskit 1.x) cho người Việt, đồng thời là trợ lý đa năng: "
          "câu hỏi ngoài lượng tử (toán, đời sống, lập trình khác...) cứ trả lời bình thường bằng kiến thức của bạn. "
          "Luôn trả lời tiếng Việt, ngắn gọn, chính xác.\n"
          "Với chủ đề lượng tử: ưu tiên mục [TÀI LIỆU] nếu có; không có thì dùng kiến thức chuẩn, không bịa. "
          "Kiến thức nền bắt buộc đúng: qubit |ψ>=α|0>+β|1>, |α|²+|β|²=1; n qubit = 2^n biên độ; "
          "H tạo chồng chập, CX tạo vướng víu (Bell: h(0);cx(0,1)); đo làm sụp đổ, kết quả là xác suất |biên độ|²; "
          "Qiskit>=1.0 đã bỏ execute() và Aer nằm ở qiskit_aer: dùng AerSimulator().run(transpile(qc,sim),shots=1024).result().get_counts(); "
          "mạch cần measure/measure_all mới có counts; qubit đánh số từ 0; Qiskit đọc bitstring little-endian (qubit 0 ở ngoài cùng bên phải). "
          "Debug: nêu nguyên nhân, rồi mã đã sửa.")

QUANTUM = re.compile(r"qubit|qiskit|quantum|luong tu|grover|deutsch|hadamard|bell|vuong viu|entangle|chong chap|superposition|"
                     r"bloch|do luong|measure|circuit|mach|cong |gate|aer|shots|counts|ibm|backend|transpile|oracle|phase|pha |"
                     r"\bcx\b|\bh\(|\bqc\b|simulator|mo phong|xac suat|bien do|stabilizer|noise|nhieu")  # chỉ nhồi tài liệu khi hỏi về lượng tử


def ask_llm(prompt):
    body = json.dumps({"model": LLM_MODEL, "stream": False, "keep_alive": "30m",
                       "options": {"temperature": 0.3, "num_ctx": 4096, "num_predict": 700},
                       "messages": [{"role": "system", "content": SYSTEM}, {"role": "user", "content": prompt}]}).encode()
    rq = urllib.request.Request(OLLAMA_URL + "/api/chat", body, {"Content-Type": "application/json"})
    return json.loads(urllib.request.urlopen(rq, timeout=180).read())["message"]["content"]


def answer(message: str, code: str | None = None, error: dict | None = None):
    run = None
    if code and not error and re.search(r"lỗi|loi|debug|sửa|sua|bug|error|không chạy|khong chay|sai", message, re.I):
        run = run_code(code)
        error = run["error"]
    diag = diagnose(error)
    query = message + (" " + error["type"] + " " + error["message"] if error else "")
    on_topic = bool(code or error or QUANTUM.search(fold(message)))
    hits = kb.search(query, 2) if on_topic else []
    sources = [{"id": h["doc"], "title": h["title"], "kind": h["kind"]} for h in hits]
    ctx = "\n\n---\n".join(f'[{h["title"]}]\n{h["text"][:800]}' for h in hits)
    if llm_available():
        p = f"[TÀI LIỆU]\n{ctx}\n\n" if ctx else ""
        if code:
            p += f"MÃ:\n```python\n{code[:3000]}\n```\n"
        if error:
            p += f"LỖI:\n{error['traceback'][-1500:]}\nGợi ý từ luật: {diag['what']} {diag['fix']}\n"
        p += f"CÂU HỎI: {message}"
        try:
            return {"answer": ask_llm(p), "mode": "llm:" + LLM_MODEL, "sources": sources, "diagnosis": diag, "ran": run is not None}
        except Exception as e:
            global last_llm_error
            last_llm_error = f"{type(e).__name__}: {e}"
            # rơi về chế độ offline
    parts = []
    if diag:
        parts.append(f"**Chẩn đoán lỗi** ({error['type']}" + (f", dòng {error['line']}" if error.get("line") else "") + f"): {diag['what']}\n**Cách sửa:** {diag['fix']}")
    if hits:
        h = hits[0]
        parts.append(f"**Tài liệu liên quan — {h['title']}:**\n" + h["text"][:900])
    elif not diag:
        parts.append("Mình chưa tìm thấy nội dung phù hợp trong cơ sở tri thức. Hãy thử hỏi lại với từ khóa khác (qubit, Hadamard, Bell, Grover…).")
    return {"answer": "\n\n".join(parts), "mode": "offline-rag", "sources": sources, "diagnosis": diag, "ran": run is not None}
