"""Knowledge Base + RAG: BM25 thuần Python (không cần tải model), chấp nhận truy vấn không dấu."""
import math, os, re, unicodedata
from collections import Counter

BASE = os.path.dirname(os.path.abspath(__file__))
STOP = set("la va cua cho voi mot cac nhung de trong khi thi se duoc co khong toi ban minh the nay do nhu tu den ra vao gi bang may nao sao tai vi hay hoac thi la".split())


def fold(s: str) -> str:
    s = unicodedata.normalize("NFD", s.lower().replace("đ", "d"))
    return "".join(c for c in s if unicodedata.category(c) != "Mn")


def tokens(s: str):
    t = [w for w in re.findall(r"[a-z0-9_]+", fold(s)) if w not in STOP]
    return t + [a + "_" + b for a, b in zip(t, t[1:])]


def parse_md(text: str):
    meta, body = {}, text
    if text.startswith("---"):
        head, _, body = text[3:].partition("\n---")
        for ln in head.strip().splitlines():
            if ":" in ln:
                k, v = ln.split(":", 1)
                meta[k.strip()] = v.strip()
        body = body.lstrip("\n")
    return meta, body


HIDDEN = re.compile(r"```(starter|solution|check)\n.*?```\n?", re.S)


def load_docs():
    docs = []
    for sub in ("lessons", "kb"):
        d = os.path.join(BASE, "content", sub)
        for fn in sorted(os.listdir(d)):
            if fn.endswith(".md"):
                meta, body = parse_md(open(os.path.join(d, fn), encoding="utf-8").read())
                docs.append({"id": meta.get("id", fn[:-3]), "title": meta.get("title", fn), "kind": sub,
                             "body": HIDDEN.sub("", body)})
    return docs


def chunk(doc):
    parts = re.split(r"\n(?=#{1,3} )", doc["body"])
    out = []
    for p in parts:
        p = p.strip()
        if len(p) < 30:
            continue
        h = re.match(r"#{1,3} (.+)", p)
        out.append({"doc": doc["id"], "kind": doc["kind"], "title": doc["title"] + (" › " + h.group(1) if h else ""), "text": p})
    return out


class KB:
    def __init__(self):
        self.docs = load_docs()
        self.chunks = [c for d in self.docs for c in chunk(d)]
        self.tf = [Counter(tokens(c["title"] + " " + c["title"] + " " + c["text"])) for c in self.chunks]
        self.len = [sum(t.values()) for t in self.tf]
        self.avg = sum(self.len) / len(self.len)
        df = Counter(w for t in self.tf for w in t)
        n = len(self.chunks)
        self.idf = {w: math.log(1 + (n - f + .5) / (f + .5)) for w, f in df.items()}

    def search(self, q, k=3):
        qt = tokens(q)
        scored = []
        for i, t in enumerate(self.tf):
            s = 0.0
            for w in qt:
                f = t.get(w)
                if f:
                    s += self.idf[w] * f * 2.5 / (f + 1.5 * (.25 + .75 * self.len[i] / self.avg))
            if s > 0:
                scored.append((s, i))
        scored.sort(reverse=True)
        seen, res = set(), []
        for s, i in scored:
            c = self.chunks[i]
            if c["text"] in seen:
                continue
            seen.add(c["text"])
            res.append({**c, "score": round(s, 3)})
            if len(res) == k:
                break
        return res
