"""Chạy mã người học trong tiến trình con có giới hạn tài nguyên. Đọc JSON từ stdin, in kết quả JSON sau dấu @@RESULT@@."""
import sys, json, io, os, resource, base64, builtins, contextlib

MEM = int(os.environ.get("QLP_MEM_MB", "3072")) * 1024 * 1024
CPU = int(os.environ.get("QLP_CPU_S", "20"))
resource.setrlimit(resource.RLIMIT_AS, (MEM, MEM))
resource.setrlimit(resource.RLIMIT_CPU, (CPU, CPU + 5))
resource.setrlimit(resource.RLIMIT_FSIZE, (1 << 20, 1 << 20))

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import qiskit
from qiskit import QuantumCircuit

BLOCK = {"os", "sys", "subprocess", "socket", "shutil", "ctypes", "multiprocessing", "threading",
         "requests", "urllib", "http", "ftplib", "smtplib", "pathlib", "importlib", "pickle",
         "builtins", "signal", "resource", "tempfile", "glob", "asyncio", "webbrowser"}
_real_import = builtins.__import__


def guarded_import(name, globals=None, locals=None, fromlist=(), level=0):
    if globals and globals.get("__name__") == "__user__" and name.split(".")[0] in BLOCK:
        raise ImportError(f"Module '{name}' bị chặn trong môi trường thực hành")
    return _real_import(name, globals, locals, fromlist, level)


def make_builtins():
    b = dict(vars(builtins))
    for k in ("open", "eval", "exec", "compile", "input", "breakpoint", "help", "exit", "quit", "globals", "locals", "vars"):
        b.pop(k, None)
    b["__import__"] = guarded_import
    return b


def main():
    req = json.loads(sys.stdin.read())
    code, check = req.get("code", ""), req.get("check")
    res = {"ok": True, "stdout": "", "error": None, "circuits": [], "images": [], "check": None,
           "qiskit": qiskit.__version__}
    ns = {"__name__": "__user__", "__builtins__": make_builtins()}
    buf = io.StringIO()
    try:
        co = compile(code, "<user>", "exec")
        with contextlib.redirect_stdout(buf):
            exec(co, ns)
    except BaseException as e:  # noqa
        import traceback
        lines = code.splitlines()
        frames = [f for f in traceback.extract_tb(e.__traceback__) if f.filename == "<user>"]
        lineno = e.lineno if isinstance(e, SyntaxError) else (frames[-1].lineno if frames else None)
        tb = "Traceback (most recent call last):\n"
        for f in frames:
            src = lines[f.lineno - 1].strip() if 0 < f.lineno <= len(lines) else ""
            tb += f'  File "<user>", line {f.lineno}, in {f.name}\n    {src}\n'
        tb += "".join(traceback.format_exception_only(type(e), e)).rstrip()
        res.update(ok=False, error={"type": type(e).__name__, "message": str(e)[:500], "line": lineno, "traceback": tb[-2500:]})
    res["stdout"] = buf.getvalue()[:20000]
    if res["ok"]:
        for k, v in list(ns.items()):
            if isinstance(v, QuantumCircuit) and not k.startswith("_") and len(res["circuits"]) < 3:
                try:
                    res["circuits"].append({"name": k, "text": str(v.draw("text"))})
                except Exception:
                    pass
        for n in plt.get_fignums()[:4]:
            b = io.BytesIO()
            plt.figure(n).savefig(b, format="png", dpi=100, bbox_inches="tight")
            res["images"].append(base64.b64encode(b.getvalue()).decode())
        if check:
            try:
                with contextlib.redirect_stdout(io.StringIO()):
                    exec(check, {**ns, "__builtins__": builtins})
                res["check"] = {"passed": True, "message": "Đạt yêu cầu bài tập."}
            except AssertionError as e:
                res["check"] = {"passed": False, "message": str(e) or "Kết quả chưa đúng yêu cầu."}
            except Exception as e:  # noqa
                res["check"] = {"passed": False, "message": f"Chưa chấm được: {type(e).__name__}: {str(e)[:200]}"}
    sys.stdout.write("\n@@RESULT@@" + json.dumps(res))


main()
