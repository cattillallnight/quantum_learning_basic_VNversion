import os, re
from flask import Flask, jsonify, request, send_from_directory, abort
import qiskit
from rag import parse_md, BASE
from sandbox import run_code
import chat

app = Flask(__name__, static_folder="static", static_url_path="")
LDIR = os.path.join(BASE, "content", "lessons")
BLOCKS = re.compile(r"```(starter|solution|check)\n(.*?)```\n?", re.S)


def load_lessons():
    out = {}
    for fn in sorted(os.listdir(LDIR)):
        if not fn.endswith(".md"):
            continue
        meta, body = parse_md(open(os.path.join(LDIR, fn), encoding="utf-8").read())
        parts = {k: v for k, v in BLOCKS.findall(body)}
        out[meta["id"]] = {**meta, "minutes": int(meta.get("minutes", 15)), "body": BLOCKS.sub("", body),
                           "starter": parts.get("starter", ""), "solution": parts.get("solution", ""), "check": parts.get("check", "")}
    return out


LESSONS = load_lessons()


def _json():
    return request.get_json(silent=True) or {}


@app.get("/")
def index():
    return send_from_directory("static", "index.html")


@app.get("/api/health")
def health():
    return jsonify(ok=True, qiskit=qiskit.__version__, lessons=len(LESSONS), kb_chunks=len(chat.kb.chunks),
                   llm_available=chat.llm_available(), llm_model=chat.LLM_MODEL, llm_error=chat.last_llm_error)


@app.get("/api/lessons")
def lessons():
    return jsonify([{k: v[k] for k in ("id", "title", "level", "minutes", "summary")} for v in LESSONS.values()])


@app.get("/api/lessons/<lid>")
def lesson(lid):
    l = LESSONS.get(lid) or abort(404)
    return jsonify({k: l[k] for k in ("id", "title", "level", "minutes", "summary", "body", "starter")} | {"has_check": bool(l["check"])})


@app.get("/api/lessons/<lid>/solution")
def solution(lid):
    return jsonify(solution=(LESSONS.get(lid) or abort(404))["solution"])


@app.get("/api/setup")
def setup():
    return jsonify(body=parse_md(open(os.path.join(BASE, "content", "setup.md"), encoding="utf-8").read())[1])


@app.post("/api/run")
def run():
    return jsonify(run_code(str(_json().get("code", ""))))


@app.post("/api/check")
def check():
    d = _json()
    l = LESSONS.get(d.get("lesson")) or abort(404)
    return jsonify(run_code(str(d.get("code", "")), l["check"]))


@app.post("/api/chat")
def chat_api():
    d = _json()
    msg = str(d.get("message", "")).strip()[:2000]
    if not msg:
        return jsonify(error="Tin nhắn trống"), 400
    return jsonify(chat.answer(msg, (d.get("code") or None), d.get("error") or None))


if __name__ == "__main__":
    app.run(host=os.environ.get("HOST", "127.0.0.1"), port=int(os.environ.get("PORT", "5000")), threaded=True)
