const $ = s => document.querySelector(s), api = (u, o) => fetch(u, o).then(r => r.json());
const post = (u, b) => api(u, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(b) });
const esc = s => s.replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const store = { get(k, d) { try { return JSON.parse(localStorage.getItem(k)) ?? d } catch { return d } }, set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)) } catch { } } };
let lessons = [], lastError = null;

function md(src) { // trình render Markdown tối giản (đã escape HTML)
  const blocks = []; src = src.replace(/```(\w*)(?: (\w+))?\n([\s\S]*?)```/g, (_, lang, flag, code) => { blocks.push({ code, run: flag === 'run' }); return `\n@@B${blocks.length - 1}@@\n`; });
  const inl = t => esc(t).replace(/`([^`]+)`/g, '<code>$1</code>').replace(/\*\*([^*]+)\*\*/g, '<b>$1</b>').replace(/\*([^*]+)\*/g, '<i>$1</i>');
  let out = '', list = null;
  const close = () => { if (list) { out += `</${list}>`; list = null } };
  for (const ln of src.split('\n')) {
    let m;
    if (m = ln.match(/^@@B(\d+)@@$/)) { close(); const b = blocks[m[1]]; out += `<div class="codewrap"><pre><code>${esc(b.code)}</code></pre>${b.run ? `<button class="btn" data-run="${m[1]}">▶ Thử trong trình soạn thảo</button>` : ''}</div>`; }
    else if (m = ln.match(/^(#{1,3}) (.+)/)) { close(); out += `<h${m[1].length + 1}>${inl(m[2])}</h${m[1].length + 1}>`; }
    else if (m = ln.match(/^[-*] (.+)/)) { if (list !== 'ul') { close(); out += '<ul>'; list = 'ul' } out += `<li>${inl(m[1])}</li>`; }
    else if (m = ln.match(/^\d+\. (.+)/)) { if (list !== 'ol') { close(); out += '<ol>'; list = 'ol' } out += `<li>${inl(m[1])}</li>`; }
    else if (m = ln.match(/^> (.+)/)) { close(); out += `<blockquote>${inl(m[1])}</blockquote>`; }
    else if (ln.trim()) { close(); out += `<p>${inl(ln)}</p>`; } else close();
  }
  close(); return { html: out, blocks };
}

function editorHTML(id, withCheck) {
  return `<div class="ed"><div class="ed-h"><b>Trình soạn thảo Python</b><span class="sp"></span>
  <button class="btn pri" id="run${id}">▶ Chạy (Ctrl+Enter)</button>${withCheck ? `<button class="btn" id="chk${id}">✔ Chấm bài</button><button class="btn" id="sol${id}">Xem đáp án</button><button class="btn" id="rst${id}">Đặt lại</button>` : ''}
  <button class="btn" id="dbg${id}">🐞 Nhờ AI debug</button></div>
  <textarea class="code" id="code${id}" spellcheck="false"></textarea><div class="out" id="out${id}"><span class="crumb">Kết quả sẽ hiển thị tại đây.</span></div></div>`;
}
function showResult(el, r, checking) {
  let h = '';
  if (r.error) { lastError = r.error; h += `<div class="err"><pre>${esc(r.error.traceback)}</pre></div>`; } else lastError = null;
  if (r.stdout) h += `<pre>${esc(r.stdout)}</pre>`;
  (r.circuits || []).forEach(c => h += `<div class="crumb">Mạch <code>${esc(c.name)}</code>:</div><pre>${esc(c.text)}</pre>`);
  (r.images || []).forEach(b => h += `<img src="data:image/png;base64,${b}" alt="kết quả">`);
  if (r.check) h = `<div class="res ${r.check.passed ? 'ok' : 'no'}">${r.check.passed ? '✔' : '✘'} ${esc(r.check.message)}</div>` + h;
  el.innerHTML = h || '<span class="crumb">Chạy thành công, không có đầu ra.</span>';
}
function wireEditor(id, o = {}) {
  const ta = $('#code' + id), out = $('#out' + id);
  ta.value = o.starter || ''; ta.onkeydown = e => {
    if (e.key === 'Tab') { e.preventDefault(); const s = ta.selectionStart; ta.setRangeText('    ', s, ta.selectionEnd, 'end'); }
    if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) { e.preventDefault(); $('#run' + id).click(); }
  };
  const busy = async (btn, fn) => { btn.disabled = true; out.innerHTML = '<span class="crumb">Đang chạy…</span>'; try { await fn() } catch (e) { out.textContent = 'Lỗi kết nối: ' + e } btn.disabled = false; };
  $('#run' + id).onclick = e => busy(e.target, async () => showResult(out, await post('/api/run', { code: ta.value })));
  $('#dbg' + id).onclick = () => { $('#chat').classList.add('open'); ask('Code của tôi bị lỗi, hãy giúp debug.'); };
  if (o.lesson) {
    $('#chk' + id).onclick = e => busy(e.target, async () => {
      const r = await post('/api/check', { lesson: o.lesson, code: ta.value }); showResult(out, r);
      if (r.check?.passed) { const d = store.get('done', []); if (!d.includes(o.lesson)) store.set('done', [...d, o.lesson]); }
    });
    $('#sol' + id).onclick = async () => { if (confirm('Xem đáp án sẽ thay thế mã hiện tại. Tiếp tục?')) ta.value = (await api(`/api/lessons/${o.lesson}/solution`)).solution; };
    $('#rst' + id).onclick = () => ta.value = o.starter;
  }
  return ta;
}

async function home() {
  const done = store.get('done', []), pct = Math.round(100 * done.filter(d => lessons.some(l => l.id === d)).length / lessons.length);
  $('#main').innerHTML = `<div class="wrap"><div class="hero"><h1>Học lập trình lượng tử với Qiskit</h1><p>${lessons.length} bài học từ qubit đến Grover, chạy mã ngay trên trình duyệt, có trợ lý AI hỗ trợ debug.</p>
  <p>Tiến độ: ${done.length}/${lessons.length} bài (lưu trên trình duyệt này)</p><div class="prog"><i style="width:${pct}%"></i></div></div>
  <div class="cards">${lessons.map(l => `<a class="card" href="#/lesson/${l.id}"><h3>${esc(l.title)}</h3><p>${esc(l.summary)}</p><div class="meta"><span>${esc(l.level)}</span><span>${l.minutes} phút</span>${done.includes(l.id) ? '<span class="done">✔ Hoàn thành</span>' : ''}</div></a>`).join('')}</div>
  <h2>Bắt đầu thực hành</h2><p>Xem <a href="#/setup">hướng dẫn cài đặt</a> hoặc thử ngay <a href="#/playground">sân chơi mã</a>.</p></div>`;
}
async function lessonPage(id) {
  const l = await api('/api/lessons/' + id), i = lessons.findIndex(x => x.id === id), r = md(l.body);
  $('#main').innerHTML = `<div class="wrap"><div class="crumb"><a href="#/">Lộ trình</a> › ${esc(l.title)} · ${l.level} · ${l.minutes} phút</div><h1>${esc(l.title)}</h1><div class="prose">${r.html}</div>${editorHTML('L', l.has_check)}
  <div class="lnav">${i > 0 ? `<a class="btn" href="#/lesson/${lessons[i - 1].id}">← Bài trước</a>` : '<span></span>'}${i < lessons.length - 1 ? `<a class="btn pri" href="#/lesson/${lessons[i + 1].id}">Bài tiếp →</a>` : ''}</div></div>`;
  const ta = wireEditor('L', { starter: l.starter, lesson: id });
  document.querySelectorAll('[data-run]').forEach(b => b.onclick = () => { ta.value = r.blocks[b.dataset.run].code; $('#runL').click(); ta.scrollIntoView({ behavior: 'smooth', block: 'center' }); });
}
function playground() {
  $('#main').innerHTML = `<div class="wrap"><h1>Sân chơi mã Qiskit</h1><p class="crumb">Chạy mã Python với qiskit, qiskit-aer, numpy, matplotlib. Biến <code>QuantumCircuit</code> sẽ tự được vẽ; hình matplotlib được hiển thị.</p>${editorHTML('P', false)}</div>`;
  const ta = wireEditor('P', { starter: store.get('pg', "from qiskit import QuantumCircuit, transpile\nfrom qiskit_aer import AerSimulator\nfrom qiskit.visualization import plot_histogram\n\nqc = QuantumCircuit(2, 2)\nqc.h(0)\nqc.cx(0, 1)\nqc.measure([0, 1], [0, 1])\n\nsim = AerSimulator()\ncounts = sim.run(transpile(qc, sim), shots=1024).result().get_counts()\nprint(counts)\nplot_histogram(counts)\n") });
  ta.oninput = () => store.set('pg', ta.value);
}
async function setupPage() { const r = md((await api('/api/setup')).body); $('#main').innerHTML = `<div class="wrap prose"><h1>Hướng dẫn cài đặt</h1>${r.html}</div>`; }

async function route() {
  const h = location.hash.slice(1) || '/', m = h.match(/^\/lesson\/(.+)/);
  document.querySelectorAll('nav a').forEach(a => a.classList.toggle('on', a.dataset.n === (m ? 'home' : h === '/' ? 'home' : h.slice(1))));
  if (m) await lessonPage(m[1]); else if (h === '/playground') playground(); else if (h === '/setup') await setupPage(); else await home();
  $('#main').scrollTop = 0;
}

function bubble(cls, text, extra = '') { const d = document.createElement('div'); d.className = 'm ' + cls; d.innerHTML = md(text).html.replace(/<button[^>]*data-run[^>]*>.*?<\/button>/g, '') + extra; $('#msgs').append(d); d.scrollIntoView(); return d; }
async function ask(text) {
  if (!text) return; const code = $('#withCode').checked ? ($('#codeL') || $('#codeP'))?.value : null;
  bubble('u', text); const w = bubble('b', '…');
  try {
    const r = await post('/api/chat', { message: text, code, error: lastError });
    w.remove(); bubble('b', r.answer, (r.llm_note ? `<div class="src" style="color:var(--bad)">⚠ AI chưa hoạt động, đang dùng tra cứu offline. Lý do: ${esc(r.llm_note)}</div>` : '') + (r.sources?.length ? `<div class="src">Nguồn: ${r.sources.map(s => esc(s.title)).join(' · ')}</div>` : '')); $('#mode').textContent = r.mode;
  } catch (e) { w.textContent = 'Lỗi kết nối: ' + e; }
}
$('#send').onclick = () => { const v = $('#chatIn').value.trim(); $('#chatIn').value = ''; ask(v); };
$('#chatIn').onkeydown = e => { if (e.key === 'Enter') $('#send').click(); };
$('#chatToggle').onclick = () => $('#chat').classList.toggle('open');
addEventListener('hashchange', route);
(async () => { lessons = await api('/api/lessons'); const h = await api('/api/health'); $('#mode').textContent = h.llm_available ? 'LLM: ' + h.llm_model : 'offline-RAG';
  bubble('b', 'Xin chào! Mình giải đáp khái niệm lượng tử và giúp debug mã Qiskit. Chạy mã bị lỗi, rồi bấm “🐞 Nhờ AI debug” hoặc hỏi trực tiếp.'); route(); })();
