import json, os, subprocess, sys, tempfile, threading
RUNNER = os.path.join(os.path.dirname(os.path.abspath(__file__)), "sandbox_runner.py")
_sem = threading.BoundedSemaphore(int(os.environ.get("QLP_MAX_JOBS", "2")))
TIMEOUT = int(os.environ.get("QLP_TIMEOUT_S", "25"))
MAX_CODE = 20000


def run_code(code: str, check: str | None = None) -> dict:
    if len(code) > MAX_CODE:
        return _err("TooLarge", f"Mã vượt quá {MAX_CODE} ký tự.")
    if not _sem.acquire(timeout=30):
        return _err("Busy", "Máy chủ đang bận, thử lại sau.")
    try:
        with tempfile.TemporaryDirectory() as d:
            env = {"PATH": os.environ.get("PATH", ""), "HOME": d, "MPLCONFIGDIR": d, "OMP_NUM_THREADS": "2",
                   "QLP_MEM_MB": os.environ.get("QLP_MEM_MB", "3072"), "QLP_CPU_S": os.environ.get("QLP_CPU_S", "20")}
            try:
                p = subprocess.run([sys.executable, "-I", RUNNER], input=json.dumps({"code": code, "check": check}),
                                   capture_output=True, text=True, timeout=TIMEOUT, cwd=d, env=env)
            except subprocess.TimeoutExpired:
                return _err("Timeout", f"Chạy quá {TIMEOUT} giây — kiểm tra vòng lặp vô hạn hoặc số qubit quá lớn.")
            out = p.stdout
            if "@@RESULT@@" in out:
                return json.loads(out.rsplit("@@RESULT@@", 1)[1])
            tail = (p.stderr or out)[-400:]
            if p.returncode == -24:
                return _err("Timeout", "Vượt giới hạn thời gian CPU — kiểm tra vòng lặp vô hạn hoặc mạch quá lớn.")
            kind = "MemoryError" if "MemoryError" in tail else "ResourceLimit"
            return _err(kind, "Tiến trình bị dừng (vượt giới hạn bộ nhớ/CPU). " + tail.strip()[-200:])
    finally:
        _sem.release()


def _err(t, m):
    return {"ok": False, "stdout": "", "circuits": [], "images": [], "check": None,
            "error": {"type": t, "message": m, "line": None, "traceback": f"{t}: {m}"}}
